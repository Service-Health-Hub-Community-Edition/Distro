using module ..\Utility.psd1
using module ..\Utility.psm1
using module ..\Logging.psm1
using module ..\BaseMessage.psm1
using module .\BaseEntity.psm1

class AzureUpdateEntity: BaseEntity
{
    AzureUpdateEntity(
        [BaseMessage]$Message
    ): base($Message)
    {
        
    }

    [void]Initialize(
        [BaseMessage]$Message
    )
    {
        ([BaseEntity]$this).Initialize($Message);

        if ($null -ne $Message.Message)
        {
            $title = [Utility]::NormalizeValue($Message.Message.title);

            $msg = "";

            foreach ($content in $Message.Message.contents) 
            {
                $msg += "<p>"+$content+"</p>" 
            }

            $description = [regex]::Replace($msg, '(?<=<p>)\\[.+?\\](?=</p>)', '<b>$&</b>');
            $history = [regex]::Replace($msg, '(?<=<p>)\\[.+?\\](?=</p>)', '<b>$&</b>');

            $this.m_properties.Add("Title", $title);
            $this.m_properties.Add("NotificationTitle", $title);
            $this.m_properties.Add("Description", $description);
            $this.m_properties.Add("History", $history);
            $this.m_properties.Add("Summary", [Utility]::NormalizeValue($Message.Message.summary));
            $this.m_properties.Add("ReleaseStatus", [Utility]::NormalizeValue($Message.Message.releaseStatus));
            $this.m_properties.Add("Article", [Utility]::NormalizeValue($Message.Message.link));
            $this.m_properties.Add("ArticleMarkdownLink", [string]::IsNullOrWhiteSpace($Message.Message.link) ? "None" : "[Link]($([Utility]::NormalizeValue($Message.Message.link)))");
            $this.m_properties.Add("TagsArray", [Utility]::NormalizeValue($Message.Message.tags));
            $this.m_properties.Add("Tags", [Utility]::NormalizeValue($Message.Message.tags) -join ', ');
            $this.m_properties.Add("Published", [Utility]::DateTimeToString($Message.Message.published));
        }
    }
}