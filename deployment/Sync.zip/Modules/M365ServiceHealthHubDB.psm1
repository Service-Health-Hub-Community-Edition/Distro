using module .\BaseConfiguration.psm1
using module .\Logging.psm1
using module .\SHHDatabase.psm1
using module .\AuthManager.psm1

class M365ServiceHealthHubDB: SHHDatabase
{
    #region Schema Creation Script
    hidden [string] $m_dbSchemaCreationScript = @"
/****** Object:  Table [dbo].[Notifications]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Notifications](
    [ID] [nvarchar](64) NOT NULL,
    [LastUpdatedTime] [datetime] NOT NULL,
    [Data] [nvarchar](max) NOT NULL,
    [WorkItemID] [nvarchar](128) NULL,
    [WorkItemURL] [nvarchar](max) NULL,
    [TargetSystem] [nvarchar](64) NULL,
    [Type] [nvarchar](32) NOT NULL,
    CONSTRAINT [PK_Notifications] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  UserDefinedFunction [dbo].[fn_AllDistinctValues]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fn_AllDistinctValues] (
    @propertyName nvarchar(64),
    @contentType nvarchar(128) = NULL
)
RETURNS TABLE
AS
RETURN
    SELECT DISTINCT 
        JSON_VALUE(Data, '$.'+@propertyName) AS Value
    FROM
        dbo.Notifications
    WHERE
        (JSON_VALUE(Data, '$.'+@propertyName) IS NOT NULL) AND
        [Type] = @contentType
GO
/****** Object:  UserDefinedFunction [dbo].[fn_AllDistinctValuesFromCollection]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fn_AllDistinctValuesFromCollection] (
    @propertyName nvarchar(64),
    @contentType nvarchar(128) = NULL
)
RETURNS TABLE
AS
RETURN
    SELECT DISTINCT colData.Value
FROM
    (SELECT [collectionData].[value] as [Value], [Data], [notifications].[Type]
    FROM dbo.Notifications as notifications
        CROSS APPLY OpenJson([Data], '$.'+@propertyName) as collectionData
    WHERE [notifications].[Type] = @contentType) as colData
    
GO
/****** Object:  View [dbo].[AllComms]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[AllComms]
AS
SELECT ID, JSON_VALUE(Data, '$.Title') AS Title, JSON_VALUE(Data, '$.WorkloadDisplayName') AS Workload, CONVERT(DateTime, JSON_VALUE(Data, '$.StartTime')) AS StartTime, CONVERT(DateTime, JSON_VALUE(Data, '$.EndTime')) 
                    AS EndTime
FROM     dbo.Notifications
WHERE  (JSON_VALUE(Data, '$.MessageType') = 'Incident')
GO
/****** Object:  Table [dbo].[Roadmap]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Roadmap](
    [ID] [nvarchar](32) NOT NULL,
    [LastUpdatedTime] [datetime] NOT NULL,
    [Data] [nvarchar](max) NOT NULL,
    [WorkItemID] [nvarchar](128) NULL,
    [WorkItemURL] [nvarchar](max) NULL,
    [TargetSystem] [nvarchar](64) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[AllRoadmapComms]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/****** Object:  View [dbo].[AllRoadmapComms]    Script Date: 18.08.2021 15:23:22 ******/

CREATE VIEW [dbo].[AllRoadmapComms]
AS
SELECT ID, '[' + ID + '] ' + JSON_VALUE(Data, '$.Title') AS Title, CONVERT(DATETIME2, JSON_VALUE(Data, '$.AvailabilityDateFrom')) AS AvailabilityFrom, CONVERT(DATETIME2, JSON_VALUE(Data, '$.AvailabilityDateTo')) AS AvailabilityTo, 
                    JSON_QUERY(Data, '$.Category') AS Category
FROM     dbo.Roadmap
GO
/****** Object:  View [dbo].[AllServiceHealthWorkloads]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[AllServiceHealthWorkloads]
AS
SELECT DISTINCT JSON_VALUE(Data, '$.WorkloadDisplayName') AS Workload
FROM     dbo.Notifications
WHERE  (JSON_VALUE(Data, '$.WorkloadDisplayName') IS NOT NULL)
GO
/****** Object:  View [dbo].[AllRoadmapCommsDetailed]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[AllRoadmapCommsDetailed]
AS
SELECT ID, 
        JSON_VALUE(Data, '$.Title') AS [Title],
        CONVERT(DATETIME2, JSON_VALUE(Data, '$.AvailabilityDateFrom')) AS [AvailabilityFrom],
        CONVERT(DATETIME2, JSON_VALUE(Data, '$.AvailabilityDateTo')) AS [AvailabilityTo], 
        JSON_QUERY(Data, '$.Category') AS [Category],
        JSON_VALUE(Data, '$.Description') AS [Description],
        JSON_VALUE(Data, '$.AvailabilityDate') AS [AvailabilityDate],
        CONVERT(DATETIME2, CONVERT(datetimeoffset, JSON_VALUE(Data, '$.Published'))) AS [Published],
        CONVERT(DATETIME2, CONVERT(datetimeoffset, JSON_VALUE(Data, '$.LastUpdated'))) AS [LastUpdated],
        WorkItemID,
        WorkItemURL
FROM    dbo.Roadmap
GO
/****** Object:  View [dbo].[vw_RoadmapStatistics]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_RoadmapStatistics]
AS
SELECT 
(SELECT COUNT(ID)
                        FROM      dbo.Roadmap CROSS APPLY OpenJson([Data], '$.Category')
                        WHERE   [value] LIKE '%in development%') AS InDevelopment,
(SELECT COUNT(ID)
                        FROM      dbo.Roadmap CROSS APPLY OpenJson([Data], '$.Category')
                        WHERE   [value] LIKE '%rolling out%') AS RollingOut,
(SELECT COUNT(ID)
                        FROM      dbo.Roadmap CROSS APPLY OpenJson([Data], '$.Category')
                        WHERE   [value] LIKE '%launched%') AS Launched


GO
/****** Object:  Table [dbo].[Config]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Config](
    [Key] [nvarchar](256) NOT NULL,
    [SerializedValue] [nvarchar](max) NULL,
    [DataType] [nchar](64) NOT NULL,
    CONSTRAINT [PK_Config] PRIMARY KEY CLUSTERED 
(
    [Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ServiceStatus]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ServiceStatus](
    [Id] [nvarchar](256) NOT NULL,
    [WorkloadDisplayName] [nvarchar](512) NOT NULL,
    [Status] [nvarchar](128) NOT NULL,
    [StatusDisplayName] [nvarchar](128) NOT NULL,
    [IncidentIds] [nvarchar](max) NOT NULL,
    [StatusTime] [datetime] NOT NULL,
    [FeatureStatus] [nvarchar](max) NOT NULL,
    [RawData] [nvarchar](max) NOT NULL,
    CONSTRAINT [PK_ServiceStatus] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Version]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Version](
    [Version] [nvarchar](32) NOT NULL,
    [LastUpdatedTime] [datetime] NOT NULL,
    [ID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Notifications] ADD  DEFAULT ('') FOR [Type]
GO
ALTER TABLE [dbo].[Version] ADD  DEFAULT (newid()) FOR [ID]
GO
/****** Object:  StoredProcedure [dbo].[proc_AddNotification]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ====================================================
-- Author: aldras
-- Create date: 12/18/2018
-- Modify date: 11/05/2021
-- Description: Adds notification information
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddNotification]
    @Id nvarchar(64),
    @LastUpdatedTime datetime,
    @Data nvarchar(MAX),
    @WorkItemID nvarchar(128) = null,
    @WorkItemURL nvarchar(MAX) = null,
    @TargetSystem nvarchar(64) = null,
    @Type nvarchar(32) = ''
AS
BEGIN
    SET NOCOUNT ON;
    declare @existingTicketId as nvarchar(64) = (select [Id] from [dbo].[Notifications] where [Id]=@Id)

    if (@existingTicketId IS NULL)
    begin
        insert into [dbo].[Notifications] ([Id], [LastUpdatedTime], [Data], [WorkItemID], [WorkItemURL], [TargetSystem], [Type])
        values (@Id, @LastUpdatedTime, @Data, @WorkItemID, @WorkItemURL, @TargetSystem, @Type)
    end
    else
    begin
        exec [dbo].[proc_UpdateNotification] @Id=@Id, @LastUpdatedTime=@LastUpdatedTime, @Data=@Data, @WorkItemID=@WorkItemID, @WorkItemURL=@WorkItemURL, @TargetSystem=@TargetSystem, @Type=@Type
    end
END
GO
/****** Object:  StoredProcedure [dbo].[proc_AddRoadmapNotification]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ====================================================
-- Author:		aldras
-- Create date: 12/16/2020
-- Modify date: 12/16/2020
-- Description:	Adds roadmap notification
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddRoadmapNotification]
    @Id nvarchar(64),
    @LastUpdatedTime datetime,
    @Data nvarchar(MAX),
    @WorkItemID nvarchar(128) = null,
    @WorkItemURL nvarchar(MAX) = null,
    @TargetSystem nvarchar(64) = null
AS
    BEGIN
        SET NOCOUNT ON;

        declare @existingTicketId as nvarchar(64) = (select [Id] from [dbo].[Roadmap] where [Id]=@Id)

        if (@existingTicketId IS NULL)
        begin
            insert into [dbo].[Roadmap] ([Id], [LastUpdatedTime], [Data], [WorkItemID], [WorkItemURL], [TargetSystem])
            values (@Id, @LastUpdatedTime, @Data, @WorkItemID, @WorkItemURL, @TargetSystem)
        end
        else
        begin
            exec [dbo].[proc_UpdateRoadmapNotification] @Id=@Id, @LastUpdatedTime=@LastUpdatedTime, @Data=@Data, @WorkItemID=@WorkItemID, @WorkItemURL=@WorkItemURL, @TargetSystem=@TargetSystem
        end
    END
GO
/****** Object:  StoredProcedure [dbo].[proc_RegisterRoadmapSyncHeartbeat]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ====================================================
-- Author:		aldras
-- Create date: 12/16/2020
-- Modify date: 12/16/2020
-- Description:	Updates last sync timestamp
-- ====================================================
CREATE PROCEDURE [dbo].[proc_RegisterRoadmapSyncHeartbeat]
AS
    BEGIN
        SET NOCOUNT ON;

        declare @heartbeatKey as nvarchar(32) = 'LastRoadmapSyncTimestamp'
        declare @existingHeartbeat as nvarchar(max) = (select [SerializedValue] from [dbo].[Config] where [Key]=@heartbeatKey)
        declare @syncTimestamp as nvarchar(max) = CONVERT(nvarchar(max), GETUTCDATE(), 127)

        if (@existingHeartbeat IS NULL)
        begin
            insert into [dbo].[Config] ([Key], [SerializedValue], [DataType])
            values (@heartbeatKey, @syncTimestamp, 'System.DateTime')
        end
        else
        begin
            UPDATE
                [dbo].[Config]
            SET
                [SerializedValue] = @syncTimestamp,
                [DataType] = 'System.DateTime'
            WHERE
                [Key] = @heartbeatKey
        end
    END
GO
/****** Object:  StoredProcedure [dbo].[proc_RegisterSyncHeartbeat]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ====================================================
-- Author:		aldras
-- Create date: 12/18/2018
-- Modify date: 11/08/2021
-- Description:	Updates last sync timestamp
-- ====================================================
CREATE PROCEDURE [dbo].[proc_RegisterSyncHeartbeat]
@CommunicationType nvarchar(128) = ''
AS
    BEGIN
        SET NOCOUNT ON;

        declare @heartbeatKey as nvarchar(256) = CONCAT('LastSync', @CommunicationType, 'Timestamp')
        declare @existingHeartbeat as nvarchar(max) = (select [SerializedValue] from [dbo].[Config] where [Key]=@heartbeatKey)
        declare @syncTimestamp as nvarchar(max) = CONVERT(nvarchar(max), GETUTCDATE(), 127)

        if (@existingHeartbeat IS NULL)
        begin
            insert into [dbo].[Config] ([Key], [SerializedValue], [DataType])
            values (@heartbeatKey, @syncTimestamp, 'System.DateTime')
        end
        else
        begin
            UPDATE
                [dbo].[Config]
            SET
                [SerializedValue] = @syncTimestamp,
                [DataType] = 'System.DateTime'
            WHERE
                [Key] = @heartbeatKey
        end
    END
GO
/****** Object:  StoredProcedure [dbo].[proc_UpdateNotification]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ====================================================
-- Author: aldras
-- Create date: 12/18/2018
-- Modify date: 11/05/2021
-- Description: Updates notification
-- ====================================================
CREATE PROCEDURE [dbo].[proc_UpdateNotification]
    @Id nvarchar(64),
    @LastUpdatedTime datetime,
    @Data nvarchar(MAX),
    @WorkItemID nvarchar(128) = null,
    @WorkItemURL nvarchar(MAX) = null,
    @TargetSystem nvarchar(64) = null,
    @Type nvarchar(32) = ''
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE
        [dbo].[Notifications]
    SET
        [LastUpdatedTime]=@LastUpdatedTime,
        [Data]=@Data,
        [WorkItemID]=@WorkItemID,
        [WorkItemURL]=@WorkItemURL,
        [TargetSystem]=@TargetSystem,
        [Type]=@Type
    WHERE
        [Id]=@Id
    END
GO
/****** Object:  StoredProcedure [dbo].[proc_UpdateRoadmapNotification]    Script Date: 23.12.2021 17:39:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ====================================================
-- Author:		aldras
-- Create date: 12/16/2020
-- Modify date: 12/16/2020
-- Description:	Updates roadmap notification
-- ====================================================
CREATE PROCEDURE [dbo].[proc_UpdateRoadmapNotification]
    @Id nvarchar(64),
    @LastUpdatedTime datetime,
    @Data nvarchar(MAX),
    @WorkItemID nvarchar(128) = null,
    @WorkItemURL nvarchar(MAX) = null,
    @TargetSystem nvarchar(64) = null
AS
    BEGIN
        SET NOCOUNT ON;

        UPDATE
            [dbo].[Roadmap]
        SET
            [LastUpdatedTime]=@LastUpdatedTime,
            [Data]=@Data,
            [WorkItemID]=@WorkItemID,
            [WorkItemURL]=@WorkItemURL,
            [TargetSystem]=@TargetSystem
        WHERE
            [Id]=@Id
    END
GO        
"@;
    #endregion

    hidden [void] m_InitializeUpgradeScripts()
    {
        ([SHHDatabase]$this).m_InitializeUpgradeScripts();
        
        $module = Get-Module M365ServiceHealthHubDB
        $this.m_modulePath = $module.ModuleBase;

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2507, 1),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("24550798-faac-4070-98e4-8f868e9bd702"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
    
-- =======================================================
-- Author: aldras
-- Create date: 07/09/2025
-- Modify date: 07/09/2025
-- Description: Add Client Policy Alert component
-- =======================================================
EXEC [dbo].[proc_AddComponent]
@Name='Client Policy Alert',
@InternalName='ClientPolicyAlert',
@Capabilities='[
    "Sync",
    "Routing",
    "Notifications",
    "TaskManagement"
]',
@EntityProperties='[
    { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
    { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
    { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
    { "displayName": "Last updated", "entityProperty": "LastModifiedDT", "type": "System.DateTime", "hidden": false },
    { "displayName": "Start time", "entityProperty": "StartTimeDT", "type": "System.DateTime", "hidden": false },
    { "displayName": "End time", "entityProperty": "EndTimeDT", "type": "System.DateTime", "hidden": false },
    { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
    { "displayName": "Title", "entityProperty": "OriginalTitle", "type": "System.String", "hidden": false },
    { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
    { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
    { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": true },
    { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false },
    { "displayName": "Type", "entityProperty": "Type", "type": "System.String", "hidden": false },
    { "displayName": "Source", "entityProperty": "Source", "type": "System.String", "hidden": false },
    { "displayName": "Resource", "entityProperty": "Resource", "type": "System.String", "hidden": false }, 
    { "displayName": "Status", "entityProperty": "Status", "type": "System.String", "hidden": false }
]'
GO

-- =======================================================
-- Author: aldras
-- Create date: 07/09/2025
-- Modify date: 07/09/2025
-- Description: Add Client Policy Alert
--              notification template 1/4
-- =======================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate]
    '099ef26c-3030-46a4-aa89-bff0efe679f8'
    ,'CLIENTPOLICYALERT'
    ,'notificationTemplate'
    ,'{
    "template": {
        "Content": {
            "Subject": "entity://NotificationTitle/translate",
            "Html": "entity://Description/translate"
        }
    }
}'
    ,'dbo'
GO

-- =======================================================
-- Author: aldras
-- Create date: 07/09/2025
-- Modify date: 07/09/2025
-- Description: Add Client Policy Alert
--              notification template 2/4
-- =======================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate]
    'e865a99d-44b2-4f3d-9c94-523c30fce3b0'
    ,'CLIENTPOLICYALERT'
    ,'notificationTemplate'
    ,'{
    "template": {
        "notificationType": "ClientPolicyAlert",
        "title": "entity://NotificationTitle/translate",
        "subtitle": "entity://Type,
        "componentImage": "route://icon",
        "properties": "",
        "description": "entity://Description/convertToPlainText/translate",
        "lastUpdate": "entity://LastModified/dateTimeToString",
        "workItemUrl": "",
        "teamId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=TeamId",
        "channelId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=ChannelId"
    }
    }'
    ,'dbo'
GO

-- =======================================================
-- Author: aldras
-- Create date: 07/09/2025
-- Modify date: 07/09/2025
-- Description: Add Client Policy Alert
--              notification template 3/4
-- =======================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'2b650c59-bc1b-429c-9da9-ae09ba576cc7'
,'CLIENTPOLICYALERT'
,'notificationTemplate'
,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "entity://Type",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://Description/translate?translate_html=true"
            },
            {
                "facts": [
                    {
                        "value": "entity://Source",
                        "name": "static://text/translate?value=Source"
                    },
                    {
                        "value": "entity://Resource",
                        "name": "static://text/translate?value=Resource"
                    },
                    {
                        "value": "entity://Type",
                        "name": "static://text/translate?value=Type"
                    },
                    {
                        "value": "entity://StartTimeDT",
                        "name": "static://text/translate?value=Start time"
                    },
                    {
                        "value": "entity://EndTimeDT",
                        "name": "static://text/translate?value=End time"
                    },
                    {
                        "value": "entity://LastModifiedDT",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            }
        ]
    }
}'
,'dbo'
GO

-- =======================================================
-- Author: aldras
-- Create date: 07/09/2025
-- Modify date: 07/09/2025
-- Description: Add Client Policy Alert
--              notification template 4/4
-- =======================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'CLIENTPOLICYALERT'
,'notificationTemplate'
,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "entity://Type",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://Description/translate?translate_html=true"
            },
            {
                "facts": [
                    {
                        "value": "entity://Source",
                        "name": "static://text/translate?value=Source"
                    },
                    {
                        "value": "entity://Resource",
                        "name": "static://text/translate?value=Resource"
                    },
                    {
                        "value": "entity://Type",
                        "name": "static://text/translate?value=Type"
                    },
                    {
                        "value": "entity://StartTimeDT",
                        "name": "static://text/translate?value=Start time"
                    },
                    {
                        "value": "entity://EndTimeDT",
                        "name": "static://text/translate?value=End time"
                    },
                    {
                        "value": "entity://LastModifiedDT",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            }
        ]
    }
}'
,'dbo'
GO
"@,
"Client Policy Sync."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2507, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("1605bd2d-45b9-485a-9f46-8bd9fbe31093"),
                @"
-- ====================================================
-- Author: aldras
-- Create date: 07/09/2025
-- Modify date: 07/09/2025
-- Description: Sets index flag to specified value
--              Flag values:
--              -1 = Mark item for reindexing
--               0 = Item not indexed
--               1 = Item indexed
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_SetIndexFlag]
    @Id nvarchar(64),
    @Flag int = 1
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE
        [dbo].[Notifications]
    SET
        [Indexed]=@Flag
    WHERE
        [Id]=@Id
    END
GO
"@,
"Added SetIndexFlag stored procedure."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2506, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("705cabd5-f635-4d7a-abc8-e2d5d60ed9a7"),
                @"
-- ====================================================
-- Author: aldras
-- Create date: 06/11/2025
-- Modify date: 06/11/2025
-- Description: Credentials table definition
-- ====================================================
CREATE TABLE [dbo].[Credentials](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [ObjectId] [uniqueidentifier] NOT NULL,
    [Name] [nvarchar](128) NOT NULL,
    [Type] [nvarchar](64) NOT NULL,
    [Description] [nvarchar](1024) NOT NULL,
    [Created] [datetime] NOT NULL,
    [Modified] [datetime] NOT NULL,
    [SerializedObject] [nvarchar](max) NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Credentials] ADD  CONSTRAINT [Credential_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [idx_CredentialType] ON [dbo].[Credentials]
(
    [Type] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [idx_CredentialObjectId] ON [dbo].[Credentials]
(
    [ObjectId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [idx_CredentialName] ON [dbo].[Credentials]
(
    [Name] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Credentials] ADD  DEFAULT (getutcdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Credentials] ADD  DEFAULT (getutcdate()) FOR [Modified]
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/11/2025
-- Modify date: 06/11/2025
-- Description: Adds or modifies credential
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddCredential]
    @ObjectId uniqueidentifier,
    @Name nvarchar(128) NOT NULL,
    @Type nvarchar(64) NOT NULL,
    @Description nvarchar(1024) NOT NULL,
    @SerializedObject nvarchar(max) NOT NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @existingCredentialId AS int = (SELECT [Id] FROM [dbo].[Credentials] WHERE [ObjectId]=@ObjectId)
    
    IF (@existingCredentialId IS NULL)
    BEGIN
        INSERT INTO 
            [dbo].[Credentials] ([ObjectId], [Name], [Type], [Description], [SerializedObject])
        VALUES 
            (@ObjectId, @Name, @Type, @Description, @SerializedObject)
    END ELSE
    BEGIN
        UPDATE 
            [dbo].[Credentials]
        SET
            [Name] = @Name,
            [Type] = @Type,
            [Description] = @Description,
            [SerializedObject] = @SerializedObject,
            [Modified] = GETUTCDATE()
        WHERE
            [Id] = @existingCredentialId
    END
END
GO
"@,
"Added Credentials table."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2411, 2),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("c5a93005-0af0-4b17-b83c-d5a7f4872f77"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION [dbo].[Compare_JsonObject] (@SourceJSON NVARCHAR(MAX), @TargetJSON NVARCHAR(MAX))
/**
Summary: >
  This function 'diffs' a source JSON document with a target JSON document and produces an
  analysis of which properties are missing in either the source or target, or the values
  of these properties that are different. It reports on the properties and values for 
  both source and target as well as the path that references that scalar value. The 
  path reference to the object's parent is exposed in the result to enable a query to
  reference the value of any other object in the parent that is needed. 
Author: Phil Factor
Date: 06/07/2020
Revised:
	- mod: Added the parent reference to the difference report
	- Date: 09/07/2020
Database: PhilsRoutines
Examples:
   - SELECT * FROM dbo.Compare_JsonObject(@TheSourceJSON, @TheTargetJSON)
       WHERE SideIndicator <> '==';
   - SELECT *, Json_Value(@TheSourceJSON,TheParent+'.name')
       FROM dbo.Compare_JsonObject(@TheSourceJSON, @TheTargetJSON)
       WHERE SideIndicator <> '==';
Returns: >
  SideIndicator:  ( == equal, <- not in target, ->  not in source, <> not equal
  ThePath:   the JSON path used by the SQL JSON functions 
  TheKey:  the key field without the path
  TheSourceValue: the value IN the SOURCE JSON document
  TheTargetValue: the value IN the TARGET JSON document
 
**/
RETURNS @returntable TABLE
  (
  SideIndicator CHAR(2), -- == means equal, <- means not in target, -> means not in source, <> means not equal
  TheParent  NVARCHAR(MAX), --the parent object
  ThePath NVARCHAR(MAX), -- the JSON path used by the SQL JSON functions 
  TheKey NVARCHAR(MAX), --the key field without the path
  TheSourceValue NVARCHAR(MAX), -- the value IN the SOURCE JSON document
  TheTargetValue NVARCHAR(MAX) -- the value IN the TARGET JSON document
  )
AS
  BEGIN
    IF (IsJson(@SourceJSON) = 1 AND IsJson(@TargetJSON) = 1) --don't try anything if either json is invalid
      BEGIN
        DECLARE @map TABLE --these contain all properties or array elements with scalar values
          (
          iteration INT, --the number of times that more arrays or objects were found
          SourceOrTarget CHAR(1), --is this the source 's' OR the target 't'
 		  TheParent NVARCHAR(MAX), --the parent object
		  ThePath NVARCHAR(MAX), -- the JSON path to the key/value pair or array element
          TheKey NVARCHAR(MAX), --the key to the property
          TheValue NVARCHAR(MAX),-- the value
          TheType INT --the type of value it is
          );
        DECLARE @objects TABLE --this contains all the properties with arrays and objects 
          (
          iteration INT,
          SourceOrTarget CHAR(1),
		  TheParent NVARCHAR(MAX),
          ThePath NVARCHAR(MAX),
          TheKey NVARCHAR(MAX),
          TheValue NVARCHAR(MAX),
          TheType INT
          );
        DECLARE @depth INT = 1; --we start in shallow water
        DECLARE @HowManyObjectsNext INT = 1, @SourceType INT, @TargetType INT;
        SELECT --firstly, we try to work out if the source is an array or object
          @SourceType = 
            CASE IsNumeric((SELECT TOP 1 [key] FROM OpenJson(@SourceJSON))) 
              WHEN 1 THEN 4 ELSE 5 END,
          @TargetType= --and if the target is an array or object
            CASE IsNumeric((SELECT TOP 1 [key] FROM OpenJson(@TargetJSON))) 
              WHEN 1 THEN 4 ELSE 5 END
        --now we insert the base objects or arrays into the object table      
        INSERT INTO @objects 
          (iteration, SourceOrTarget, TheParent, ThePath, TheKey, TheValue, TheType)
          SELECT 0, 's' AS SourceOrTarget,'' AS parent, '$' AS path, '', @SourceJSON, @SourceType;
        INSERT INTO @objects 
          (iteration, SourceOrTarget,TheParent, ThePath, TheKey, TheValue, TheType)
          SELECT 0, 't' AS SourceOrTarget, '' AS parent, '$' AS path,
          '', @TargetJSON, @TargetType;
        --we now set the depth and how many objects are in the next iteration
        SELECT @depth = 0, @HowManyObjectsNext = 2; 
        WHILE @HowManyObjectsNext > 0
          BEGIN
            INSERT INTO @map --get the scalar values into the @map table
              (iteration, SourceOrTarget, TheParent, ThePath, TheKey, TheValue, TheType)
              SELECT -- 
                o.iteration + 1, SourceOrTarget,
				ThePath,
                ThePath+CASE Thetype WHEN 4 THEN '['+[Key]+']' ELSE '.'+[key] END, 
                [key],[value],[type]
                FROM @objects AS o
                  CROSS APPLY OpenJson(TheValue)
                WHERE Type IN (1, 2, 3) AND o.iteration = @depth;
			--now we do the same for the objects and arrays
            INSERT INTO @objects (iteration, SourceOrTarget, TheParent, ThePath, TheKey,
            TheValue, TheType)
              SELECT o.iteration + 1, SourceOrTarget,ThePath,
               ThePath + CASE TheType WHEN 4 THEN '['+[Key]+']' ELSE '.'+[Key] END,
               [key],[value],[type]
              FROM @objects o 
			  CROSS APPLY OpenJson(TheValue) 
			  WHERE type IN (4,5) AND o.iteration=@depth    
           SELECT @HowManyObjectsNext=@@RowCount --how many objects or arrays?
           SELECT @depth=@depth+1 --and so to the next depth maybe
         END
--now we just do a full join on the columns we are comparing and work out the comparison
         INSERT INTO @returntable
          SELECT 
		   --first we work out the side-indicator that summarises the comparison
           CASE WHEN The_Source.TheValue=The_Target.TheValue THEN '=='
             ELSE 
             CASE  WHEN The_Source.ThePath IS NULL THEN '-' ELSE '<' end
               + CASE WHEN The_Target.ThePath IS NULL THEN '-' ELSE '>' END 
           END AS Sideindicator, 
		   --these columns could be in either table
		   Coalesce(The_source.TheParent, The_target.TheParent) AS TheParent,
           Coalesce(The_source.ThePath, The_target.ThePath) AS TheactualPath,
           Coalesce(The_source.TheKey, The_target.TheKey) AS TheKey,
           The_source.TheValue, The_target.TheValue
            FROM 
               (SELECT TheParent, ThePath, TheKey, TheValue FROM @map WHERE SourceOrTarget = 's')
			     AS The_source -- the source scalar literals
              FULL OUTER JOIN 
               (SELECT TheParent, ThePath, TheKey, TheValue FROM @map WHERE SourceOrTarget = 't')
			     AS The_target --the target scalar literals
                ON The_source.ThePath = The_target.ThePath
            ORDER BY TheactualPath;
      END;
    RETURN;
  END;
GO
"@,
"Bugfix, fixed JSON object diff function, caused by the paths longer than 80 characters."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2411, 1),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("11d3d7d1-3b55-4007-aa09-d31405d6a563"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =======================================================
-- Author: aldras
-- Create date: 11/15/2024
-- Modify date: 11/15/2024
-- Description: Update configuration definition for
--              Microsoft Search connector, add
--              SyncACL property
-- =======================================================
EXECUTE [dbo].[proc_AddConnectorTypeDefinition] 
    @ConnectorId = '4d7bed24-698e-47ce-ae13-44a15982906f'
    ,@Name = 'Microsoft Search'
    ,@Type = 'graphConnector'
    ,@Icon = '/images/search.png'
    ,@Unique = true
    ,@System = true
    ,@Hidden = true
    ,@Parameters = '[
        {
            "id": 1,
            "name": "Configured",
            "displayName": "Graph connector configured",
            "type": "boolean",
            "description": "",
            "parameterType": "configuration"
        },
        {
            "id": 2,
            "name": "Enabled",
            "displayName": "Graph connector enabled",
            "type": "boolean",
            "description": "",
            "parameterType": "configuration"
        },
        {
            "id": 3,
            "name": "SchemaUpdated",
            "displayName": "Graph connector schema updated timestamp",
            "type": "DateTime",
            "description": "",
            "parameterType": "configuration"
        },
        {
            "id": 4,
            "name": "RootUrl",
            "displayName": "Service Health Hub Root Url",
            "type": "string",
            "description": "",
            "parameterType": "configuration"
        },
        {
            "id": 5,
            "name": "SyncACL",
            "displayName": "Access control list",
            "type": "array",
            "description": "",
            "parameterType": "cache"
        }
]'
GO

-- =======================================================
-- Author: aldras
-- Create date: 11/15/2024
-- Modify date: 11/15/2024
-- Description: Update configuration for
--              Microsoft Search connector, add
--              SyncACL property
-- =======================================================
EXECUTE [dbo].[proc_AddConnector] 
    @ConnectorId = 'a6a162f4-4910-4c64-a5fd-18a01665c88d'
    ,@Name = 'Microsoft Search'
    ,@Type = '4d7bed24-698e-47ce-ae13-44a15982906f'
    ,@Configuration = '[
        {
            "name": "Configured",
            "value": false
        },
        {
            "name": "Enabled",
            "value": false
        },
        {
            "name": "SchemaUpdated",
            "value": "2000-01-01T00:00:00"
        },
        {
            "name": "RootUrl",
            "value": ""
        },
        {
            "name": "SyncACL",
            "value": []
        }
    ]'
GO
"@,
"Updated Microsoft Search connector, add SyncACL property."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2411, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("03c33154-79ec-4396-bb77-09c317dd1d82"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =======================================================
-- Author: aldras
-- Create date: 10/14/2024
-- Modify date: 11/04/2024
-- Description: Reset index flag on all communications
--              This will retrigger full index of current
--              items
-- =======================================================
CREATE OR ALTER PROCEDURE [dbo].[ResetIndexFlag]
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE [dbo].[Notifications] SET [Indexed]=-1 WHERE [Indexed]=1
END
GO
"@,
"Added full index trigger."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2409, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("e8b69b81-5543-4ca7-bb01-371ea0e08970"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =======================================================
-- Author: aldras
-- Create date: 07/19/2024
-- Modify date: 11/15/2024
-- Description: New Graph Connector schema
-- =======================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'4d7bed24-698e-47ce-ae13-44a15982906f'
,'search'
,'schema'
,'{
    "baseType": "microsoft.graph.externalItem",
    "properties": [
        {
            "name": "id",
            "type": "string",
            "isSearchable": true,
            "isRetrievable": true,
            "isQueryable": true
        },
        {
            "name": "title",
            "type": "string",
            "isSearchable": true,
            "isRetrievable": true,
            "labels": [
                "title"
            ]
        },
        {
            "name": "iconUrl",
            "type": "string",
            "isRetrievable": true,
            "labels": [
                "iconUrl"
            ]
        },
        {
            "name": "url",
            "type": "string",
            "isSearchable": true,
            "isRetrievable": true,
            "labels": [
                "url"
            ]
        },
        {
            "name": "summary",
            "type": "string",
            "isSearchable": true,
            "isRetrievable": true
        },
        {
            "name": "content",
            "type": "string",
            "isSearchable": true,
            "isRetrievable": true
        },
        {
            "name": "source",
            "type": "string",
            "isSearchable": false,
            "isRetrievable": true,
            "isQueryable": true,
            "isRefinable": true
        },
        {
            "name": "status",
            "type": "string",
            "isSearchable": false,
            "isRetrievable": true,
            "isQueryable": true,
            "isRefinable": true
        },
        {
            "name": "expirationDate",
            "type": "dateTime",
            "isSearchable": false,
            "isRetrievable": true,
            "isQueryable": true
        },
        {
            "name": "resources",
            "type": "stringCollection",
            "isSearchable": false,
            "isRetrievable": true,
            "isQueryable": true,
            "isRefinable": true
        },
        {
            "name": "startTime",
            "type": "dateTime",
            "isSearchable": false,
            "isRetrievable": true,
            "isQueryable": true,
            "isRefinable": true
        },
        {
            "name": "endTime",
            "type": "dateTime",
            "isSearchable": false,
            "isRetrievable": true,
            "isQueryable": true
        },
        {
            "name": "tags",
            "type": "stringCollection",
            "isSearchable": false,
            "isRetrievable": true,
            "isQueryable": true,
            "isRefinable": true
        },
        {
            "name": "lastUpdate",
            "type": "dateTime",
            "isSearchable": false,
            "isRetrievable": true,
            "isQueryable": true,
            "labels": [
                "lastModifiedDateTime"
            ],
            "isRefinable": true
        }
    ]
}'
,'dbo'
GO
"@,
"Updated Graph Connector (search) schema."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2407, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("3d15644b-9bec-4e43-9724-aedb1b0ccf1c"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

EXECUTE [dbo].[proc_AddConnectorTypeDefinition] 
    @ConnectorId = 'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,@Name = 'Workflow via Power Automate'
    ,@Type = 'notificationManager'
    ,@Icon = '/images/workflow.png'
    ,@Unique = true
    ,@System = true
    ,@Hidden = false
    ,@Parameters = '[
            {
                "id": 100,
                "name": "TeamsWorkflowUri",
                "displayName": "Teams workflow url",
                "type": "string",
                "description": "Enter the url of the Teams workflow",
                "parameterType": "routing"
            }
        ]'
GO

EXECUTE [dbo].[proc_AddConnectorTypeDefinition] 
   @ConnectorId = '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
  ,@Name = 'Teams (via WebHook - deprecated)'
  ,@Type = 'notificationManager'
  ,@Icon = '/images/teams.png'
  ,@Unique = true
  ,@System = true
  ,@Hidden = false
  ,@Parameters = '[
            {
                "id": 100,
                "name": "TeamsChannelUri",
                "displayName": "Teams channel incoming webhook url",
                "type": "string",
                "description": "Enter the url of the Teams channel",
                "parameterType": "routing"
            }
        ]'
GO

EXECUTE [dbo].[proc_AddConnector] 
    @ConnectorId = 'a6bb0207-74d1-4094-a808-42a6fdd9d31d'
    ,@Name = 'Incoming Webhook via Power Automate'
    ,@Type = 'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,@Configuration = '[]'
GO

EXECUTE [dbo].[proc_AddConnector] 
   @ConnectorId = 'e3990fbe-4fb9-4967-884c-2dc76ac819f4'
  ,@Name = 'Incoming Webhook (deprecated)'
  ,@Type = '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
  ,@Configuration = '[]'
GO
    
-- ========================================================
-- Author: aldras
-- Create date: 07/12/2024
-- Modify date: 07/15/2024
-- Description: New Message Center notification template
-- ========================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'SERVICEUPDATEMESSAGE'
,'notificationTemplate'
,'{
    "template" : {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": null,
                "content": {
                    "type": "AdaptiveCard",
                    "`$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version": "1.4",
                    "msteams": {
                        "width": "Full"
                    },
                    "body": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "64px",
                                    "items": [
                                        {
                                            "type": "Image",
                                            "url": "route://icon"
                                        }
                                    ],
                                    "horizontalAlignment": "Center"
                                },
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": "entity://NotificationTitle/translate",
                                            "wrap": true,
                                            "size": "Large",
                                            "weight": "Bolder",
                                            "spacing": "Large"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": "Microsoft 365 Message Center",
                                            "wrap": true,
                                            "size": "Small",
                                            "weight": "Normal",
                                            "spacing": "Small",
                                            "horizontalAlignment": "Left"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Services and tasks",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up0",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down0",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Large",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Services and tasks",
                                "targetElements": [
                                    "a0",
                                    "chevron_up0",
                                    "chevron_down0"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\u2699\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Services",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Services",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\u2757\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Major change",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://MajorChange/BoolToYesNoString",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udccb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Task",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://TaskMarkdownLink",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udf9f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Tags",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Tags",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        }
                                    ]
                                }
                            ],
                            "id": "a0",
                            "isVisible": false,
                            "spacing": "Small"
                        },
                        {
                            "type": "Container",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Summary",
                                "targetElements": [
                                    "a1",
                                    "chevron_up1",
                                    "chevron_down1"
                                ]
                            },
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "wrap": true,
                                                    "text": "Summary",
                                                    "weight": "Bolder",
                                                    "spacing": "Large",
                                                    "separator": true
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "verticalContentAlignment": "Center",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up1"
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down1",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "isVisible": false
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "verticalContentAlignment": "Center",
                            "minHeight": "30px",
                            "style": "emphasis"
                        },
                        {
                            "type": "Container",
                            "id": "a1",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://Summary/translate/ToAdaptiveCardElements"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "spacing": "None",
                                    "minHeight": "24px"
                                }
                            ]
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Details",
                                                    "wrap": true,
                                                    "separator": true,
                                                    "spacing": "Large",
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up2",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down2",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "style": "emphasis",
                            "spacing": "Small",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "q2",
                                "targetElements": [
                                    "a2",
                                    "chevron_up2",
                                    "chevron_down2"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://Description/translate/ToAdaptiveCardElements"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "isVisible": false,
                            "id": "a2"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Resources",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up6",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down6",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Small",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "q6",
                                "targetElements": [
                                    "a6",
                                    "chevron_up6",
                                    "chevron_down6"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "entity://ResourcesMarkdownLinks/translate",
                                                    "wrap": true,
                                                    "spacing": "Medium"
                                                }
                                            ]
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "id": "a6",
                            "isVisible": false
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Timeline (UTC)",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up5",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down5",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Small",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "q5",
                                "targetElements": [
                                    "a5",
                                    "chevron_up5",
                                    "chevron_down5"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udce6",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Release state",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://ReleaseState",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd50",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Start time",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://StartTime",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd58",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=End time",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://EndTime",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\u2668\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Action required by",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://ActionRequiredBy",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd8b",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Last update",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://LastModified",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        }
                                    ]
                                }
                            ],
                            "id": "a5",
                            "isVisible": false,
                            "spacing": "Small"
                        }
                    ]
                }
            }
        ]
    }
}'
,'dbo'
GO

-- ========================================================
-- Author: aldras
-- Create date: 07/15/2024
-- Modify date: 07/15/2024
-- Description: New Service Health notification template
-- ========================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'SERVICEHEALTHISSUE'
,'notificationTemplate'
,'{
    "template" : {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": null,
                "content": {
                    "type": "AdaptiveCard",
                    "`$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version": "1.4",
                    "msteams": {
                        "width": "Full"
                    },
                    "body": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "64px",
                                    "items": [
                                        {
                                            "type": "Image",
                                            "url": "route://icon"
                                        }
                                    ],
                                    "horizontalAlignment": "Center"
                                },
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": "entity://NotificationTitle/translate",
                                            "wrap": true,
                                            "size": "Large",
                                            "weight": "Bolder",
                                            "spacing": "Large"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": "Microsoft 365 Service Health",
                                            "wrap": true,
                                            "size": "Small",
                                            "weight": "Normal",
                                            "spacing": "Small",
                                            "horizontalAlignment": "Left"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Services and tasks",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up0",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down0",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Large",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Services and tasks",
                                "targetElements": [
                                    "a0",
                                    "chevron_up0",
                                    "chevron_down0"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\u2699\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Services",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Service",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udfdb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Origin",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Origin/translate",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udee0",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Resolved",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Resolved/BoolToYesNoString",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udccb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Task",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://TaskMarkdownLink",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udf9f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Tags",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Tags",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        }
                                    ]
                                }
                            ],
                            "id": "a0",
                            "isVisible": false,
                            "spacing": "Small"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Details",
                                                    "wrap": true,
                                                    "separator": true,
                                                    "spacing": "Large",
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up2",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down2",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "style": "emphasis",
                            "spacing": "Small",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "q2",
                                "targetElements": [
                                    "a2",
                                    "chevron_up2",
                                    "chevron_down2"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://Description/translate/ToAdaptiveCardElements"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "isVisible": true,
                            "id": "a2"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Timeline (UTC)",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up5",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down5",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Small",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "q5",
                                "targetElements": [
                                    "a5",
                                    "chevron_up5",
                                    "chevron_down5"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd50",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Start time",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://StartTime",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd58",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=End time",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://EndTime",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd8b",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Last update",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://LastModified",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        }
                                    ]
                                }
                            ],
                            "id": "a5",
                            "isVisible": false,
                            "spacing": "Small"
                        }
                    ]
                }
            }
        ]
    }
}'
,'dbo'
GO

-- ========================================================
-- Author: aldras
-- Create date: 07/15/2024
-- Modify date: 07/15/2024
-- Description: New Roadmap Communication notification template
-- ========================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'ROADMAPCOMMUNICATION'
,'notificationTemplate'
,'{
    "template" : {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": null,
                "content": {
                    "type": "AdaptiveCard",
                    "`$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version": "1.4",
                    "msteams": {
                        "width": "Full"
                    },
                    "body": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "64px",
                                    "items": [
                                        {
                                            "type": "Image",
                                            "url": "route://icon"
                                        }
                                    ],
                                    "horizontalAlignment": "Center"
                                },
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": "entity://NotificationTitle/translate",
                                            "wrap": true,
                                            "size": "Large",
                                            "weight": "Bolder",
                                            "spacing": "Large"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": "Microsoft 365 Roadmap",
                                            "wrap": true,
                                            "size": "Small",
                                            "weight": "Normal",
                                            "spacing": "Small",
                                            "horizontalAlignment": "Left"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Products and tasks",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up0",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down0",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Large",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Services and tasks",
                                "targetElements": [
                                    "a0",
                                    "chevron_up0",
                                    "chevron_down0"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\u2699\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Products",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Products",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udfdb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Platforms",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Platforms",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udee0",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Cloud instances",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://CloudInstances",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udce6",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Release phase",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://ReleasePhase",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udccb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Task",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://TaskMarkdownLink",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udf9f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Category",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Category",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Padding"
                                        }
                                    ]
                                }
                            ],
                            "id": "a0",
                            "isVisible": false,
                            "spacing": "Small"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Details",
                                                    "wrap": true,
                                                    "separator": true,
                                                    "spacing": "Large",
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up2",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down2",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "style": "emphasis",
                            "spacing": "Small",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "q2",
                                "targetElements": [
                                    "a2",
                                    "chevron_up2",
                                    "chevron_down2"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://Description/translate/ToAdaptiveCardElements"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "isVisible": true,
                            "id": "a2"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Additional information",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up5",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down5",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Small",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Additional information",
                                "targetElements": [
                                    "a5",
                                    "chevron_up5",
                                    "chevron_down5"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udd94",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Feature ID",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Id",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udcc5",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Public preview",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://PublicPreview",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udcc5",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=General availability",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Availability",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udcdd",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Published",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Published",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd8b",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Last updated",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://LastModified",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        }
                                    ]
                                }
                            ],
                            "id": "a5",
                            "isVisible": false,
                            "spacing": "Small"
                        }
                    ]
                }
            }
        ]
    }
}'
,'dbo'
GO

-- ========================================================
-- Author: aldras
-- Create date: 07/16/2024
-- Modify date: 07/16/2024
-- Description: New Service Health Hub Release
--              notification template
-- ========================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'RELEASEMESSAGE'
,'notificationTemplate'
,'{
    "template" : {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": null,
                "content": {
                    "type": "AdaptiveCard",
                    "`$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version": "1.4",
                    "msteams": {
                        "width": "Full"
                    },
                    "body": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "64px",
                                    "items": [
                                        {
                                            "type": "Image",
                                            "url": "route://icon"
                                        }
                                    ],
                                    "horizontalAlignment": "Center"
                                },
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": "entity://NotificationTitle/translate",
                                            "wrap": true,
                                            "size": "Large",
                                            "weight": "Bolder",
                                            "spacing": "Large"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": "Microsoft Service Health Hub",
                                            "wrap": true,
                                            "size": "Small",
                                            "weight": "Normal",
                                            "spacing": "Small",
                                            "horizontalAlignment": "Left"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Details",
                                                    "wrap": true,
                                                    "separator": true,
                                                    "spacing": "Large",
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up2",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down2",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "style": "emphasis",
                            "spacing": "Small",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "q2",
                                "targetElements": [
                                    "a2",
                                    "chevron_up2",
                                    "chevron_down2"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://Description/translate/ToAdaptiveCardElements"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "isVisible": true,
                            "id": "a2"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Additional information",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up5",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down5",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Small",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Additional information",
                                "targetElements": [
                                    "a5",
                                    "chevron_up5",
                                    "chevron_down5"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udd94",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=ID",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Id",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udf9f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Tags",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Tags",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udccb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Task",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://TaskMarkdownLink",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udcc5",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Release date",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://ReleaseDate",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\u2668\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Action required by",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://ActionRequiredBy",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd8b",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Last updated",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://LastModified",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        }
                                    ]
                                }
                            ],
                            "id": "a5",
                            "isVisible": false,
                            "spacing": "Small"
                        }
                    ]
                }
            }
        ]
    }
}'
,'dbo'
GO

-- ========================================================
-- Author: aldras
-- Create date: 07/16/2024
-- Modify date: 07/16/2024
-- Description: New Azure Service Health Alert
--              notification template
-- ========================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'AZURESERVICEHEALTHALERT'
,'notificationTemplate'
,'{
    "template" : {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": null,
                "content": {
                    "type": "AdaptiveCard",
                    "`$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version": "1.4",
                    "msteams": {
                        "width": "Full"
                    },
                    "body": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "64px",
                                    "items": [
                                        {
                                            "type": "Image",
                                            "url": "route://icon"
                                        }
                                    ],
                                    "horizontalAlignment": "Center"
                                },
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": "entity://NotificationTitle/translate",
                                            "wrap": true,
                                            "size": "Large",
                                            "weight": "Bolder",
                                            "spacing": "Large"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": "Azure Service Health Alert",
                                            "wrap": true,
                                            "size": "Small",
                                            "weight": "Normal",
                                            "spacing": "Small",
                                            "horizontalAlignment": "Left"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Additional information",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up5",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down5",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Small",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Additional information",
                                "targetElements": [
                                    "a5",
                                    "chevron_up5",
                                    "chevron_down5"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udd94",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=ID",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Id",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\u2757\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Severity",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Severity",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\uddc2\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Subscriptions",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://SubscriptionsTextList",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udf9f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Tags",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Tags",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udccb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Task",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://TaskMarkdownLink",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd50",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Start time",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://StartTime",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd58",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=End time",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://EndTime",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd8b",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Last update",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://LastModified",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        }
                                    ]
                                }
                            ],
                            "id": "a5",
                            "isVisible": false,
                            "spacing": "Small"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Details",
                                                    "wrap": true,
                                                    "separator": true,
                                                    "spacing": "Large",
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up2",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down2",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "style": "emphasis",
                            "spacing": "Small",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "q2",
                                "targetElements": [
                                    "a2",
                                    "chevron_up2",
                                    "chevron_down2"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://Description/translate/ToAdaptiveCardElements"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "isVisible": true,
                            "id": "a2"
                        }
                    ]
                }
            }
        ]
    }
}'
,'dbo'
GO

-- ========================================================
-- Author: aldras
-- Create date: 07/16/2024
-- Modify date: 07/16/2024
-- Description: Microsoft 365 URL/IP Change Alert
--              notification template
-- ========================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'OFFICE365ENDPOINTSCHANGE'
,'notificationTemplate'
,'{
    "template" : {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": null,
                "content": {
                    "type": "AdaptiveCard",
                    "`$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version": "1.4",
                    "msteams": {
                        "width": "Full"
                    },
                    "body": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "64px",
                                    "items": [
                                        {
                                            "type": "Image",
                                            "url": "route://icon"
                                        }
                                    ],
                                    "horizontalAlignment": "Center"
                                },
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": "entity://NotificationTitle/translate",
                                            "wrap": true,
                                            "size": "Large",
                                            "weight": "Bolder",
                                            "spacing": "Large"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": "Microsoft 365 URL/IP Change",
                                            "wrap": true,
                                            "size": "Small",
                                            "weight": "Normal",
                                            "spacing": "Small",
                                            "horizontalAlignment": "Left"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Additional information",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up5",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down5",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Small",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Additional information",
                                "targetElements": [
                                    "a5",
                                    "chevron_up5",
                                    "chevron_down5"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udd94",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=ID",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Id",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd22",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Version",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Version",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\u2699\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Service area",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://ServiceArea",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\u2733\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Disposition",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Disposition",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udca5",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Impact",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Impact",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udf9f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Tags",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Tags",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udccb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Task",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://TaskMarkdownLink",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\u2668\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Action required by",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://ActionRequiredBy",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd8b",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Last update",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://LastModified",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        }
                                    ]
                                }
                            ],
                            "id": "a5",
                            "isVisible": false,
                            "spacing": "Small"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Details",
                                                    "wrap": true,
                                                    "separator": true,
                                                    "spacing": "Large",
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up2",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down2",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "style": "emphasis",
                            "spacing": "Small",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "q2",
                                "targetElements": [
                                    "a2",
                                    "chevron_up2",
                                    "chevron_down2"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://Description/translate/ToAdaptiveCardElements"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "isVisible": true,
                            "id": "a2"
                        }
                    ]
                }
            }
        ]
    }
}'
,'dbo'
GO

-- ========================================================
-- Author: aldras
-- Create date: 07/16/2024
-- Modify date: 07/16/2024
-- Description: Azure Update notification template
-- ========================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'AZUREUPDATE'
,'notificationTemplate'
,'{
    "template" : {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": null,
                "content": {
                    "type": "AdaptiveCard",
                    "`$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version": "1.4",
                    "msteams": {
                        "width": "Full"
                    },
                    "body": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "64px",
                                    "items": [
                                        {
                                            "type": "Image",
                                            "url": "route://icon"
                                        }
                                    ],
                                    "horizontalAlignment": "Center"
                                },
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": "entity://NotificationTitle/translate",
                                            "wrap": true,
                                            "size": "Large",
                                            "weight": "Bolder",
                                            "spacing": "Large"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": "Azure Update",
                                            "wrap": true,
                                            "size": "Small",
                                            "weight": "Normal",
                                            "spacing": "Small",
                                            "horizontalAlignment": "Left"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Additional information",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up5",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down5",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Small",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Additional information",
                                "targetElements": [
                                    "a5",
                                    "chevron_up5",
                                    "chevron_down5"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udd94",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=ID",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Id",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udf9f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Tags",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Tags",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udccb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Task",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://TaskMarkdownLink",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\uddde\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Blog article",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://ArticleMarkdownLink",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udce6",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Release status",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://ReleaseStatus",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udcdd",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Published",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Published",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        }
                                    ]
                                }
                            ],
                            "id": "a5",
                            "isVisible": false,
                            "spacing": "Small"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Details",
                                                    "wrap": true,
                                                    "separator": true,
                                                    "spacing": "Large",
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up2",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down2",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "style": "emphasis",
                            "spacing": "Small",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "q2",
                                "targetElements": [
                                    "a2",
                                    "chevron_up2",
                                    "chevron_down2"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://Description/translate/ToAdaptiveCardElements"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "isVisible": true,
                            "id": "a2"
                        }
                    ]
                }
            }
        ]
    }
}'
,'dbo'
GO

-- ========================================================
-- Author: aldras
-- Create date: 07/16/2024
-- Modify date: 07/16/2024
-- Description: Microsoft Service Health Hub System Alert
--              notification template
-- ========================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'SYSTEMALERT'
,'notificationTemplate'
,'{
    "template" : {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": null,
                "content": {
                    "type": "AdaptiveCard",
                    "`$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version": "1.4",
                    "msteams": {
                        "width": "Full"
                    },
                    "body": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "64px",
                                    "items": [
                                        {
                                            "type": "Image",
                                            "url": "route://icon"
                                        }
                                    ],
                                    "horizontalAlignment": "Center"
                                },
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": "entity://NotificationTitle",
                                            "wrap": true,
                                            "size": "Large",
                                            "weight": "Bolder",
                                            "spacing": "Large"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": "Microsoft Service Health Hub",
                                            "wrap": true,
                                            "size": "Small",
                                            "weight": "Normal",
                                            "spacing": "Small",
                                            "horizontalAlignment": "Left"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Additional information",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up5",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down5",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Small",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Additional information",
                                "targetElements": [
                                    "a5",
                                    "chevron_up5",
                                    "chevron_down5"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udff7\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/void?value=Type",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://AlertType",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\uddc4\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/void?value=Source",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Source",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udd94",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/void?value=Communication ID",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://CommunicationID",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\uddc2\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/void?value=Communication type",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://CommunicationType",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd25",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/void?value=Fired at",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Timestamp",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        }
                                    ]
                                }
                            ],
                            "id": "a5",
                            "isVisible": false,
                            "spacing": "Small"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Details",
                                                    "wrap": true,
                                                    "separator": true,
                                                    "spacing": "Large",
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up2",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down2",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "style": "emphasis",
                            "spacing": "Small",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "q2",
                                "targetElements": [
                                    "a2",
                                    "chevron_up2",
                                    "chevron_down2"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://AdaptiveCardBody"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "isVisible": true,
                            "id": "a2"
                        }
                    ]
                }
            }
        ]
    }
}'
,'dbo'
GO

-- ========================================================
-- Author: aldras
-- Create date: 07/16/2024
-- Modify date: 07/16/2024
-- Description: Dynamics 365 and Power Platform Release
--              notification template
-- ========================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'D365POWERPLATFORMRELEASE'
,'notificationTemplate'
,'{
    "template" : {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": null,
                "content": {
                    "type": "AdaptiveCard",
                    "`$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version": "1.4",
                    "msteams": {
                        "width": "Full"
                    },
                    "body": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "64px",
                                    "items": [
                                        {
                                            "type": "Image",
                                            "url": "route://icon"
                                        }
                                    ],
                                    "horizontalAlignment": "Center"
                                },
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": "entity://NotificationTitle/translate",
                                            "wrap": true,
                                            "size": "Large",
                                            "weight": "Bolder",
                                            "spacing": "Large"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": "Dynamics 365 and Power Platform Release Planner",
                                            "wrap": true,
                                            "size": "Small",
                                            "weight": "Normal",
                                            "spacing": "Small",
                                            "horizontalAlignment": "Left"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Additional information",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up5",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down5",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Small",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Additional information",
                                "targetElements": [
                                    "a5",
                                    "chevron_up5",
                                    "chevron_down5"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udce6",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Product",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Product",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\u2699\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Feature type",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://FeatureType",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udc64",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Enabled for",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://EnabledFor",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udccb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Early access",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://EarlyAccessStatus",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udccb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Public preview",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://PublicPreviewStatus",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udccb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=General availability",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://GAStatus",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udf9f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Tags",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Tags",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udccb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Task",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://TaskMarkdownLink",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd8b",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Last update",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://LastUpdate",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        }
                                    ]
                                }
                            ],
                            "id": "a5",
                            "isVisible": false,
                            "spacing": "Small"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Business value",
                                                    "wrap": true,
                                                    "separator": true,
                                                    "spacing": "Large",
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up2",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down2",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "style": "emphasis",
                            "spacing": "Small",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Business Value",
                                "targetElements": [
                                    "a2",
                                    "chevron_up2",
                                    "chevron_down2"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://BusinessValue/translate/ToAdaptiveCardElements"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "isVisible": true,
                            "id": "a2"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Details",
                                                    "wrap": true,
                                                    "separator": true,
                                                    "spacing": "Large",
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up3",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down3",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "style": "emphasis",
                            "spacing": "Small",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Details",
                                "targetElements": [
                                    "a3",
                                    "chevron_up3",
                                    "chevron_down3"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://Description/translate/ToAdaptiveCardElements"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "isVisible": false,
                            "id": "a3"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Resources",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up6",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down6",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Small",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "q6",
                                "targetElements": [
                                    "a6",
                                    "chevron_up6",
                                    "chevron_down6"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://ResourcesHtml/translate/ToAdaptiveCardElements"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "id": "a6",
                            "isVisible": false
                        }
                    ]
                }
            }
        ]
    }
}'
,'dbo'
GO

-- ========================================================
-- Author: aldras
-- Create date: 07/16/2024
-- Modify date: 07/16/2024
-- Description: Common Data Connector Alert V1
--              notification template
-- ========================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'COMMONDATACONNECTORALERTV1'
,'notificationTemplate'
,'{
    "template" : {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": null,
                "content": {
                    "type": "AdaptiveCard",
                    "`$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version": "1.4",
                    "msteams": {
                        "width": "Full"
                    },
                    "body": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "64px",
                                    "items": [
                                        {
                                            "type": "Image",
                                            "url": "route://icon"
                                        }
                                    ],
                                    "horizontalAlignment": "Center"
                                },
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": "entity://NotificationTitle/translate",
                                            "wrap": true,
                                            "size": "Large",
                                            "weight": "Bolder",
                                            "spacing": "Large"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": "entity://Source",
                                            "wrap": true,
                                            "size": "Small",
                                            "weight": "Normal",
                                            "spacing": "Small",
                                            "horizontalAlignment": "Left"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Additional information",
                                                    "wrap": true,
                                                    "spacing": "Large",
                                                    "separator": true,
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up5",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down5",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ],
                                            "verticalContentAlignment": "Center"
                                        }
                                    ]
                                }
                            ],
                            "spacing": "Small",
                            "style": "emphasis",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Additional information",
                                "targetElements": [
                                    "a5",
                                    "chevron_up5",
                                    "chevron_down5"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "Container",
                                    "style": "default",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udd94",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=ID",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Id",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\u2699\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Type",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Type",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udca1",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Status",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Status",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udda5\ufe0f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Resource",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Resource",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd50",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Start time",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://StartTime",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd58",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=End time",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://EndTime",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83c\udf9f",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Tags",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://Tags",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udccb",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Task",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://TaskMarkdownLink",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": 8,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "\ud83d\udd8b",
                                                            "wrap": true,
                                                            "horizontalAlignment": "Center"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "static://text/translate?value=Last update",
                                                            "wrap": true,
                                                            "weight": "Bolder"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": 50,
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "entity://LastModified",
                                                            "wrap": true,
                                                            "size": "Small",
                                                            "isSubtle": true
                                                        }
                                                    ]
                                                }
                                            ],
                                            "separator": true,
                                            "spacing": "Medium"
                                        }
                                    ]
                                }
                            ],
                            "id": "a5",
                            "isVisible": false,
                            "spacing": "Small"
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": [
                                                {
                                                    "type": "TextBlock",
                                                    "text": "Details",
                                                    "wrap": true,
                                                    "separator": true,
                                                    "spacing": "Large",
                                                    "weight": "Bolder"
                                                }
                                            ]
                                        },
                                        {
                                            "type": "Column",
                                            "width": "28px",
                                            "items": [
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-up.png",
                                                    "width": "20px",
                                                    "height": "20px",
                                                    "id": "chevron_up2",
                                                    "isVisible": false
                                                },
                                                {
                                                    "type": "Image",
                                                    "url": "https://raw.githubusercontent.com/pnp/AdaptiveCards-Templates/main/samples/faq-accordion/assets/ico-down.png",
                                                    "id": "chevron_down2",
                                                    "width": "20px",
                                                    "height": "20px"
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "style": "emphasis",
                            "spacing": "Small",
                            "selectAction": {
                                "type": "Action.ToggleVisibility",
                                "title": "Details",
                                "targetElements": [
                                    "a2",
                                    "chevron_up2",
                                    "chevron_down2"
                                ]
                            }
                        },
                        {
                            "type": "Container",
                            "items": [
                                {
                                    "type": "ColumnSet",
                                    "columns": [
                                        {
                                            "type": "Column",
                                            "width": "8px"
                                        },
                                        {
                                            "type": "Column",
                                            "width": "stretch",
                                            "items": "entity://Description/translate/ToAdaptiveCardElements"
                                        }
                                    ]
                                },
                                {
                                    "type": "Container",
                                    "minHeight": "24px"
                                }
                            ],
                            "isVisible": true,
                            "id": "a2"
                        }
                    ]
                }
            }
        ]
    }
}'
,'dbo'
GO
"@,
"New Teams Workflow notification connectors and templates"
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2405, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("b364b13c-8488-43ee-9a76-cc64090302ee"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
    
-- ========================================================
-- Author: aldras
-- Create date: 05/08/2024
-- Modify date: 05/08/2024
-- Description: Add Indexing field to communications record
-- ========================================================
ALTER TABLE [dbo].[Notifications] ADD [Indexed] SMALLINT DEFAULT 0
GO

-- ====================================================
-- Author: aldras
-- Create date: 12/18/2018
-- Modify date: 05/08/2024
-- Description: Adds notification information
-- ====================================================
ALTER PROCEDURE [dbo].[proc_AddNotification]
    @Id nvarchar(64),
    @LastUpdatedTime datetime,
    @Data nvarchar(MAX),
    @WorkItemID nvarchar(128) = null,
    @WorkItemURL nvarchar(MAX) = null,
    @TargetSystem nvarchar(64) = null,
    @Type nvarchar(32) = ''
AS
BEGIN
    SET NOCOUNT ON;
    declare @existingTicketId as nvarchar(64) = (select [Id] from [dbo].[Notifications] where [Id]=@Id)

    if (@existingTicketId IS NULL)
    begin
        insert into [dbo].[Notifications] ([Id], [LastUpdatedTime], [Data], [WorkItemID], [WorkItemURL], [TargetSystem], [Type], [Indexed])
        values (@Id, @LastUpdatedTime, @Data, @WorkItemID, @WorkItemURL, @TargetSystem, @Type, 0)
    end
    else
    begin
        exec [dbo].[proc_UpdateNotification] @Id=@Id, @LastUpdatedTime=@LastUpdatedTime, @Data=@Data, @WorkItemID=@WorkItemID, @WorkItemURL=@WorkItemURL, @TargetSystem=@TargetSystem, @Type=@Type
    end
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 12/18/2018
-- Modify date: 05/08/2024
-- Description: Updates notification
-- ====================================================
ALTER PROCEDURE [dbo].[proc_UpdateNotification]
    @Id nvarchar(64),
    @LastUpdatedTime datetime,
    @Data nvarchar(MAX),
    @WorkItemID nvarchar(128) = null,
    @WorkItemURL nvarchar(MAX) = null,
    @TargetSystem nvarchar(64) = null,
    @Type nvarchar(32) = ''
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE
        [dbo].[Notifications]
    SET
        [LastUpdatedTime]=@LastUpdatedTime,
        [Data]=@Data,
        [WorkItemID]=@WorkItemID,
        [WorkItemURL]=@WorkItemURL,
        [TargetSystem]=@TargetSystem,
        [Type]=@Type,
        [Indexed]=0
    WHERE
        [Id]=@Id
    END
GO

-- ====================================================
-- Author: aldras
-- Create date: 05/08/2024
-- Modify date: 05/08/2024
-- Description: Updates notification
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_RegisterIndexEvent]
    @Id nvarchar(64)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE
        [dbo].[Notifications]
    SET
        [Indexed]=1
    WHERE
        [Id]=@Id
    END
GO

-- ====================================================
-- Author: aldras
-- Create date: 02/10/2023
-- Modify date: 05/08/2023
-- Description: Retrieves communication information
-- ====================================================

ALTER VIEW [dbo].[vw_GetCommunications]
AS
    SELECT
    *,
    CASE
        WHEN (SELECT COUNT([ID]) FROM [dbo].[AllVersions] WHERE [ID]=[dbo].[Notifications].[ID]) > 1 AND DATEADD(hour, 48, [LastUpdatedTime]) >= GETUTCDATE() THEN 'UPDATED'
        WHEN (SELECT COUNT([ID]) FROM [dbo].[AllVersions] WHERE [ID]=[dbo].[Notifications].[ID]) = 1 AND DATEADD(hour, 48, [LastUpdatedTime]) >= GETUTCDATE() THEN 'NEW'
        ELSE NULL
        END AS [State]
    FROM
    [dbo].[Notifications]
GO

EXECUTE [dbo].[proc_AddConnectorTypeDefinition] 
    @ConnectorId = '4d7bed24-698e-47ce-ae13-44a15982906f'
    ,@Name = 'Microsoft Search'
    ,@Type = 'graphConnector'
    ,@Icon = '/images/search.png'
    ,@Unique = true
    ,@System = true
    ,@Hidden = true
    ,@Parameters = '[
        {
            "id": 1,
            "name": "Configured",
            "displayName": "Graph connector configured",
            "type": "boolean",
            "description": "",
            "parameterType": "configuration"
        },
        {
            "id": 2,
            "name": "Enabled",
            "displayName": "Graph connector enabled",
            "type": "boolean",
            "description": "",
            "parameterType": "configuration"
        },
        {
            "id": 3,
            "name": "SchemaUpdated",
            "displayName": "Graph connector schema updated timestamp",
            "type": "DateTime",
            "description": "",
            "parameterType": "configuration"
        },
        {
            "id": 4,
            "name": "RootUrl",
            "displayName": "Service Health Hub Root Url",
            "type": "string",
            "description": "",
            "parameterType": "configuration"
        },
        {
            "id": 5,
            "name": "SyncACL",
            "displayName": "Access control list",
            "type": "array",
            "description": "",
            "parameterType": "cache"
        }
]'
GO

EXECUTE [dbo].[proc_AddConnector] 
    @ConnectorId = 'a6a162f4-4910-4c64-a5fd-18a01665c88d'
    ,@Name = 'Microsoft Search'
    ,@Type = '4d7bed24-698e-47ce-ae13-44a15982906f'
    ,@Configuration = '[
        {
            "name": "Configured",
            "value": false
        },
        {
            "name": "Enabled",
            "value": false
        },
        {
            "name": "SchemaUpdated",
            "value": "2000-01-01T00:00:00"
        },
        {
            "name": "RootUrl",
            "value": ""
        }
    ]'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'4d7bed24-698e-47ce-ae13-44a15982906f'
,'search'
,'schema'
,'{
    "baseType": "microsoft.graph.externalItem",
    "properties": [
      {
        "name": "id",
        "type": "String",
        "isSearchable": "true",
        "isRetrievable": "true"
      },
      {
        "name": "title",
        "type": "String",
        "isRetrievable": "true",
        "isSearchable": "true",
        "labels": [
          "title"
        ]
      },
      {
        "name": "iconUrl",
        "type": "String",
        "isRetrievable": "true",
        "isSearchable": "false",
        "labels": [
          "iconUrl"
        ]
      },
      {
        "name": "url",
        "type": "String",
        "isRetrievable": "true",
        "isSearchable": "true",
        "labels": [
          "url"
        ]
      },
      {
        "name": "summary",
        "type": "String",
        "isRetrievable": "true",
        "isSearchable": "true"
      },
      {
        "name": "source",
        "type": "String",
        "isQueryable": "true",
        "isRetrievable": "true"
      },
      {
        "name": "status",
        "type": "String",
        "isQueryable": "true",
        "isRetrievable": "true"
      },
      {
        "name": "active",
        "type": "Boolean",
        "isQueryable": "true",
        "isRetrievable": "true"
      },
      {
        "name": "resources",
        "type": "StringCollection",
        "isQueryable": "true",
        "isRetrievable": "true"
      },
      {
        "name": "startTime",
        "type": "DateTime",
        "isQueryable": "true",
        "isRetrievable": "true"
      },
      {
        "name": "endTime",
        "type": "DateTime",
        "isQueryable": "true",
        "isRetrievable": "true"
      },
      {
        "name": "tags",
        "type": "StringCollection",
        "isQueryable": "true",
        "isRetrievable": "true"
      },
      {
        "name": "lastUpdate",
        "type": "DateTime",
        "isQueryable": "true",
        "isRetrievable": "true",
        "labels": [
          "lastModifiedDateTime"
        ]
      }
    ]
  }'
,'dbo'
GO
"@,
"Microsoft Graph Connector, indexing support."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2404, 1),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("b364b13c-8488-43ee-9a76-cc64090302ee"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
    
-- =======================================================
-- Author: aldras
-- Create date: 04/19/2024
-- Modify date: 04/19/2024
-- Description: Add Common Data Connector Alert component
-- =======================================================
EXEC [dbo].[proc_AddComponent]
@Name='Common Data Connector Alert (V1)',
@InternalName='CommonDataConnectorAlertV1',
@Capabilities='[
    "Sync",
    "Routing",
    "Notifications",
    "TaskManagement"
]',
@EntityProperties='[
    { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
    { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
    { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
    { "displayName": "Last updated", "entityProperty": "LastModifiedDT", "type": "System.DateTime", "hidden": false },
    { "displayName": "Start time", "entityProperty": "StartTimeDT", "type": "System.DateTime", "hidden": false },
    { "displayName": "End time", "entityProperty": "EndTimeDT", "type": "System.DateTime", "hidden": false },
    { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
    { "displayName": "Title", "entityProperty": "OriginalTitle", "type": "System.String", "hidden": false },
    { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
    { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
    { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": true },
    { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false },
    { "displayName": "Type", "entityProperty": "Type", "type": "System.String", "hidden": false },
    { "displayName": "Source", "entityProperty": "Source", "type": "System.String", "hidden": false },
    { "displayName": "Resource", "entityProperty": "Resource", "type": "System.String", "hidden": false }, 
    { "displayName": "Status", "entityProperty": "Status", "type": "System.String", "hidden": false }
]'
GO

-- =======================================================
-- Author: aldras
-- Create date: 04/19/2024
-- Modify date: 04/19/2024
-- Description: Add Common Data Connector Alert
--              notification template 1/4
-- =======================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate]
    '099ef26c-3030-46a4-aa89-bff0efe679f8'
    ,'COMMONDATACONNECTORALERTV1'
    ,'notificationTemplate'
    ,'{
    "template": {
        "Content": {
            "Subject": "entity://NotificationTitle/translate",
            "Html": "entity://Description/translate"
        }
    }
}'
    ,'dbo'
GO

-- =======================================================
-- Author: aldras
-- Create date: 04/19/2024
-- Modify date: 04/19/2024
-- Description: Add Common Data Connector Alert
--              notification template 2/4
-- =======================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate]
    'e865a99d-44b2-4f3d-9c94-523c30fce3b0'
    ,'COMMONDATACONNECTORALERTV1'
    ,'notificationTemplate'
    ,'{
    "template": {
        "notificationType": "CommonDataConnectorAlertV1",
        "title": "entity://NotificationTitle/translate",
        "subtitle": "entity://Type,
        "componentImage": "route://icon",
        "properties": "",
        "description": "entity://Description/convertToPlainText/translate",
        "lastUpdate": "entity://LastModified/dateTimeToString",
        "workItemUrl": "",
        "teamId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=TeamId",
        "channelId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=ChannelId"
    }
    }'
    ,'dbo'
GO

-- =======================================================
-- Author: aldras
-- Create date: 04/19/2024
-- Modify date: 04/19/2024
-- Description: Add Common Data Connector Alert
--              notification template 3/4
-- =======================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'2b650c59-bc1b-429c-9da9-ae09ba576cc7'
,'COMMONDATACONNECTORALERTV1'
,'notificationTemplate'
,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "entity://Type",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://Description/translate?translate_html=true"
            },
            {
                "facts": [
                    {
                        "value": "entity://Source",
                        "name": "static://text/translate?value=Source"
                    },
                    {
                        "value": "entity://Resource",
                        "name": "static://text/translate?value=Resource"
                    },
                    {
                        "value": "entity://Type",
                        "name": "static://text/translate?value=Type"
                    },
                    {
                        "value": "entity://StartTimeDT",
                        "name": "static://text/translate?value=Start time"
                    },
                    {
                        "value": "entity://EndTimeDT",
                        "name": "static://text/translate?value=End time"
                    },
                    {
                        "value": "entity://LastModifiedDT",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            }
        ]
    }
}'
,'dbo'
GO

-- =======================================================
-- Author: aldras
-- Create date: 04/19/2024
-- Modify date: 04/19/2024
-- Description: Add Common Data Connector Alert
--              notification template 4/4
-- =======================================================
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'COMMONDATACONNECTORALERTV1'
,'notificationTemplate'
,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "entity://Type",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://Description/translate?translate_html=true"
            },
            {
                "facts": [
                    {
                        "value": "entity://Source",
                        "name": "static://text/translate?value=Source"
                    },
                    {
                        "value": "entity://Resource",
                        "name": "static://text/translate?value=Resource"
                    },
                    {
                        "value": "entity://Type",
                        "name": "static://text/translate?value=Type"
                    },
                    {
                        "value": "entity://StartTimeDT",
                        "name": "static://text/translate?value=Start time"
                    },
                    {
                        "value": "entity://EndTimeDT",
                        "name": "static://text/translate?value=End time"
                    },
                    {
                        "value": "entity://LastModifiedDT",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            }
        ]
    }
}'
,'dbo'
GO
"@,
"Common Data Connector V1."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2402, 1),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("bcf17a8c-fbdd-4c5e-810f-9497effd7866"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
    
-- ====================================================
-- Author: aldras
-- Create date: 06/04/2022
-- Modify date: 03/06/2024
-- Description: Retrieve newest license statistics
-- ====================================================
CREATE OR ALTER VIEW [dbo].[LastLicenseStatistics]
AS
        SELECT
        [DisplayName],
        [SkuPartNumber],
        [Enabled],
        [ConsumedUnits],
        [Suspended],
        [Warning],
        [Enabled]+[Warning]-[ConsumedUnits] AS [AvailableUnits],
        CAST([Timestamp] AS DATE) AS [Date]
    FROM (
        SELECT
            [DisplayName],
            [SkuPartNumber],
            [Enabled],
            [ConsumedUnits],
            [Suspended],
            [Warning],
            [Timestamp],
            ROW_NUMBER() OVER (PARTITION BY [SkuPartNumber] ORDER BY [Timestamp] DESC) as MAX_ID
        FROM
            [dbo].[AllLicenseStatistics]) ls
    WHERE MAX_ID = 1
GO
"@,
"License statistics fix."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2401, 1),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("48f69243-9e17-4ffb-901d-6e477fc58a02"),
                @"
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'2b650c59-bc1b-429c-9da9-ae09ba576cc7'
,'SERVICEUPDATEMESSAGE'
,'notificationTemplate'
,'{
"template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
    {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
    },
    {
        "text": "entity://Tags"
    },
    {
        "text": "entity://Description/translate?translate_html=true"
    },
    {
        "facts": [
        {
            "value": "entity://ReleaseState",
            "name": "static://text/translate?value=Release state"
        },
        {
            "value": "entity://StartTime",
            "name": "static://text/translate?value=Start time"
        },
        {
            "value": "entity://EndTime",
            "name": "static://text/translate?value=End time"
        },
        {
            "value": "entity://ActionRequiredBy",
            "name": "static://text/translate?value=Action required by"
        },
        {
            "value": "entity://LastModified",
            "name": "static://text/translate?value=Last update"
        }
        ]
    },
    {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
    }
    ],
    "potentialAction": [
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
        }
        ],
        "name": "static://text/translate?value=Work item"
    },
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://HelpLink"
        }
        ],
        "name": "static://text/translate?value=Help link"
    },
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://ExternalLink"
        }
        ],
        "name": "static://text/translate?value=External link"
    },
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://BlogLink"
        }
        ],
        "name": "static://text/translate?value=Blog link"
    }
    ]
}
}'
,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
    '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
    ,'RELEASEMESSAGE'
    ,'notificationTemplate'
    ,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "static://text/translate?value=Please review the information provided below",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://Tags"
            },
            {
                "text": "entity://Description/translate?translate_html=true"
            },
            {
                "facts": [
                    {
                        "value": "entity://ReleaseDate/dateTimeToString",
                        "name": "static://text/translate?value=Release date"
                    },
                    {
                        "value": "entity://ActionRequiredBy/dateTimeToString",
                        "name": "static://text/translate?value=Action required by"
                    },
                    {
                        "value": "entity://LastModified/dateTimeToString",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            }
        ]
    }
}'
    ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
    '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
    ,'AZURESERVICEHEALTHALERT'
    ,'notificationTemplate'
    ,'{
    "template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
        {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
        },
        {
        "text": "entity://Tags"
        },
        {
        "text": "entity://Description/translate?translate_html=true"
        },
        {
        "text": "entity://ImpactedServicesDescription/translate"
        },
        {
        "facts": [
            {
            "value": "entity://StartTime",
            "name": "static://text/translate?value=Start time"
            },
            {
            "value": "entity://EndTime",
            "name": "static://text/translate?value=End time"
            },
            {
            "value": "entity://LastModified",
            "name": "static://text/translate?value=Last update"
            }
        ]
        },
        {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
        }
    ],
    "potentialAction": [
        {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
            { 
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
            }
        ],
        "name": "static://text/translate?value=Work item"
        }
    ]
    }
}'
    ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
    '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
    ,'AZUREUPDATE'
    ,'notificationTemplate'
    ,'{
    "template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
        {
        "activityImage": "route://icon",
        "activityText": "entity://Summary/translate",
        "activityTitle": "entity://NotificationTitle/translate"
        },
        {
        "text": "entity://Tags"
        },
        {
        "text": "entity://Description/translate?translate_html=true"
        },
        {
        "text": "entity://ImpactedServicesDescription/translate"
        },
        {
        "facts": [
            {
            "value": "entity://ReleaseStatus",
            "name": "static://text/translate?value=Release status"
            },
            {
            "value": "entity://Published",
            "name": "static://text/translate?value=Published"
            }
        ]
        },
        {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
        }
    ],
    "potentialAction": [
        {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
            { 
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
            }
        ],
        "name": "static://text/translate?value=Work item"
        },
        {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
            {
            "os": "default",
            "uri": "entity://Article"
            }
        ],
        "name": "static://text/translate?value=Blog article"
        }
    ]
    }
}'
    ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'2b650c59-bc1b-429c-9da9-ae09ba576cc7'
,'D365POWERPLATFORMRELEASE'
,'notificationTemplate'
,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "static://text/translate?value=Please review the information provided below",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://BusinessValue/translate?translate_html=true"
            },
            {
                "text": "entity://Description/translate?translate_html=true"
            },
            {
                "facts": [
                    {
                        "value": "entity://Product",
                        "name": "static://text/translate?value=Product"
                    },
                    {
                        "value": "entity://FeatureType",
                        "name": "static://text/translate?value=Feature type"
                    },
                    {
                        "value": "entity://EnabledFor",
                        "name": "static://text/translate?value=Enabled for"
                    },
                    {
                        "value": "entity://EarlyAccessStatus",
                        "name": "static://text/translate?value=Early access"
                    },
                    {
                        "value": "entity://PublicPreviewStatus",
                        "name": "static://text/translate?value=Public preview"
                    },
                    {
                        "value": "entity://GAStatus",
                        "name": "static://text/translate?value=General availability"
                    },
                    {
                        "value": "entity://LastUpdate",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://Documentation"
                    }
                ],
                "name": "static://text/translate?value=Documentation"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://BlogArticle"
                    }
                ],
                "name": "static://text/translate?value=Blog article"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://OverviewVideo"
                    }
                ],
                "name": "static://text/translate?value=Overview video"
            }
        ]
    }
}'
,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'SERVICEUPDATEMESSAGE'
,'notificationTemplate'
,'{
"template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
    {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
    },
    {
        "text": "entity://Tags"
    },
    {
        "text": "entity://Description/translate?translate_html=true"
    },
    {
        "facts": [
        {
            "value": "entity://ReleaseState",
            "name": "static://text/translate?value=Release state"
        },
        {
            "value": "entity://StartTime",
            "name": "static://text/translate?value=Start time"
        },
        {
            "value": "entity://EndTime",
            "name": "static://text/translate?value=End time"
        },
        {
            "value": "entity://ActionRequiredBy",
            "name": "static://text/translate?value=Action required by"
        },
        {
            "value": "entity://LastModified",
            "name": "static://text/translate?value=Last update"
        }
        ]
    },
    {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
    }
    ],
    "potentialAction": [
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
        }
        ],
        "name": "static://text/translate?value=Work item"
    },
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://HelpLink"
        }
        ],
        "name": "static://text/translate?value=Help link"
    },
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://ExternalLink"
        }
        ],
        "name": "static://text/translate?value=External link"
    },
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://BlogLink"
        }
        ],
        "name": "static://text/translate?value=Blog link"
    }
    ]
}
}'
,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
    'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,'RELEASEMESSAGE'
    ,'notificationTemplate'
    ,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "static://text/translate?value=Please review the information provided below",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://Tags"
            },
            {
                "text": "entity://Description/translate?translate_html=true"
            },
            {
                "facts": [
                    {
                        "value": "entity://ReleaseDate/dateTimeToString",
                        "name": "static://text/translate?value=Release date"
                    },
                    {
                        "value": "entity://ActionRequiredBy/dateTimeToString",
                        "name": "static://text/translate?value=Action required by"
                    },
                    {
                        "value": "entity://LastModified/dateTimeToString",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            }
        ]
    }
}'
    ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
    'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,'AZURESERVICEHEALTHALERT'
    ,'notificationTemplate'
    ,'{
    "template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
        {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
        },
        {
        "text": "entity://Tags"
        },
        {
        "text": "entity://Description/translate?translate_html=true"
        },
        {
        "text": "entity://ImpactedServicesDescription/translate"
        },
        {
        "facts": [
            {
            "value": "entity://StartTime",
            "name": "static://text/translate?value=Start time"
            },
            {
            "value": "entity://EndTime",
            "name": "static://text/translate?value=End time"
            },
            {
            "value": "entity://LastModified",
            "name": "static://text/translate?value=Last update"
            }
        ]
        },
        {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
        }
    ],
    "potentialAction": [
        {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
            { 
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
            }
        ],
        "name": "static://text/translate?value=Work item"
        }
    ]
    }
}'
    ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
    'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,'AZUREUPDATE'
    ,'notificationTemplate'
    ,'{
    "template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
        {
        "activityImage": "route://icon",
        "activityText": "entity://Summary/translate",
        "activityTitle": "entity://NotificationTitle/translate"
        },
        {
        "text": "entity://Tags"
        },
        {
        "text": "entity://Description/translate?translate_html=true"
        },
        {
        "text": "entity://ImpactedServicesDescription/translate"
        },
        {
        "facts": [
            {
            "value": "entity://ReleaseStatus",
            "name": "static://text/translate?value=Release status"
            },
            {
            "value": "entity://Published",
            "name": "static://text/translate?value=Published"
            }
        ]
        },
        {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
        }
    ],
    "potentialAction": [
        {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
            { 
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
            }
        ],
        "name": "static://text/translate?value=Work item"
        },
        {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
            {
            "os": "default",
            "uri": "entity://Article"
            }
        ],
        "name": "static://text/translate?value=Blog article"
        }
    ]
    }
}'
    ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'D365POWERPLATFORMRELEASE'
,'notificationTemplate'
,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "static://text/translate?value=Please review the information provided below",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://BusinessValue/translate?translate_html=true"
            },
            {
                "text": "entity://Description/translate?translate_html=true"
            },
            {
                "facts": [
                    {
                        "value": "entity://Product",
                        "name": "static://text/translate?value=Product"
                    },
                    {
                        "value": "entity://FeatureType",
                        "name": "static://text/translate?value=Feature type"
                    },
                    {
                        "value": "entity://EnabledFor",
                        "name": "static://text/translate?value=Enabled for"
                    },
                    {
                        "value": "entity://EarlyAccessStatus",
                        "name": "static://text/translate?value=Early access"
                    },
                    {
                        "value": "entity://PublicPreviewStatus",
                        "name": "static://text/translate?value=Public preview"
                    },
                    {
                        "value": "entity://GAStatus",
                        "name": "static://text/translate?value=General availability"
                    },
                    {
                        "value": "entity://LastUpdate",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://Documentation"
                    }
                ],
                "name": "static://text/translate?value=Documentation"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://BlogArticle"
                    }
                ],
                "name": "static://text/translate?value=Blog article"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://OverviewVideo"
                    }
                ],
                "name": "static://text/translate?value=Overview video"
            }
        ]
    }
}'
,'dbo'
GO
"@,
"HTML Translation fix."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2401, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("41e746fa-8029-4649-bed1-32f063190388"),
                @"
-- =========================================================
-- Author: aldras
-- Modify date: 12/21/2023
-- Description: Adds hidden column for connector definitions
-- =========================================================
ALTER TABLE [dbo].[ConnectorDefinition] ADD [Hidden] [bit] NOT NULL CONSTRAINT D_ConnectorDefinition_Hidden DEFAULT(0)
GO

-- =========================================================
-- Author: aldras
-- Create date: 06/14/2022
-- Modify date: 12/21/2023
-- Description: Adds connector type definition
-- =========================================================
ALTER PROCEDURE [dbo].[proc_AddConnectorTypeDefinition]
    @ConnectorId UNIQUEIDENTIFIER,
    @Name [nvarchar](128),
    @Type [nvarchar](64),
    @Icon [nvarchar](256),
    @Unique [bit],
    @System [bit],
    @Hidden [bit],
    @Parameters [nvarchar](max)
AS
BEGIN
    SET NOCOUNT ON;
    
    declare @existingId as UNIQUEIDENTIFIER = (SELECT [ConnectorId] from [dbo].[ConnectorDefinition] where [ConnectorId]=@ConnectorId)
    
    if (@existingId IS NULL)
    begin
        INSERT INTO [dbo].[ConnectorDefinition] ([ConnectorId], [Name], [Type], [Icon], [Unique], [System], [Hidden], [Parameters])
        values (@ConnectorId, @Name, @Type, @Icon, @Unique, @System, @Hidden, @Parameters)
    end else
    begin
        UPDATE [dbo].[ConnectorDefinition]
        SET
            [Name] = @Name,
            [Type] = @Type,
            [Icon] = @Icon,
            [Unique] = @Unique,
            [System] = @System,
            [Hidden] = @Hidden,
            [Parameters] = @Parameters
        WHERE [ConnectorId]=@ConnectorId
    end
END
GO

EXECUTE [dbo].[proc_AddConnectorTypeDefinition] 
    @ConnectorId = 'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,@Name = 'Teams'
    ,@Type = 'notificationManager'
    ,@Icon = '/images/teams.png'
    ,@Unique = true
    ,@System = true
    ,@Hidden = true
    ,@Parameters = '[
            {
                "id": 100,
                "name": "TeamsChannelUri",
                "displayName": "Teams channel incoming webhook url",
                "type": "string",
                "description": "Enter the url of the Teams channel",
                "parameterType": "routing"
            }
        ]'
GO

EXECUTE [dbo].[proc_AddConnector] 
    @ConnectorId = 'a6bb0207-74d1-4094-a808-42a6fdd9d31d'
    ,@Name = 'Microsoft Teams'
    ,@Type = 'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,@Configuration = '[]'
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/14/2022
-- Modify date: 12/21/2023
-- Description: Retrieve list of connectors
-- ====================================================
ALTER VIEW [dbo].[vw_GetConnectors]
AS
    SELECT 
        [Connector].*,
        [ConnectorDefinition].[Name] AS [ConnectorTypeName],
        [ConnectorDefinition].[Icon] AS [Icon],
        [ConnectorDefinition].[System] AS [System],
        [ConnectorDefinition].[Hidden] AS [Hidden],
        [ConnectorDefinition].[Parameters] AS [ParameterDefinition],
        [ConnectorDefinition].[Type] AS [ConnectorType]
    FROM [dbo].[Connectors] AS [Connector]
    LEFT OUTER JOIN
        [dbo].[ConnectorDefinition] AS [ConnectorDefinition] on [Connector].[Type] = [ConnectorDefinition].[ConnectorId]
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'SERVICEUPDATEMESSAGE'
,'notificationTemplate'
,'{
"template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
    {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
    },
    {
        "text": "entity://Tags"
    },
    {
        "text": "entity://Description/translate"
    },
    {
        "facts": [
        {
            "value": "entity://ReleaseState",
            "name": "static://text/translate?value=Release state"
        },
        {
            "value": "entity://StartTime",
            "name": "static://text/translate?value=Start time"
        },
        {
            "value": "entity://EndTime",
            "name": "static://text/translate?value=End time"
        },
        {
            "value": "entity://ActionRequiredBy",
            "name": "static://text/translate?value=Action required by"
        },
        {
            "value": "entity://LastModified",
            "name": "static://text/translate?value=Last update"
        }
        ]
    },
    {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
    }
    ],
    "potentialAction": [
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
        }
        ],
        "name": "static://text/translate?value=Work item"
    },
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://HelpLink"
        }
        ],
        "name": "static://text/translate?value=Help link"
    },
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://ExternalLink"
        }
        ],
        "name": "static://text/translate?value=External link"
    },
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://BlogLink"
        }
        ],
        "name": "static://text/translate?value=Blog link"
    }
    ]
}
}'
,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
    'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,'SERVICEHEALTHISSUE'
    ,'notificationTemplate'
    ,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "entity://Status/getStatusThemeColor",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "entity://ImpactDescription/translate",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://NotificationStatus"
            },
            {
                "text": "entity://Description/translate"
            },
            {
                "facts": [
                    {
                        "value": "entity://StartTime",
                        "name": "static://text/translate?value=Start time"
                    },
                    {
                        "value": "entity://EndTime",
                        "name": "static://text/translate?value=End time"
                    },
                    {
                        "value": "entity://LastModified",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            }
        ]
    }
}'
    ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
    'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,'ROADMAPCOMMUNICATION'
    ,'notificationTemplate'
    ,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "entity://Category",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "facts": [
                    {
                        "value": "entity://Products",
                        "name": "static://text/translate?value=Products"
                    },
                    {
                        "value": "entity://Platforms",
                        "name": "static://text/translate?value=Platforms"
                    },
                    {
                        "value": "entity://CloudInstances",
                        "name": "static://text/translate?value=Cloud instances"
                    },
                    {
                        "value": "entity://ReleasePhase",
                        "name": "static://text/translate?value=Release phase"
                    }
                ]
            },
            {
                "text": "entity://Description/translate"
            },
            {
                "facts": [
                    {
                        "value": "entity://Id",
                        "name": "static://text/translate?value=Feature ID"
                    },
                    {
                        "value": "entity://PublicPreview",
                        "name": "static://text/translate?value=Public preview"
                    },
                    {
                        "value": "entity://Availability",
                        "name": "static://text/translate?value=Availability"
                    },
                    {
                        "value": "entity://Published/dateTimeToString",
                        "name": "static://text/translate?value=Published"
                    },
                    {
                        "value": "entity://LastModified/dateTimeToString",
                        "name": "static://text/translate?value=Last updated"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://RoadmapUrl"
                    }
                ],
                "name": "static://text/translate?value=Roadmap item"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://MoreInfoLink"
                    }
                ],
                "name": "static://text/translate?value=More info"
            }
        ]
    }
}'
    ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
    'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,'RELEASEMESSAGE'
    ,'notificationTemplate'
    ,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "static://text/translate?value=Please review the information provided below",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://Tags"
            },
            {
                "text": "entity://Description/translate"
            },
            {
                "facts": [
                    {
                        "value": "entity://ReleaseDate/dateTimeToString",
                        "name": "static://text/translate?value=Release date"
                    },
                    {
                        "value": "entity://ActionRequiredBy/dateTimeToString",
                        "name": "static://text/translate?value=Action required by"
                    },
                    {
                        "value": "entity://LastModified/dateTimeToString",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            }
        ]
    }
}'
    ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
    'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,'AZURESERVICEHEALTHALERT'
    ,'notificationTemplate'
    ,'{
    "template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
        {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
        },
        {
        "text": "entity://Tags"
        },
        {
        "text": "entity://Description/translate"
        },
        {
        "text": "entity://ImpactedServicesDescription/translate"
        },
        {
        "facts": [
            {
            "value": "entity://StartTime",
            "name": "static://text/translate?value=Start time"
            },
            {
            "value": "entity://EndTime",
            "name": "static://text/translate?value=End time"
            },
            {
            "value": "entity://LastModified",
            "name": "static://text/translate?value=Last update"
            }
        ]
        },
        {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
        }
    ],
    "potentialAction": [
        {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
            { 
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
            }
        ],
        "name": "static://text/translate?value=Work item"
        }
    ]
    }
}'
    ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
    'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,'OFFICE365ENDPOINTSCHANGE'
    ,'notificationTemplate'
    ,'{
    "template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
        {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
        },
        {
        "text": "entity://Tags"
        },
        {
        "text": "entity://Description/translate"
        },
        {
        "facts": [
            {
            "value": "entity://Version",
            "name": "static://text/translate?value=Version"
            },
            {
            "value": "entity://ServiceArea",
            "name": "static://text/translate?value=Service area"
            },
            {
            "value": "entity://Disposition",
            "name": "static://text/translate?value=Disposition"
            },
            {
            "value": "entity://Impact",
            "name": "static://text/translate?value=Impact"
            },
            {
            "value": "entity://ActionRequiredBy",
            "name": "static://text/translate?value=Action required by"
            },
            {
            "value": "entity://LastModified",
            "name": "static://text/translate?value=Last update"
            }
        ]
        },
        {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
        }
    ],
    "potentialAction": [
        {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
            {
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
            }
        ],
        "name": "static://text/translate?value=Work item"
        }
    ]
    }
}'
    ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
    'df88e1e0-6af3-4b7e-9584-57340ca34caf'
    ,'AZUREUPDATE'
    ,'notificationTemplate'
    ,'{
    "template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
        {
        "activityImage": "route://icon",
        "activityText": "entity://Summary/translate",
        "activityTitle": "entity://NotificationTitle/translate"
        },
        {
        "text": "entity://Tags"
        },
        {
        "text": "entity://Description/translate"
        },
        {
        "text": "entity://ImpactedServicesDescription/translate"
        },
        {
        "facts": [
            {
            "value": "entity://ReleaseStatus",
            "name": "static://text/translate?value=Release status"
            },
            {
            "value": "entity://Published",
            "name": "static://text/translate?value=Published"
            }
        ]
        },
        {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
        }
    ],
    "potentialAction": [
        {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
            { 
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
            }
        ],
        "name": "static://text/translate?value=Work item"
        },
        {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
            {
            "os": "default",
            "uri": "entity://Article"
            }
        ],
        "name": "static://text/translate?value=Blog article"
        }
    ]
    }
}'
    ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate]
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'SYSTEMALERT'
,'notificationTemplate'
,'{
"template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
    {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
    },
    {
        "text": "entity://Type"
    },

    {
        "text": "entity://Description/translate"
    },
    {
        "facts": [
        {
            "value": "entity://Source",
            "name": "static://text/translate?value=Source"
        },
        {
            "value": "entity://CommunicationID",
            "name": "static://text/translate?value=Communication ID"
        },
        {
            "value": "entity://CommunicationType",
            "name": "static://text/translate?value=Communication type"
        },
        {
            "value": "entity://Timestamp",
            "name": "static://text/translate?value=Fired at"
        }
        ]
    },
    {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
    }
    ]
}
}'
,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'df88e1e0-6af3-4b7e-9584-57340ca34caf'
,'D365POWERPLATFORMRELEASE'
,'notificationTemplate'
,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "static://text/translate?value=Please review the information provided below",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://BusinessValue/translate"
            },
            {
                "text": "entity://Description/translate"
            },
            {
                "facts": [
                    {
                        "value": "entity://Product",
                        "name": "static://text/translate?value=Product"
                    },
                    {
                        "value": "entity://FeatureType",
                        "name": "static://text/translate?value=Feature type"
                    },
                    {
                        "value": "entity://EnabledFor",
                        "name": "static://text/translate?value=Enabled for"
                    },
                    {
                        "value": "entity://EarlyAccessStatus",
                        "name": "static://text/translate?value=Early access"
                    },
                    {
                        "value": "entity://PublicPreviewStatus",
                        "name": "static://text/translate?value=Public preview"
                    },
                    {
                        "value": "entity://GAStatus",
                        "name": "static://text/translate?value=General availability"
                    },
                    {
                        "value": "entity://LastUpdate",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://Documentation"
                    }
                ],
                "name": "static://text/translate?value=Documentation"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://BlogArticle"
                    }
                ],
                "name": "static://text/translate?value=Blog article"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://OverviewVideo"
                    }
                ],
                "name": "static://text/translate?value=Overview video"
            }
        ]
    }
}'
,'dbo'
GO             
"@,
"Added native Microsoft Teams connector."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2311, 8),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("b14042f1-d358-46d3-839f-c8e874409cb1"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[AllD365PPCommsDetailed]
AS
SELECT [ID], 
    JSON_VALUE([Data], '$.FeatureName') AS [Title],
    JSON_VALUE([Data], '$.BusinessValue') AS [BusinessValue],
    JSON_VALUE([Data], '$.FeatureDetails') AS [Description],
    JSON_VALUE([Data], '$.FeatureType') AS [FeatureType],
    JSON_VALUE([Data], '$.Product') AS [Product],
    JSON_VALUE([Data], '$.ProductArea') AS [ProductArea],
    JSON_VALUE([Data], '$.ParentProductName') AS [ParentProduct],
    JSON_VALUE([Data], '$.EnabledFor') AS [EnabledFor],
    JSON_VALUE([Data], '$.ReleaseWaveId') AS [ReleaseWaveId],
    JSON_VALUE([Data], '$.ReleaseWaveName') AS [ReleaseWave],
    IIF (JSON_VALUE([Data], '$.RW_StartShipDate') IS NULL OR JSON_VALUE([Data], '$.RW_StartShipDate') = '', NULL, CONVERT(DATETIME2, JSON_VALUE([Data], '$.RW_StartShipDate'))) AS [RWStartShipDate],
    IIF (JSON_VALUE([Data], '$.RW_EndShipDate') IS NULL OR JSON_VALUE([Data], '$.RW_EndShipDate') = '', NULL, CONVERT(DATETIME2, JSON_VALUE([Data], '$.RW_EndShipDate'))) AS [RWEndShipDate],
    JSON_VALUE([Data], '$.RW_Status') AS [RW_Status],
    IIF (JSON_VALUE([Data], '$.EarlyAccessDate') IS NULL OR JSON_VALUE([Data], '$.EarlyAccessDate') = '', NULL, CONVERT(DATETIME2, JSON_VALUE([Data], '$.EarlyAccessDate'))) AS [EarlyAccessDate],
    JSON_VALUE([Data], '$.EAStatus') AS [EarlyAccessStatus],
    IIF (JSON_VALUE([Data], '$.PublicPreviewDate') IS NULL OR JSON_VALUE([Data], '$.PublicPreviewDate') = '', NULL, CONVERT(DATETIME2, JSON_VALUE([Data], '$.PublicPreviewDate'))) AS [PublicPreviewDate],
    JSON_VALUE([Data], '$.PPStatus') AS [PublicPreviewStatus],
    IIF (JSON_VALUE([Data], '$.GADate') IS NULL OR JSON_VALUE([Data], '$.GADate') = '', NULL, CONVERT(DATETIME2, JSON_VALUE([Data], '$.GADate'))) AS [GADate],
    JSON_VALUE([Data], '$.GAStatus') AS [GAStatus],
    JSON_VALUE([Data], '$.DocsUrl') AS [Documentation],
    JSON_VALUE([Data], '$.BlogURL') AS [BlogArticle],
    JSON_VALUE([Data], '$.OverviewVideo') AS [OverviewVideo],
    IIF (JSON_VALUE([Data], '$.FirstGitHubPushDate') IS NULL OR JSON_VALUE([Data], '$.FirstGitHubPushDate') = '', NULL, CONVERT(DATETIME2, JSON_VALUE([Data], '$.FirstGitHubPushDate'))) AS [Published],
    IIF (JSON_VALUE([Data], '$.GitCommitDate') IS NULL OR JSON_VALUE([Data], '$.GitCommitDate') = '', NULL, CONVERT(DATETIME2, JSON_VALUE([Data], '$.GitCommitDate'))) AS [LastUpdate],
    JSON_QUERY([Data], '$.SHHImageMetadata') AS [SHHImageMetadata],
    [WorkItemID],
    [WorkItemURL],
    [Public],
    [ExtendedProperties]
FROM
    [dbo].[Notifications]
WHERE
    [Type]='D365POWERPLATFORMRELEASE'
GO              
"@,
"Added Dynamics 365 and Power Platform Release view for the Web API support."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2311, 7),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("df27b08f-59fe-41e7-9535-fd36f1244fff"),
                @"
EXEC [dbo].[proc_AddComponent]
@Name='Dynamics 365 and Power Platform Release',
@InternalName='D365PowerPlatformRelease',
@Capabilities='[
    "Sync",
    "Routing",
    "Notifications",
    "TaskManagement",
    "Portal",
    "CustomActions"
]',
@EntityProperties='[
    { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
    { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
    { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
    { "displayName": "Last updated", "entityProperty": "LastUpdatedTime", "type": "System.DateTime", "hidden": true },
    { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
    { "displayName": "Title", "entityProperty": "OriginalTitle", "type": "System.String", "hidden": false },
    { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
    { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
    { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": false },
    { "displayName": "Business value", "entityProperty": "BusinessValue", "type": "System.String", "hidden": false },
    { "displayName": "Feature type", "entityProperty": "FeatureType", "type": "System.String", "hidden": false },
    { "displayName": "Product", "entityProperty": "Product", "type": "System.String", "hidden": false },
    { "displayName": "Product area", "entityProperty": "ProductArea", "type": "System.String", "hidden": false }, 
    { "displayName": "Parent product", "entityProperty": "ParentProduct", "type": "System.String", "hidden": false },
    { "displayName": "Enabled for", "entityProperty": "EnabledFor", "type": "System.String", "hidden": false },
    { "displayName": "Release Wave Id", "entityProperty": "ReleaseWaveId", "type": "System.String", "hidden": false },
    { "displayName": "Release Wave Name", "entityProperty": "ReleaseWave", "type": "System.String", "hidden": false },
    { "displayName": "Release Wave Start Ship Date", "entityProperty": "RWStartShipDate", "type": "System.DateTime", "hidden": true },
    { "displayName": "Release Wave End Ship Date", "entityProperty": "RWEndShipDate", "type": "System.DateTime", "hidden": true },
    { "displayName": "Release Wave Status", "entityProperty": "RW_Status", "type": "System.String", "hidden": false },
    { "displayName": "Early Access Date", "entityProperty": "EarlyAccessDate", "type": "System.DateTime", "hidden": true },
    { "displayName": "Early Access Status", "entityProperty": "EarlyAccessStatus", "type": "System.String", "hidden": false },
    { "displayName": "Public Preview Date", "entityProperty": "PublicPreviewDate", "type": "System.DateTime", "hidden": true },
    { "displayName": "Public Preview Status", "entityProperty": "PublicPreviewStatus", "type": "System.String", "hidden": false },
    { "displayName": "GA Date", "entityProperty": "GADate", "type": "System.DateTime", "hidden": true },
    { "displayName": "GA Status", "entityProperty": "GAStatus", "type": "System.String", "hidden": false },
    { "displayName": "Documentation", "entityProperty": "Documentation", "type": "System.String", "hidden": false },
    { "displayName": "Blog article", "entityProperty": "BlogArticle", "type": "System.String", "hidden": false },
    { "displayName": "Overview video", "entityProperty": "OverviewVideo", "type": "System.String", "hidden": false },
    { "displayName": "Published", "entityProperty": "Published", "type": "System.DateTime", "hidden": false },
    { "displayName": "Last modified", "entityProperty": "LastUpdate", "type": "System.DateTime", "hidden": false },
    { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false }
]'
GO
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'2b650c59-bc1b-429c-9da9-ae09ba576cc7'
,'D365POWERPLATFORMRELEASE'
,'notificationTemplate'
,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "static://text/translate?value=Please review the information provided below",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://BusinessValue/translate"
            },
            {
                "text": "entity://Description/translate"
            },
            {
                "facts": [
                    {
                        "value": "entity://Product",
                        "name": "static://text/translate?value=Product"
                    },
                    {
                        "value": "entity://FeatureType",
                        "name": "static://text/translate?value=Feature type"
                    },
                    {
                        "value": "entity://EnabledFor",
                        "name": "static://text/translate?value=Enabled for"
                    },
                    {
                        "value": "entity://EarlyAccessStatus",
                        "name": "static://text/translate?value=Early access"
                    },
                    {
                        "value": "entity://PublicPreviewStatus",
                        "name": "static://text/translate?value=Public preview"
                    },
                    {
                        "value": "entity://GAStatus",
                        "name": "static://text/translate?value=General availability"
                    },
                    {
                        "value": "entity://LastUpdate",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://Documentation"
                    }
                ],
                "name": "static://text/translate?value=Documentation"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://BlogArticle"
                    }
                ],
                "name": "static://text/translate?value=Blog article"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://OverviewVideo"
                    }
                ],
                "name": "static://text/translate?value=Overview video"
            }
        ]
    }
}'
,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate]
   '099ef26c-3030-46a4-aa89-bff0efe679f8'
  ,'D365POWERPLATFORMRELEASE'
  ,'notificationTemplate'
  ,'{
    "template": {
        "Content": {
            "Subject": "entity://NotificationTitle/translate",
            "Html": "entity://Description/translate"
        }
    }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate]
   'e865a99d-44b2-4f3d-9c94-523c30fce3b0'
  ,'D365POWERPLATFORMRELEASE'
  ,'notificationTemplate'
  ,'{
    "template": {
      "notificationType": "D365PowerPlatformRelease",
      "title": "entity://NotificationTitle/translate",
      "subtitle": "entity://FeatureType,
      "componentImage": "route://icon",
      "properties": "",
      "description": "entity://Description/convertToPlainText/translate",
      "lastUpdate": "entity://LastUpdate/dateTimeToString",
      "workItemUrl": "",
      "teamId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=TeamId",
      "channelId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=ChannelId"
    }
  }'
  ,'dbo'
GO
"@,
"Added Dynamics 365 and Power Platform Release component."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2311, 6),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("38bf8812-7862-4530-99af-667d842b109b"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Admin notifications',
    @InternalName='SystemAlert',
    @Icon=null,
    @Capabilities='[
       "Notifications",
       "Routing"
    ]',
@EntityProperties='[
    { "displayName": "Fired on", "entityProperty": "Timestamp", "type": "System.DateTime", "hidden": true },
    { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
    { "displayName": "Title", "entityProperty": "OriginalTitle", "type": "System.String", "hidden": false },
    { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
    { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
    { "displayName": "Type", "entityProperty": "Type", "type": "System.String", "hidden": false },
    { "displayName": "Source", "entityProperty": "Source", "type": "System.String", "hidden": false },
    { "displayName": "Communication ID", "entityProperty": "CommunicationID", "type": "System.String", "hidden": false },
    { "displayName": "Communication type", "entityProperty": "CommunicationType", "type": "System.String", "hidden": false }
]'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate]
'2b650c59-bc1b-429c-9da9-ae09ba576cc7'
,'SYSTEMALERT'
,'notificationTemplate'
,'{
"template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
    {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
    },
    {
        "text": "entity://Type"
    },

    {
        "text": "entity://Description/translate"
    },
    {
        "facts": [
        {
            "value": "entity://Source",
            "name": "static://text/translate?value=Source"
        },
        {
            "value": "entity://CommunicationID",
            "name": "static://text/translate?value=Communication ID"
        },
        {
            "value": "entity://CommunicationType",
            "name": "static://text/translate?value=Communication type"
        },
        {
            "value": "entity://Timestamp",
            "name": "static://text/translate?value=Fired at"
        }
        ]
    },
    {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
    }
    ]
}
}'
,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate]
   '099ef26c-3030-46a4-aa89-bff0efe679f8'
  ,'SYSTEMALERT'
  ,'notificationTemplate'
  ,'{
    "template": {
        "Content": {
            "Subject": "entity://NotificationTitle/translate",
            "Html": "entity://Description/translate"
        }
    }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate]
   'e865a99d-44b2-4f3d-9c94-523c30fce3b0'
  ,'SYSTEMALERT'
  ,'notificationTemplate'
  ,'{
    "template": {
      "notificationType": "System",
      "title": "entity://NotificationTitle/translate",
      "subtitle": "entity://Type,
      "componentImage": "route://icon",
      "properties": "",
      "description": "entity://Description/convertToPlainText/translate",
      "lastUpdate": "entity://Timestamp/dateTimeToString",
      "workItemUrl": "",
      "teamId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=TeamId",
      "channelId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=ChannelId"
    }
  }'
  ,'dbo'
GO
"@,
"Added System Alert (Admin notifications) component."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2311, 5),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("366e7f1f-72c9-4f4c-a74e-20805f26c20f"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Tenant reports',
    @InternalName='LicenseAnalytics',
    @Icon=null,
    @Capabilities='[
        "Sync"
    ]'
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Employee forecast import',
    @InternalName='HRStatsImport',
    @Icon=null,
    @Capabilities='[
        "Webhook"
    ]'
GO

UPDATE [dbo].[Components] SET [InternalName]='TenantReports' WHERE [InternalName]='LicenseAnalytics'
GO
"@,
"Renamed license analytics and HR stats import jobs."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2311, 4),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("bbecbc9e-41fe-44e0-a20d-17aa0d71ec9f"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ====================================================
-- Author: aldras
-- Create date: 10/20/2023
-- Modify date: 10/20/2023
-- Description: User-defined tags, definition table
-- ====================================================
CREATE TABLE [dbo].[TagDefinitions](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [TagId] [uniqueidentifier] NOT NULL,
    [Name] [nvarchar](64) NOT NULL,
    [Type] [nvarchar](32)
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TagDefinitions] ADD  CONSTRAINT [TagDefinitions_PK] PRIMARY KEY CLUSTERED 
(
    [TagId] ASC
)WITH (STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [idx_TDType] ON [dbo].[TagDefinitions]
(
    [Type] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

-- ====================================================
-- Author: aldras
-- Create date: 10/20/2023
-- Modify date: 10/20/2023
-- Description: User-defined tags, definition table
-- ====================================================
CREATE TABLE [dbo].[Tags](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [MessageId] [nvarchar](64) NOT NULL,
    [Type] [nvarchar](32) NOT NULL,
    [TagId] [uniqueidentifier] NOT NULL,
    [Modified] [datetime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Tags] ADD  CONSTRAINT [Tags_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [idx_MessageIdType] ON [dbo].[Tags]
(
    [MessageId] ASC,
    [Type] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [idx_Tag] ON [dbo].[Tags]
(
    [TagId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Tags] ADD  DEFAULT (getutcdate()) FOR [Modified]
GO

-- ====================================================
-- Author: aldras
-- Create date: 10/20/2023
-- Modify date: 10/20/2023
-- Description: Adds or modifies tag definition
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddTagDefinition]
    @TagId uniqueidentifier,
    @Name nvarchar(64),
    @Type nvarchar(40) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @existingTagId AS int = (SELECT [Id] FROM [dbo].[TagDefinitions] WHERE [TagId]=@TagId)
    
    IF (@existingTagId IS NULL)
    BEGIN
        INSERT INTO 
            [dbo].[TagDefinitions] ([TagId], [Name], [Type])
        VALUES 
            (@TagId, @Name, @Type)
    END ELSE
    BEGIN
        UPDATE 
            [dbo].[TagDefinitions]
        SET
            [Name] = @Name,
            [Type] = @Type
        WHERE
            [Id] = @existingTagId
    END
END
GO

-- ===========================================================
-- Author: aldras
-- Create date: 10/20/2023
-- Modify date: 10/20/2023
-- Description: Moves tag definition to new communication type
-- ============================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_MoveTagDefinition]
    @TagId uniqueidentifier,
    @Type nvarchar(32) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @existingTagTypeId AS int = (SELECT [Id] FROM [dbo].[TagDefinitions] WHERE [TagId]=@TagId)
    
    IF (@existingTagTypeId IS NOT NULL)
    BEGIN
        DECLARE @existingTagType AS nvarchar(32) = (SELECT [Type] FROM [dbo].[TagDefinitions] WHERE [TagId]=@TagId)

        IF ((@Type IS NULL AND @existingTagType IS NOT NULL) OR
            (@Type IS NOT NULL AND @existingTagType IS NULL) OR
            (@Type <> @existingTagType))
        BEGIN
            UPDATE
                [dbo].[TagDefinitions]
            SET
                [Type] = @Type
            WHERE
                [TagId] = @TagId

            IF (@Type IS NOT NULL)
            BEGIN
                -- we are moving tags from one communication type to another, all items will be un-tagged. Exception is moving to General section (Type = NULL)
                DELETE FROM 
                    [dbo].[Tags]
                WHERE
                    [TagId] = @TagId
            END
        END
    END
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 10/20/2023
-- Modify date: 10/20/2023
-- Description: Adds or modifies tag definition
-- ====================================================
CREATE PROCEDURE [dbo].[proc_RemoveTagDefinition]
    @TagId UNIQUEIDENTIFIER
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @existingTagTypeId AS int = (SELECT [ID] FROM [dbo].[TagDefinitions] WHERE [TagId]=@TagId)
    
    IF (@existingTagTypeId IS NOT NULL)
    BEGIN
        
        -- we are removing tags from one all communications as the definition is about to be removed
        DELETE FROM 
            [dbo].[Tags]
        WHERE
            [TagId] = @TagId

        DELETE FROM
            [dbo].[TagDefinitions]
        WHERE
            [Id] = @existingTagTypeId
    END
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 10/20/2023
-- Modify date: 10/20/2023
-- Description: Adds tag
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddTag]
    @MessageId [nvarchar](64),
    @Type [nvarchar](32),
    @TagId [uniqueidentifier]
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @existingId AS int = (SELECT [Id] FROM [dbo].[Tags] WHERE [MessageId]=@MessageId AND [Type]=@Type AND [TagId] = @TagId)
    
    IF (@existingId IS NULL)
    BEGIN
        INSERT INTO 
            [dbo].[Tags] ([MessageId], [Type], [TagId])
        VALUES 
            (@MessageId, @Type, @TagId)
    END
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 10/20/2023
-- Modify date: 10/20/2023
-- Description: Removes tag
-- ====================================================
CREATE PROCEDURE [dbo].[proc_RemoveTag]
    @MessageId [nvarchar](64),
    @Type [nvarchar](32),
    @TagId [uniqueidentifier]
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @existingId AS int = (SELECT [Id] FROM [dbo].[Tags] WHERE [MessageId]=@MessageId AND [Type]=@Type AND [TagId] = @TagId)
    
    IF (@existingId IS NOT NULL)
    BEGIN
        DELETE FROM
            [dbo].[Tags] 
        WHERE
            [Id] = @existingId
    END
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 02/10/2023
-- Modify date: 02/10/2023
-- Description: Retrieves list of tag definitions with
--              statistics
-- ====================================================

CREATE VIEW [dbo].[vw_GetTagDefinitions]
AS
    SELECT [Id]
        ,[TagId]
        ,[Name]
        ,[Type]
        ,(SELECT COUNT(1) FROM [dbo].[Tags] WHERE [TagId] = [td].[TagId]) AS ItemCount
        ,(SELECT TOP(1) [Modified] FROM [dbo].[Tags] WHERE [TagId] = [td].[TagId] ORDER BY [Modified] DESC) AS LastUsed
    FROM [dbo].[TagDefinitions] AS td
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =========================================================
-- Author: aldras
-- Create date: 10/24/2023
-- Modify date: 10/24/2023
-- Description: Gets tags for a list of communications
-- =========================================================
CREATE   FUNCTION [dbo].[fn_GetTagCollection] (
    @CommunicationIds tvp_CommunicationIdCollection READONLY
)
RETURNS @T TABLE (
    [MessageId] NVARCHAR(64),
    [Tag] NVARCHAR(64),
    [TagId] UNIQUEIDENTIFIER)
AS
BEGIN
    INSERT INTO @T ([MessageId], [Tag], [TagId])
    SELECT 
        [tt].[CommunicationId] AS [CommunicationId],
        [td].[Name] AS [Tag],
        [tg].[TagId] AS [TagId]
    FROM 
        @CommunicationIds as tt LEFT JOIN [dbo].[Tags] AS tg ON tt.CommunicationId = tg.MessageId LEFT JOIN [dbo].[TagDefinitions] AS td ON tg.TagId = td.TagId

    RETURN
END
GO
"@,
"Support for user-defined tags."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2311, 3),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("84613ff6-c723-404b-a0c0-55e095a49f29"),
                @"
EXEC [dbo].[proc_AddComponent]
@Name='Microsoft 365 Message Center',
@InternalName='ServiceUpdateMessage',
@Capabilities='[
    "Sync",
    "Routing",
    "Notifications",
    "TaskManagement",
    "Portal",
    "CustomActions"
]',
@EntityProperties='[
    { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
    { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
    { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
    { "displayName": "Last updated", "entityProperty": "LastUpdatedTime", "type": "System.DateTime", "hidden": true },
    { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
    { "displayName": "Title", "entityProperty": "OriginalTitle", "type": "System.String", "hidden": false },
    { "displayName": "Task title", "entityProperty": "Title", "type": "System.String", "hidden": false },
    { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
    { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
    { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": false },
    { "displayName": "Severity", "entityProperty": "Severity", "type": "System.String", "hidden": false },
    { "displayName": "Services", "entityProperty": "ServicesArray", "type": "System.String[]", "hidden": false },
    { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false },
    { "displayName": "Category", "entityProperty": "Category", "type": "System.String", "hidden": false },
    { "displayName": "Major change", "entityProperty": "MajorChange", "type": "System.Boolean", "hidden": false },
    { "displayName": "Start time", "entityProperty": "StartTime", "type": "System.DateTime", "hidden": false },
    { "displayName": "End time", "entityProperty": "EndTime", "type": "System.DateTime", "hidden": false },
    { "displayName": "Action required by", "entityProperty": "ActionRequiredBy", "type": "System.DateTime", "hidden": false },
    { "displayName": "Release state", "entityProperty": "ReleaseState", "type": "System.String", "hidden": false },
    { "displayName": "Release state (last update)", "entityProperty": "ReleaseState", "type": "System.DateTime", "hidden": false },
    { "displayName": "Last modified", "entityProperty": "LastModified", "type": "System.DateTime", "hidden": false },
    { "displayName": "Help link", "entityProperty": "HelpLink", "type": "System.String", "hidden": false },
    { "displayName": "Blog link", "entityProperty": "BlogLink", "type": "System.String", "hidden": false },
    { "displayName": "External link", "entityProperty": "ExternalLink", "type": "System.String", "hidden": false }
]'
GO
EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
'2b650c59-bc1b-429c-9da9-ae09ba576cc7'
,'SERVICEUPDATEMESSAGE'
,'notificationTemplate'
,'{
"template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
    {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
    },
    {
        "text": "entity://Tags"
    },
    {
        "text": "entity://Description/translate"
    },
    {
        "facts": [
        {
            "value": "entity://ReleaseState",
            "name": "static://text/translate?value=Release state"
        },
        {
            "value": "entity://StartTime",
            "name": "static://text/translate?value=Start time"
        },
        {
            "value": "entity://EndTime",
            "name": "static://text/translate?value=End time"
        },
        {
            "value": "entity://ActionRequiredBy",
            "name": "static://text/translate?value=Action required by"
        },
        {
            "value": "entity://LastModified",
            "name": "static://text/translate?value=Last update"
        }
        ]
    },
    {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
    }
    ],
    "potentialAction": [
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
        }
        ],
        "name": "static://text/translate?value=Work item"
    },
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://HelpLink"
        }
        ],
        "name": "static://text/translate?value=Help link"
    },
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://ExternalLink"
        }
        ],
        "name": "static://text/translate?value=External link"
    },
    {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
        {
            "os": "default",
            "uri": "entity://BlogLink"
        }
        ],
        "name": "static://text/translate?value=Blog link"
    }
    ]
}
}'
,'dbo'
GO
"@,
"Added ReleaseState properties to Microsoft 365 Message Center component."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2311, 2),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("b7d94a6b-2705-4d33-8221-72128d7bfd16"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

EXECUTE [dbo].[proc_AddConnectorTypeDefinition] 
   @ConnectorId = '099ef26c-3030-46a4-aa89-bff0efe679f8'
  ,@Name = 'E-mail (via ACS)'
  ,@Type = 'notificationManager'
  ,@Icon = '/images/acs.png'
  ,@Unique = false
  ,@System = false
  ,@Parameters = '[
            {
                "id": 1,
                "name": "Endpoint",
                "displayName": "Azure Communication Service endpoint url",
                "type": "string",
                "description": "Enter Azure Communication Service endpoint url",
                "parameterType": "configuration"
            },
            {
                "id": 2,
                "name": "Sender",
                "displayName": "Sender e-mail address",
                "type": "string",
                "description": "Enter Azure Communication Service sender e-mail address",
                "parameterType": "configuration"
            },
            {
                "id": 100,
                "name": "recipients",
                "displayName": "Recipients",
                "type": "string",
                "description": "Semicolon separated list of e-mail recipients",
                "parameterType": "routing"
            }
        ]'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '099ef26c-3030-46a4-aa89-bff0efe679f8'
  ,'SERVICEUPDATEMESSAGE'
  ,'notificationTemplate'
  ,'{
    "template": {
        "Content": {
            "Subject": "entity://NotificationTitle/translate",
            "Html": "entity://Description/translate"
        }
    }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '099ef26c-3030-46a4-aa89-bff0efe679f8'
  ,'SERVICEHEALTHISSUE'
  ,'notificationTemplate'
  ,'{
    "template": {
        "Content": {
            "Subject": "entity://NotificationTitle/translate",
            "Html": "entity://Description/translate"
        }
    }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '099ef26c-3030-46a4-aa89-bff0efe679f8'
  ,'ROADMAPCOMMUNICATION'
  ,'notificationTemplate'
  ,'{
    "template": {
        "Content": {
            "Subject": "entity://NotificationTitle/translate",
            "Html": "entity://Description/translate"
        }
    }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '099ef26c-3030-46a4-aa89-bff0efe679f8'
  ,'RELEASEMESSAGE'
  ,'notificationTemplate'
  ,'{
    "template": {
        "Content": {
            "Subject": "entity://NotificationTitle/translate",
            "Html": "entity://Description/translate"
        }
    }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '099ef26c-3030-46a4-aa89-bff0efe679f8'
  ,'AZURESERVICEHEALTHALERT'
  ,'notificationTemplate'
  ,'{
    "template": {
        "Content": {
            "Subject": "entity://NotificationTitle/translate",
            "Html": "entity://Description/translate"
        }
    }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '099ef26c-3030-46a4-aa89-bff0efe679f8'
  ,'AZUREUPDATE'
  ,'notificationTemplate'
  ,'{
    "template": {
        "Content": {
            "Subject": "entity://NotificationTitle/translate",
            "Html": "entity://Description/translate"
        }
    }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '099ef26c-3030-46a4-aa89-bff0efe679f8'
  ,'OFFICE365ENDPOINTSCHANGE'
  ,'notificationTemplate'
  ,'{
    "template": {
        "Content": {
            "Subject": "entity://NotificationTitle/translate",
            "Html": "entity://Description/translate"
        }
    }
}'
  ,'dbo'
GO
"@,
"Added E-mail (via ACS) notification connector."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2311, 1),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("b7d94a6b-2705-4d33-8221-72128d7bfd16"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

EXEC [dbo].[proc_AddCustomActionType]
    @ActionTypeId = 'da3128f6-65ac-4507-ae53-e7610345391f',
    @Name = 'Service Bus',
    @Icon = '/images/serviceBus.png',
    @Parameters = '[
    {
        "internalName": "serviceBusUri",
        "displayName": "Service Bus Namespace Url",
        "type": "string"
    },
    {
        "internalName": "queueName",
        "displayName": "Queue name",
        "type": "string"
    },
    {
        "internalName": "responseQueueName",
        "displayName": "Response queue name",
        "type": "string"
    }
]'
GO
"@,
"Added Service Bus custom action type."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2311, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("b7d94a6b-2705-4d33-8221-72128d7bfd16"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

EXECUTE [dbo].[proc_AddConnectorTypeDefinition] 
   @ConnectorId = 'a13f62e6-685a-47d6-91ee-f0cedffb3410'
  ,@Name = 'Service Bus'
  ,@Type = 'notificationManager'
  ,@Icon = '/images/serviceBus.png'
  ,@Unique = false
  ,@System = false
  ,@Parameters = '[
            {
                "id": 1,
                "name": "Endpoint",
                "displayName": "Service Bus host name url",
                "type": "string",
                "description": "Enter Service Bus root url, without queue or topic name",
                "parameterType": "configuration"
            },
            {
                "id": 100,
                "name": "QueueName",
                "displayName": "Queue name",
                "type": "string",
                "description": "Enter the name of the Service Bus Queue",
                "parameterType": "routing"
            }
        ]'
GO
"@,
"Added Service Bus notification connector."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2307, 1),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("ed6a8550-54ee-44aa-ad35-002e47395aa3"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Azure Service Health Alert',
    @InternalName='AzureServiceHealthAlert',
    @Icon=null,
    @Capabilities='[
        "Sync",
        "Routing",
        "Notifications",
        "TaskManagement",
        "Webhook",
        "Portal",
        "CustomActions"
    ]',
    @EntityProperties='[
        { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
        { "displayName": "Last updated", "entityProperty": "LastUpdatedTime", "type": "System.DateTime", "hidden": true },
        { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
        { "displayName": "Title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Task title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
        { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
        { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": false },
        { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Stage", "entityProperty": "Stage", "type": "System.String", "hidden": false },
        { "displayName": "Services", "entityProperty": "Service", "type": "System.String[]", "hidden": false },
        { "displayName": "Impacted service details", "entityProperty": "ImpactedServiceDescription", "type": "System.String", "hidden": false },
        { "displayName": "Subscriptions", "entityProperty": "Subscriptions", "type": "System.String[]", "hidden": false },
        { "displayName": "Resolved", "entityProperty": "IsResolved", "type": "System.Boolean", "hidden": false },
        { "displayName": "Type", "entityProperty": "Type", "type": "System.String", "hidden": false },
        { "displayName": "Impact type", "entityProperty": "ImpactType", "type": "System.String", "hidden": false },
        { "displayName": "Region", "entityProperty": "Region", "type": "System.String", "hidden": true },
        { "displayName": "Regions", "entityProperty": "Region", "type": "System.String[]", "hidden": false },
        { "displayName": "Start time", "entityProperty": "StartTime", "type": "System.DateTime", "hidden": false },
        { "displayName": "End time", "entityProperty": "EndTime", "type": "System.DateTime", "hidden": false },
        { "displayName": "Last modified", "entityProperty": "LastModified", "type": "System.DateTime", "hidden": false }
    ]'
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Azure Updates',
    @InternalName='AzureUpdate',
    @Capabilities='[
        "Sync",
        "Routing",
        "Notifications",
        "TaskManagement",
        "Portal",
        "CustomActions"
    ]',
    @EntityProperties='[
        { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
        { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
        { "displayName": "Title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
        { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
        { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": true },
        { "displayName": "Summary", "entityProperty": "Summary", "type": "System.String", "hidden": false },
        { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Release status", "entityProperty": "ReleaseStatus", "type": "System.String", "hidden": false },
        { "displayName": "Published", "entityProperty": "Published", "type": "System.DateTime", "hidden": false },
        { "displayName": "Article", "entityProperty": "Article", "type": "System.String", "hidden": true }
    ]'
GO
"@,
"Added integration capability for Azure Service Health Alerts and Azure Updates."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2307, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("142b5197-f041-45eb-855d-1cd07da61762"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Azure Service Health Alert',
    @InternalName='AzureServiceHealthAlert',
    @Icon=null,
    @Capabilities='[
        "Sync",
        "Routing",
        "Notifications",
        "TaskManagement",
        "Webhook"
    ]',
    @EntityProperties='[
        { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
        { "displayName": "Last updated", "entityProperty": "LastUpdatedTime", "type": "System.DateTime", "hidden": true },
        { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
        { "displayName": "Title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Task title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
        { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
        { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": false },
        { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Stage", "entityProperty": "Stage", "type": "System.String", "hidden": false },
        { "displayName": "Services", "entityProperty": "Service", "type": "System.String[]", "hidden": false },
        { "displayName": "Impacted service details", "entityProperty": "ImpactedServiceDescription", "type": "System.String", "hidden": false },
        { "displayName": "Subscriptions", "entityProperty": "Subscriptions", "type": "System.String[]", "hidden": false },
        { "displayName": "Resolved", "entityProperty": "IsResolved", "type": "System.Boolean", "hidden": false },
        { "displayName": "Type", "entityProperty": "Type", "type": "System.String", "hidden": false },
        { "displayName": "Impact type", "entityProperty": "ImpactType", "type": "System.String", "hidden": false },
        { "displayName": "Region", "entityProperty": "Region", "type": "System.String", "hidden": true },
        { "displayName": "Regions", "entityProperty": "Region", "type": "System.String[]", "hidden": false },
        { "displayName": "Start time", "entityProperty": "StartTime", "type": "System.DateTime", "hidden": false },
        { "displayName": "End time", "entityProperty": "EndTime", "type": "System.DateTime", "hidden": false },
        { "displayName": "Last modified", "entityProperty": "LastModified", "type": "System.DateTime", "hidden": false }
    ]'
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Azure Updates',
    @InternalName='AzureUpdate',
    @Capabilities='[
        "Sync",
        "Routing",
        "Notifications",
        "TaskManagement",
        "Portal"
    ]',
    @EntityProperties='[
        { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
        { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
        { "displayName": "Title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
        { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
        { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": true },
        { "displayName": "Summary", "entityProperty": "Summary", "type": "System.String", "hidden": false },
        { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Release status", "entityProperty": "ReleaseStatus", "type": "System.String", "hidden": false },
        { "displayName": "Published", "entityProperty": "Published", "type": "System.DateTime", "hidden": false },
        { "displayName": "Article", "entityProperty": "Article", "type": "System.String", "hidden": true }
    ]'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
  ,'AZUREUPDATE'
  ,'notificationTemplate'
  ,'{
  "template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
      {
        "activityImage": "route://icon",
        "activityText": "entity://Summary/translate",
        "activityTitle": "entity://NotificationTitle/translate"
      },
      {
        "text": "entity://Tags"
      },
      {
        "text": "entity://Description/translate"
      },
      {
        "text": "entity://ImpactedServicesDescription/translate"
      },
      {
        "facts": [
          {
            "value": "entity://ReleaseStatus",
            "name": "static://text/translate?value=Release status"
          },
          {
            "value": "entity://Published",
            "name": "static://text/translate?value=Published"
          }
        ]
      },
      {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
      }
    ],
    "potentialAction": [
      {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
          { 
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
          }
        ],
        "name": "static://text/translate?value=Work item"
      },
      {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
          {
            "os": "default",
            "uri": "entity://Article"
          }
        ],
        "name": "static://text/translate?value=Blog article"
      }
    ]
  }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   'e865a99d-44b2-4f3d-9c94-523c30fce3b0'
  ,'AZUREUPDATE'
  ,'notificationTemplate'
  ,'{
    "template": {
      "notificationType": "AzureUpdate",
      "title": "entity://NotificationTitle/translate",
      "subtitle": "entity://Summary/translate",
      "componentImage": "route://icon",
      "properties": "entity://Tags",
      "description": "entity://Description/convertToPlainText/translate",
      "lastUpdate": "entity://Published/dateTimeToString",
      "workItemUrl": "entity://WorkItemUrl/processWorkItemUrl",
      "teamId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=TeamId",
      "channelId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=ChannelId"
    }
  }'
  ,'dbo'
GO
"@,
"Notification templates for Azure Updates."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2304, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("83a036ad-f859-4462-8a3f-6a3999bf9dbe"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE NONCLUSTERED INDEX [nci_wi_ActivityLog_284FCED4CF56C928D2B2BDB2F81D179F] ON [dbo].[ActivityLog] ([CorrelationID]) WITH (ONLINE = ON)
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ====================================================
-- Author: aldras
-- Create date: 02/10/2023
-- Modify date: 02/10/2023
-- Description: Retrieves communication information
-- ====================================================

CREATE OR ALTER VIEW [dbo].[vw_GetCommunications]
AS
    SELECT
    *,
    CASE
        WHEN (SELECT COUNT([ID]) FROM [dbo].[AllVersions] WHERE [ID]=[dbo].[Notifications].[ID]) > 1 AND DATEADD(hour, 48, [LastUpdatedTime]) >= GETUTCDATE() THEN 'UPDATED'
        WHEN (SELECT COUNT([ID]) FROM [dbo].[AllVersions] WHERE [ID]=[dbo].[Notifications].[ID]) = 1 AND DATEADD(hour, 48, [LastUpdatedTime]) >= GETUTCDATE() THEN 'NEW'
        ELSE NULL
        END AS [State]
    FROM
    [dbo].[Notifications]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ======================================================
-- Author: aldras
-- Create date: 02/10/2023
-- Modify date: 02/10/2023
-- Description: Store for viewpoint data
--              Read status for communications per user
--              Comms user marked as favorite
-- ======================================================
CREATE TABLE [dbo].[Viewpoint](
    [ID] [int] IDENTITY(1,1),
	[UserId] [uniqueidentifier] NOT NULL,
    [CommunicationId] [nvarchar](64) NOT NULL,
    [TenantId] [uniqueidentifier] NOT NULL,
    [SubscriptionId] [uniqueidentifier] NOT NULL,
    [LastReadVersion] [int] NULL,
    [Favorite] [bit] NOT NULL DEFAULT 0,
    [Archived] [bit] NOT NULL DEFAULT 0,
	[LastUpdatedTime] [datetime] NOT NULL DEFAULT GETUTCDATE()
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Viewpoint] ADD  CONSTRAINT [PK_Viewpoint] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [idx_Viewpoint] ON [dbo].[Viewpoint]
(
    [UserId] ASC,
    [CommunicationId] ASC,
	[TenantId] ASC,
	[SubscriptionId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ====================================================
-- Author: aldras
-- Create date: 02/10/2023
-- Modify date: 02/10/2023
-- Description: Sets read flag for communication
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_SetViewpointReadFlag]
    @UserId [UNIQUEIDENTIFIER],
    @CommunicationId [nvarchar](64),
    @TenantId [UNIQUEIDENTIFIER],
    @SubscriptionId [UNIQUEIDENTIFIER],
    @Read [bit]
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @existingRecordId AS INT = (
        SELECT TOP(1)
            [ID]
        FROM
            [dbo].[Viewpoint]
        WHERE
            [UserId]=@UserId AND
            [CommunicationId] = @CommunicationId AND
            [TenantId] = @TenantId AND
            [SubscriptionId] = @SubscriptionId)

    DECLARE @versionNumber AS INT = -1
    IF (@Read = 1)
    BEGIN
        SET @versionNumber = (
            SELECT TOP (1)
                [Version]
            FROM
                [dbo].[AllVersions]  
            WHERE
                [ID]=@CommunicationId -- add TenantId and SubscriptionId check when implemented
            ORDER BY
                [Version] DESC)

        IF (@versionNumber IS NULL)
        BEGIN
            SET @versionNumber = -1
        END
    END

    IF (@existingRecordId IS NULL)
    BEGIN
        INSERT INTO [dbo].[Viewpoint] (
            [UserId], [CommunicationId], [TenantId], [SubscriptionId], [LastReadVersion]
        ) VALUES (
            @UserId, @CommunicationId, @TenantId, @SubscriptionId, @versionNumber
        )
    END ELSE
    BEGIN
        UPDATE
            [dbo].[Viewpoint]
        SET
            [LastReadVersion] = @versionNumber
        WHERE
            [ID] = @existingRecordId
    END
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ====================================================
-- Author: aldras
-- Create date: 02/10/2023
-- Modify date: 02/10/2023
-- Description: Sets favorite flag for communication
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_SetViewpointFavoriteFlag]
    @UserId [UNIQUEIDENTIFIER],
    @CommunicationId [nvarchar](64),
    @TenantId [UNIQUEIDENTIFIER],
    @SubscriptionId [UNIQUEIDENTIFIER],
    @Favorite [bit]
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @existingRecordId AS INT = (
        SELECT TOP(1)
            [ID]
        FROM
            [dbo].[Viewpoint]
        WHERE
            [UserId]=@UserId AND
            [CommunicationId] = @CommunicationId AND
            [TenantId] = @TenantId AND
            [SubscriptionId] = @SubscriptionId)

    IF (@existingRecordId IS NULL)
    BEGIN
        INSERT INTO [dbo].[Viewpoint] (
            [UserId], [CommunicationId], [TenantId], [SubscriptionId], [LastReadVersion], [Favorite]
        ) VALUES (
            @UserId, @CommunicationId, @TenantId, @SubscriptionId, -1, @Favorite
        )
    END ELSE
    BEGIN
        UPDATE
            [dbo].[Viewpoint]
        SET
            [Favorite] = @Favorite
        WHERE
            [ID] = @existingRecordId
    END
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ====================================================
-- Author: aldras
-- Create date: 02/11/2023
-- Modify date: 02/11/2023
-- Description: Sets archived flag for communication
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_SetViewpointArchiveFlag]
    @UserId [UNIQUEIDENTIFIER],
    @CommunicationId [nvarchar](64),
    @TenantId [UNIQUEIDENTIFIER],
    @SubscriptionId [UNIQUEIDENTIFIER],
    @Archived [bit]
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @existingRecordId AS INT = (
        SELECT TOP(1)
            [ID]
        FROM
            [dbo].[Viewpoint]
        WHERE
            [UserId]=@UserId AND
            [CommunicationId] = @CommunicationId AND
            [TenantId] = @TenantId AND
            [SubscriptionId] = @SubscriptionId)

    IF (@existingRecordId IS NULL)
    BEGIN
        INSERT INTO [dbo].[Viewpoint] (
            [UserId], [CommunicationId], [TenantId], [SubscriptionId], [LastReadVersion], [Archived]
        ) VALUES (
            @UserId, @CommunicationId, @TenantId, @SubscriptionId, -1, @Archived
        )
    END ELSE
    BEGIN
        UPDATE
            [dbo].[Viewpoint]
        SET
            [Archived] = @Archived
        WHERE
            [ID] = @existingRecordId
    END
END
GO

CREATE TYPE
    [dbo].[tvp_CommunicationIdCollection]
AS TABLE (
    [UserId] [uniqueidentifier] NOT NULL,
    [CommunicationId] [nvarchar](64) NOT NULL,
    [TenantId] [uniqueidentifier] NOT NULL,
    [SubscriptionId] [uniqueidentifier] NOT NULL)
GO

-- =========================================================
-- Author: aldras
-- Create date: 02/11/2023
-- Modify date: 02/13/2023
-- Description: Gets viewpoint for a list of communications
-- =========================================================
CREATE OR ALTER FUNCTION [dbo].[fn_GetViewpointCollection] (
    @CommunicationIds tvp_CommunicationIdCollection READONLY
)
RETURNS @T TABLE (
    [UserId] UNIQUEIDENTIFIER,
    [CommunicationId] NVARCHAR(64),
    [TenantId] UNIQUEIDENTIFIER,
    [SubscriptionId] UNIQUEIDENTIFIER, 
    [Read] bit, 
    [Favorite] bit,
    [Archived] bit)
AS
BEGIN
    INSERT INTO @T ([UserId], [CommunicationId], [TenantId], [SubscriptionId], [Read], [Favorite], [Archived])
    SELECT 
        [tt].[UserId] AS [UserId],
        [tt].[CommunicationId] AS [CommunicationId],
        [tt].[TenantId] AS [TenantId],
        [tt].[SubscriptionId],
        IIF([LastReadVersion] IS NOT NULL AND [LastReadVersion] <> -1 AND [LastReadVersion]=(SELECT TOP(1) [Version] FROM dbo.AllVersions WHERE [ID]=vwp.CommunicationId AND [Version] IS NOT NULL ORDER BY [Version] DESC), 1, 0) AS [Read],
        [vwp].[Favorite] AS [Favorite],
        [vwp].[Archived] AS [Archived]
    FROM 
        @CommunicationIds as tt LEFT JOIN [dbo].[Viewpoint] AS vwp ON tt.UserId = vwp.UserId AND tt.CommunicationId = vwp.CommunicationId AND tt.TenantId = vwp.TenantId AND tt.SubscriptionId = vwp.SubscriptionId

    RETURN
END
GO
"@,
"List improvements support. Viewpoint support."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2301, 2),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("753cde3a-e75e-426c-b1a4-5351308e66ec"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ====================================================
-- Author: aldras
-- Create date: 01/19/2023
-- Modify date: 01/19/2023
-- Description: Text summarization cache
-- ====================================================
CREATE TABLE [dbo].[SummaryCache](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [MessageId] [nvarchar](64) NOT NULL,
    [Hash] [nvarchar](40) NOT NULL,
    [Summary] [nvarchar](max) NOT NULL,
    [Timestamp] [datetime] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[SummaryCache] ADD  CONSTRAINT [SummaryCache_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [idx_Summary] ON [dbo].[SummaryCache]
(
    [Hash] ASC,
    [Timestamp] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_Summary_MessageId] ON [dbo].[SummaryCache]
(
    [MessageId] ASC,
    [Timestamp] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SummaryCache] ADD  DEFAULT (getutcdate()) FOR [Timestamp]
GO

-- ====================================================
-- Author: aldras
-- Create date: 01/19/2023
-- Modify date: 01/19/2023
-- Description: Adds summary to summary cache
-- ====================================================
CREATE PROCEDURE [dbo].[proc_CacheSummary]
    @MessageId nvarchar(64),
    @Hash nvarchar(40),
    @Summary nvarchar(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @existingHash AS NVARCHAR(40) = (SELECT [Hash] FROM [dbo].[SummaryCache] WHERE [MessageId]=@MessageId AND [Hash]=@Hash)
    
    IF (@existingHash IS NULL)
    BEGIN
        INSERT INTO [dbo].[SummaryCache] ([MessageId], [Hash], [Summary])
        VALUES (@MessageId, @Hash, @Summary)
    END
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 01/22/2023
-- Modify date: 01/22/2023
-- Description: Retrieves latest summaries for
--              service messages
-- ====================================================
CREATE OR ALTER VIEW
    [dbo].[vw_SummaryCacheNewest]
AS
    WITH summaryCacheRN AS (
    SELECT
        *,
        ROW_NUMBER() OVER(PARTITION BY [MessageId] ORDER BY [Timestamp] DESC) AS row_number
    FROM [dbo].[SummaryCache]
    )
    SELECT
    *
    FROM summaryCacheRN
    WHERE row_number = 1;
GO
"@,
"Text summarization cache."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2301, 1),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("fb1496e5-a786-42bf-a57c-a8bfc5b83435"),
                @"
-- ====================================================
-- Author: aldras
-- Create date: 01/17/2023
-- Modify date: 01/17/2023
-- Description: Retrieves monthly usage report
-- ====================================================
CREATE VIEW [dbo].[vw_GetMonthlyUsageReport]
AS
SELECT [Id]
        ,[Service]
        ,[Active]
        ,[Inactive]
        ,[ReportDate]
    FROM
    [dbo].[MonthlyActiveUsers]
    WHERE
    [ReportDate] >= DATEADD(dd,  0, DATEADD(dd, DATEDIFF(dd, 0, DATEADD(dd, -1, GETUTCDATE())) - 30, 0)) AND
    [ReportDate] <= DATEADD(dd,  7, DATEADD(dd, DATEDIFF(dd, 0, DATEADD(dd, -1, GETUTCDATE())) - 1, 0))
GO
"@,
"New dashboard. Additional queries for new dashboard cards."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2301, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("b8161f9a-d5dc-41a5-bcb0-6bc26b9c05d9"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ====================================================
-- Author:		aldras
-- Create date: 10/07/2022
-- Modify date: 12/29/2022
-- Description:	Adds configuration value
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_SetConfigValue]
@Key nvarchar(128),
@Value nvarchar(max) NULL = NULL,
@DataType nchar(64)
AS
    BEGIN
        SET NOCOUNT ON;

        declare @existingKey as nvarchar(max) = (select [Key] from [dbo].[Config] where [Key]=@Key)

        if (@existingKey IS NULL)
        begin
            insert into [dbo].[Config] ([Key], [SerializedValue], [DataType])
            values (@Key, @Value, @DataType)
        end
        else
        begin
            UPDATE
                [dbo].[Config]
            SET
                [SerializedValue] = @Value,
                [DataType] = @DataType
            WHERE
                [Key] = @Key
        end
    END
GO
-- ====================================================
-- Author: aldras
-- Create date: 12/29/2022
-- Modify date: 12/29/2022
-- Description: Job statistics information
-- ====================================================
CREATE TABLE [dbo].[JobStatistics] (
    [Id] INT IDENTITY(1,1),
    [CorrelationId] UNIQUEIDENTIFIER,
    [Start] DATETIME,
    [End] DATETIME,
    [JobName] NVARCHAR(256),
    [ItemsCreated] INT,
    [ItemsModified] INT,
    [ItemsFailed] INT,
    [TasksCreated] INT,
    [TasksModified] INT,
    [TasksFailed] INT,
    [NotificationsSent] INT,
    [NotificationsFailed] INT
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[JobStatistics] ADD  CONSTRAINT [JobStatistics_PK] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [idx_JobStatistics] ON [dbo].[JobStatistics]
(
	[JobName] ASC,
    [Start] ASC,
    [End] ASC,
	[CorrelationId] ASC    
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ====================================================
-- Author: aldras
-- Create date: 12/29/2022
-- Modify date: 12/29/2022
-- Description: Adds or updates job statistics
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddJobStatistics]
    @CorrelationId [UNIQUEIDENTIFIER]
AS
BEGIN
    SET NOCOUNT ON;
    
    declare @existingId as UNIQUEIDENTIFIER = (SELECT [CorrelationId] from [dbo].[JobStatistics] where [CorrelationId]=@CorrelationId)
    
    declare @timestamp AS DATETIME
    DECLARE @timestampEnd AS DATETIME
    DECLARE @jobName AS nvarchar(256)

    SELECT
        @timestamp = MIN([Timestamp]),
        @timestampEnd = MAX([Timestamp]),
        @jobName = MIN(CAST('<t>' + REPLACE([Item] , '/','</t><t>') + '</t>' AS XML).value('/t[3]','varchar(256)'))
    FROM
        [dbo].[ActivityLog]
    WHERE
        [CorrelationID] = @CorrelationId
    GROUP BY
        [CorrelationID]

    if (@existingId IS NOT NULL)
    begin
        DELETE FROM 
            [dbo].[JobStatistics]
        WHERE
            [CorrelationId] = @CorrelationId
    END

    INSERT INTO [dbo].[JobStatistics]
        ([CorrelationId], [Start], [End], [JobName],
        [ItemsCreated], [ItemsModified], [ItemsFailed],
        [TasksCreated], [TasksModified], [TasksFailed],
        [NotificationsSent], [NotificationsFailed])
    SELECT
        @correlationId,
        @timestamp,
        @timestampEnd,
        @jobName,
        SUM(CASE WHEN ([Activity]='Created' AND [ItemType]='Item') THEN 1 ELSE 0 END) AS [ItemsCreated],
        SUM(CASE WHEN ([Activity]='Modified' AND [ItemType]='Item') THEN 1 ELSE 0 END) AS [ItemsModified],
        SUM(CASE WHEN (([Activity]='CreateFailed' OR [Activity]='UpdateFailed') AND [ItemType]='Item') THEN 1 ELSE 0 END) AS [ItemsFailed],
        SUM(CASE WHEN ([Activity]='Created' AND [ItemType]='Task') THEN 1 ELSE 0 END) AS [TasksCreated],
        SUM(CASE WHEN ([Activity]='Modified' AND [ItemType]='Task') THEN 1 ELSE 0 END) AS [TasksModified],
        SUM(CASE WHEN (([Activity]='CreateFailed' OR [Activity]='UpdateFailed') AND [ItemType]='Task') THEN 1 ELSE 0 END) AS [TasksFailed],
        SUM(CASE WHEN [Activity]='NotificationSent' THEN 1 ELSE 0 END) AS [NotificationsSent],
        SUM(CASE WHEN [Activity]='NotificationFailed' THEN 1 ELSE 0 END) AS [NotificationsFailed]
    FROM 
        [dbo].[ActivityLog]
    WHERE
        [CorrelationId]=@CorrelationId
END
GO

-- ==========================================================
-- Author: aldras
-- Create date: 12/29/2022
-- Modify date: 12/29/2022
-- Description: Automatically adds job statistics on
--              Activity Log change
-- ==========================================================
CREATE TRIGGER [dbo].[onAuditLogChange] ON [dbo].[ActivityLog]
AFTER INSERT, UPDATE AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @correlationId UNIQUEIDENTIFIER;

    DECLARE @cur CURSOR
    SET @cur = CURSOR STATIC FOR
        SELECT
            [CorrelationID]
        FROM
            inserted
    OPEN @cur
    WHILE 1 = 1
    BEGIN
        FETCH @cur INTO @correlationId
        IF @@fetch_status <> 0
            BREAK

        IF (@correlationId IS NOT NULL)
        BEGIN
            EXEC [dbo].[proc_AddJobStatistics] @CorrelationId=@correlationId
        END
    END
END
GO

-- ==========================================================
-- Author: aldras
-- Create date: 12/29/2022
-- Modify date: 12/29/2022
-- Description: Populate log statistics based on
--              Activity Log data
-- ==========================================================
DECLARE @correlationId AS UNIQUEIDENTIFIER
DECLARE @cur CURSOR
SET @cur = CURSOR STATIC FOR
    SELECT
        [CorrelationID]
    FROM
        [dbo].[ActivityLog]
    WHERE
        [CorrelationID] IS NOT NULL
    GROUP BY
        [CorrelationId]
OPEN @cur
WHILE 1 = 1
BEGIN
    FETCH @cur INTO @correlationId
    IF @@fetch_status <> 0
        BREAK

    EXEC dbo.proc_AddJobStatistics @CorrelationId = @correlationId
END
GO
"@,
"Job statistics support. Configuration management bugfix."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2211, 4),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("ef7c4efa-37cf-44f3-b26f-26c683306b12"),
                @"
-- ====================================================
-- Author: aldras
-- Create date: 11/17/2022
-- Modify date: 12/19/2022
-- Description: Sets or resets archive flag on item
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_SetArchiveFlag](
    @Id NVARCHAR(64),
    @Type NVARCHAR(32),
    @Archived BIT
)
AS
BEGIN
    DECLARE @existingId AS NVARCHAR(64) = (SELECT [Id] FROM [dbo].[Notifications] WHERE [ID]=@Id AND [Type]=@Type)
    IF (@existingId IS NOT NULL)
    BEGIN
        DECLARE @extendedProperties AS NVARCHAR(MAX) = (SELECT [ExtendedProperties] FROM [dbo].[Notifications] WHERE [ID]=@Id AND [Type]=@Type)
        if (@extendedProperties IS NULL)
        BEGIN
            SET @extendedProperties = '{}'
        END

        DECLARE @currentValue AS BIT = CONVERT(BIT, JSON_VALUE(@extendedProperties, '$.Archived'))
        IF(@currentValue IS NULL OR @Archived <> @currentValue)
        BEGIN
            SET @extendedProperties=JSON_MODIFY(@extendedProperties, '$.Archived', @Archived)

            UPDATE
                [dbo].[Notifications]
            SET
                [ExtendedProperties] = @extendedProperties
            WHERE
                [ID]=@Id AND
                [Type]=@Type

            RETURN 1
        END ELSE
        BEGIN
            RETURN 0
        END
    END ELSE
    BEGIN
        RETURN -1
    END
END
GO
"@,
"Archiving stored procedure bugfix."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2211, 3),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("541ed569-5938-42d6-8080-02749ac281d9"),
                @"
-- ====================================================
-- Author: aldras
-- Create date: 12/02/2022
-- Modify date: 12/02/2022
-- Description: Office 365 endpoint sets
-- ====================================================

CREATE TABLE [dbo].[Office365EndpointSets](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [ServiceArea] [NVARCHAR](255) NOT NULL,
    [ServiceAreaDisplayName] [NVARCHAR](255) NOT NULL,
    [Category] [NVARCHAR](128) NOT NULL,
    [ExpressRoute] [BIT] NOT NULL,
    [Required] [BIT] NOT NULL,
    [IPs] [NVARCHAR](MAX) NULL,
    [URLs] [NVARCHAR](MAX) NULL,
    [TCPPorts] [NVARCHAR](4000) NULL,
    [UDPPorts] [NVARCHAR](4000) NULL,
    [Notes] [NVARCHAR](MAX) NULL,
    [LastModified] [datetime] NOT NULL DEFAULT GETUTCDATE()
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [idx_Office365EndpointSets] ON [dbo].[Office365EndpointSets]
(
    [Id] ASC,
    [ServiceArea] ASC,
    [ServiceAreaDisplayName] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_Office365EndpointSetsCategories] ON [dbo].[Office365EndpointSets]
(
    [Id] ASC,
    [Category] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

-- ====================================================
-- Author:		aldras
-- Create date: 12/02/2022
-- Modify date: 12/02/2022
-- Description:	Adds Office 365 Endpoint set
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_AddOffice365EndpointSet]
@Id [INT],
@ServiceArea [NVARCHAR](255),
@ServiceAreaDisplayName [NVARCHAR](255),
@Category [NVARCHAR](128),
@ExpressRoute [BIT],
@Required [BIT],
@IPs [NVARCHAR](MAX) NULL = NULL,
@URLs [NVARCHAR](MAX) NULL = NULL,
@TCPPorts [NVARCHAR](4000) NULL = NULL,
@UDPPorts [NVARCHAR](4000) NULL = NULL,
@Notes [NVARCHAR](MAX) NULL = NULL
AS
    BEGIN
        SET NOCOUNT ON;

        DECLARE @existingId AS [INT] = (SELECT [Id] from [dbo].[Office365EndpointSets] where [Id]=@Id)

        IF (@existingId IS NULL)
        BEGIN
            SET IDENTITY_INSERT [dbo].[Office365EndpointSets] ON

            INSERT INTO [dbo].[Office365EndpointSets] ([Id], [ServiceArea], [ServiceAreaDisplayName], [Category], [ExpressRoute], [Required], [IPs], [URLs], [TCPPorts], [UDPPorts], [Notes])
            VALUES (@Id, @ServiceArea, @ServiceAreaDisplayName, @Category, @ExpressRoute, @Required, @IPs, @URLs, @TCPPorts, @UDPPorts, @Notes)
        
            SET IDENTITY_INSERT [dbo].[Office365EndpointSets] OFF
        END ELSE
        BEGIN
            UPDATE
                [dbo].[Office365EndpointSets]
            SET
                [ServiceArea] = @ServiceArea,
                [ServiceAreaDisplayName] = @ServiceAreaDisplayName,
                [Category] = @Category,
                [ExpressRoute] = @ExpressRoute,
                [Required] = @Required,
                [IPs] = @IPs,
                [URLs] = @URLs,
                [TCPPorts] = @TCPPorts,
                [UDPPorts] = @UDPPorts,
                [Notes] = @Notes,
                [LastModified] = GETUTCDATE()
                WHERE
                [Id] = @Id
        END
    END
GO

-- ====================================================
-- Author: aldras
-- Create date: 12/02/2022
-- Modify date: 12/02/2022
-- Description: Office 365 endpoint set changes
-- ====================================================

CREATE TABLE [dbo].[Office365EndpointSetChanges](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [EndpointSetId] [INT] NOT NULL,
    [Disposition] [NVARCHAR](255) NOT NULL,
    [Impact] [NVARCHAR](255) NOT NULL,
    [Version] [NVARCHAR](128) NOT NULL,
    [Previous] [NVARCHAR](MAX) NULL,
    [Current] [NVARCHAR](MAX) NULL,
    [Add] [NVARCHAR](MAX) NULL,
    [Remove] [NVARCHAR](MAX) NULL,
    [LastModified] [datetime] NOT NULL DEFAULT GETUTCDATE()
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [idx_Office365EndpointChanges] ON [dbo].[Office365EndpointSetChanges]
(
    [Id] ASC,
    [EndpointSetId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

-- ====================================================
-- Author:		aldras
-- Create date: 12/02/2022
-- Modify date: 12/02/2022
-- Description:	Adds Office 365 Endpoint set change
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_AddOffice365EndpointSetChange]
@Id [INT],
@EndpointSetId [INT],
@Disposition [NVARCHAR](255),
@Impact [NVARCHAR](255),
@Version [NVARCHAR](128),
@Previous [NVARCHAR](MAX) NULL = NULL,
@Current [NVARCHAR](MAX) NULL = NULL,
@Add [NVARCHAR](MAX) NULL = NULL,
@Remove [NVARCHAR](MAX) NULL = NULL
AS
    BEGIN
        SET NOCOUNT ON;

        DECLARE @existingId AS [INT] = (SELECT [Id] from [dbo].[Office365EndpointSetChanges] where [Id]=@Id)

        IF (@existingId IS NULL)
        BEGIN
            SET IDENTITY_INSERT [dbo].[Office365EndpointSetChanges] ON

            INSERT INTO [dbo].[Office365EndpointSetChanges] ([Id], [EndpointSetId], [Disposition], [Impact], [Version], [Previous], [Current], [Add], [Remove])
            VALUES (@Id, @EndpointSetId, @Disposition, @Impact, @Version, @Previous, @Current, @Add, @Remove)

            SET IDENTITY_INSERT [dbo].[Office365EndpointSetChanges] OFF
        END ELSE
        BEGIN
            UPDATE
                [dbo].[Office365EndpointSetChanges]
            SET
                [EndpointSetId] = @EndpointSetId,
                [Disposition] = @Disposition,
                [Impact] = @Impact,
                [Version] = @Version,
                [Previous] = @Previous,
                [Current] = @Current,
                [Add] = @Add,
                [Remove] = @Remove,
                [LastModified] = GETUTCDATE()
                WHERE
                [Id] = @Id
        END
    END
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Office 365 Endpoint Change',
    @InternalName='Office365EndpointsChange',
    @Capabilities='[
        "Sync",
        "Routing",
        "Notifications",
        "TaskManagement",
        "Portal"
    ]',
    @EntityProperties='[
        { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
        { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
        { "displayName": "Title", "entityProperty": "OriginalTitle", "type": "System.String", "hidden": false },
        { "displayName": "Task title", "entityProperty": "Title", "type": "System.String", "hidden": true },
        { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
        { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
        { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": true },
        { "displayName": "Service area", "entityProperty": "ServiceArea", "type": "System.String", "hidden": false },
        { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Disposition", "entityProperty": "Disposition", "type": "System.String", "hidden": false },
        { "displayName": "Impact", "entityProperty": "Impact", "type": "System.String", "hidden": false },
        { "displayName": "Version", "entityProperty": "Version", "type": "System.String", "hidden": false },
        { "displayName": "Action required by", "entityProperty": "ActionRequiredBy", "type": "System.DateTime", "hidden": false },
        { "displayName": "Last modified", "entityProperty": "LastModified", "type": "System.DateTime", "hidden": false },
        { "displayName": "Help link", "entityProperty": "HelpLink", "type": "System.String", "hidden": false }
    ]'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
  ,'OFFICE365ENDPOINTSCHANGE'
  ,'notificationTemplate'
  ,'{
  "template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
      {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
      },
      {
        "text": "entity://Tags"
      },
      {
        "text": "entity://Description/translate"
      },
      {
        "facts": [
          {
            "value": "entity://Version",
            "name": "static://text/translate?value=Version"
          },
          {
            "value": "entity://ServiceArea",
            "name": "static://text/translate?value=Service area"
          },
          {
            "value": "entity://Disposition",
            "name": "static://text/translate?value=Disposition"
          },
          {
            "value": "entity://Impact",
            "name": "static://text/translate?value=Impact"
          },
          {
            "value": "entity://ActionRequiredBy",
            "name": "static://text/translate?value=Action required by"
          },
          {
            "value": "entity://LastModified",
            "name": "static://text/translate?value=Last update"
          }
        ]
      },
      {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
      }
    ],
    "potentialAction": [
      {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
          {
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
          }
        ],
        "name": "static://text/translate?value=Work item"
      }
    ]
  }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   'e865a99d-44b2-4f3d-9c94-523c30fce3b0'
  ,'OFFICE365ENDPOINTSCHANGE'
  ,'notificationTemplate'
  ,'{
    "template": {
      "notificationType": "Office365EndpointsChange",
      "title": "entity://NotificationTitle/translate",
      "subtitle": "static://text/translate?value=Please review the information provided below",
      "componentImage": "route://icon",
      "properties": "entity://Tags",
      "description": "entity://Description/convertToPlainText/translate",
      "actionRequiredBy": "entity://ActionRequiredBy/dateTimeToString",
      "lastUpdate": "entity://LastModified/dateTimeToString",
      "workItemUrl": "entity://WorkItemUrl/processWorkItemUrl",
      "teamId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=TeamId",
      "channelId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=ChannelId"
    }
  }'
  ,'dbo'
GO
"@,
"Office 365 Endpoint changes - additional tables and stored procedures"
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2211, 2),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("aee3e9f6-b585-42b1-bf5f-9c697e51bd32"),
                @"
-- ====================================================
-- Author: aldras
-- Create date: 06/14/2022
-- Modify date: 11/24/2022
-- Description: Adds or updates a route
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_AddRoute]
    @RouteId UNIQUEIDENTIFIER NULL = NULL,
    @ComponentId UNIQUEIDENTIFIER,
    @Order int NULL = NULL,
    @Name [nvarchar](128),
    @Icon [nvarchar](256) NULL,
    @Language [nvarchar](32) NULL = NULL,
    @StopProcessingOnMatch [bit],
    @HideWorkItemLink [bit],
    @Conditions [nvarchar](max),
    @Connector UNIQUEIDENTIFIER,
    @ConnectorConfiguration [nvarchar](max)
AS
BEGIN
    SET NOCOUNT ON;

    if (@RouteId IS NULL)
    begin
        set @RouteId = NEWID()
    END

    declare @existingId as UNIQUEIDENTIFIER = (SELECT [RouteId] from [dbo].[Routing] where [RouteId]=@RouteId)
    
    if (@existingId IS NULL)
    begin
        IF (@Order IS NULL)
        BEGIN
        DECLARE @lastOrderNumber int = (SELECT TOP(1)
                                            [Order]
                                        FROM
                                            [dbo].[vw_GetRoutes]
                                        WHERE
                                            [ComponentId] = @ComponentId
                                        AND
                                            [ConnectorType] = (
                                                SELECT TOP(1)
                                                    [ConnectorDefinition].[Type] AS [ConnectorDefinitionType]
                                                FROM
                                                    [dbo].[Connectors] AS [Connector]
                                                LEFT OUTER JOIN
                                                    [dbo].[ConnectorDefinition] AS [ConnectorDefinition] ON [Connector].[Type] = [ConnectorDefinition].[ConnectorId]
                                                WHERE
                                                    [Connector].[ConnectorId] = @Connector
                                            )
                                        ORDER BY [Order] DESC)
            IF (@lastOrderNumber IS NULL)
            BEGIN
                set @Order = 0
            END ELSE
            BEGIN
                SET @Order = @lastOrderNumber + 1
            END
        END

        INSERT INTO [dbo].[Routing] ([RouteId], [ComponentId], [Order], [Name], [Icon], [Language], [StopProcessingOnMatch], [HideWorkItemLink], [Conditions], [Connector], [ConnectorConfiguration])
        values (@RouteId, @ComponentId, @Order, @Name, @Icon, @Language, @StopProcessingOnMatch, @HideWorkItemLink, @Conditions, @Connector, @ConnectorConfiguration)
    end else
    begin
        UPDATE [dbo].[Routing]
        SET
            [ComponentId] = @ComponentId,
            [Name] = @Name,
            [Order] = @Order,
            [Icon] = @Icon,
            [Language] = @Language,
            [StopProcessingOnMatch] = @StopProcessingOnMatch,
            [HideWorkItemLink] = @HideWorkItemLink,
            [Conditions] = @Conditions,
            [Connector] = @Connector,
            [ConnectorConfiguration] = @ConnectorConfiguration
        WHERE [RouteId]=@RouteId
    end
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 11/21/2022
-- Modify date: 11/21/2022
-- Description: Stores user profile information
-- ====================================================

CREATE TABLE [dbo].[UserProfiles](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [ObjectId] [UNIQUEIDENTIFIER] NOT NULL,
    [Properties] [nvarchar](MAX) NULL,
    [LastModified] [datetime] NOT NULL DEFAULT GETUTCDATE()
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [idx_UserProfiles] ON [dbo].[UserProfiles]
(
    [Id] ASC,
    [ObjectId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

-- ====================================================
-- Author: aldras
-- Create date: 11/21/2022
-- Modify date: 11/21/2022
-- Description: Sets a property on a user profile
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_SetUserProfileProperty](
    @ObjectId UNIQUEIDENTIFIER,
    @Name NVARCHAR(64),
    @Value NVARCHAR(MAX),
    @Type NVARCHAR(64) NULL = 'string'
)
AS
BEGIN
    DECLARE @properties AS NVARCHAR(MAX)

    DECLARE @existingId AS NVARCHAR(64) = (SELECT [Id] FROM [dbo].[UserProfiles] WHERE [ObjectId]=@ObjectId)
    IF (@existingId IS NOT NULL)
    BEGIN
        SET @properties = (SELECT [Properties] FROM [dbo].[UserProfiles] WHERE [ObjectId]=@ObjectId)
        if (@properties IS NULL)
        BEGIN
            SET @properties = '{}'
        END

        IF (@Type = 'object' OR @Type = 'array')
            BEGIN
                SET @properties=JSON_MODIFY(@properties, CONCAT('$.', @Name), JSON_QUERY(@Value))
            END
        ELSE IF (@Type = 'boolean')
            BEGIN
                SET @properties=JSON_MODIFY(@properties, CONCAT('$.', @Name), CONVERT(BIT, @Value))
            END
        ELSE IF (@Type = 'int')
            BEGIN
                SET @properties=JSON_MODIFY(@properties, CONCAT('$.', @Name), CONVERT(INT, @Value))
            END
        ELSE
            BEGIN
                SET @properties=JSON_MODIFY(@properties, CONCAT('$.', @Name), @Value)
            END

        UPDATE
            [dbo].[UserProfiles]
        SET
            [Properties] = @properties,
            [LastModified] = GETUTCDATE()
        WHERE
            [ObjectId]=@ObjectId

        RETURN 2
        
    END ELSE
    BEGIN
        SET @properties = '{}'

        IF (@Type = 'object' OR @Type = 'array')
            BEGIN
                SET @properties=JSON_MODIFY(@properties, CONCAT('$.', @Name), JSON_QUERY(@Value))
            END
        ELSE IF (@Type = 'boolean')
            BEGIN
                SET @properties=JSON_MODIFY(@properties, CONCAT('$.', @Name), CONVERT(BIT, @Value))
            END
        ELSE IF (@Type = 'int')
            BEGIN
                SET @properties=JSON_MODIFY(@properties, CONCAT('$.', @Name), CONVERT(INT, @Value))
            END
        ELSE
            BEGIN
                SET @properties=JSON_MODIFY(@properties, CONCAT('$.', @Name), @Value)
            END

        INSERT INTO
            [dbo].[UserProfiles] ([ObjectId], [Properties])
        VALUES
            (@ObjectId, @properties)
        
        RETURN 1
    END
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 11/21/2022
-- Modify date: 11/21/2022
-- Description: Sets a property on a user profile
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_SetUserProfileProperties](
    @ObjectId UNIQUEIDENTIFIER,
    @PropertiesJson NVARCHAR(MAX)
)
AS
BEGIN
    DECLARE @properties NVARCHAR(MAX) = (SELECT [Properties] FROM [dbo].[UserProfiles] WHERE [ObjectId]=@ObjectId)
    if (@properties IS NULL)
        BEGIN
            SET @properties = '{}'
        END

    DECLARE @key AS NVARCHAR(MAX)
    DECLARE @value AS NVARCHAR(MAX)
    DECLARE @type AS INT
    DECLARE @cur CURSOR
    SET @cur = CURSOR STATIC FOR
        SELECT
            *
        FROM
            OpenJson(@PropertiesJson)
    OPEN @cur
    WHILE 1 = 1
    BEGIN
        FETCH @cur INTO @key, @value, @type
        IF @@fetch_status <> 0
            BREAK

        IF (@type = 4 OR @type = 5)
            BEGIN
                SET @properties=JSON_MODIFY(@properties, CONCAT('$.', @key), JSON_QUERY(@value))
            END
        ELSE IF (@type = 3)
            BEGIN
                SET @properties=JSON_MODIFY(@properties, CONCAT('$.', @key), CONVERT(BIT, @value))
            END
        ELSE IF (@Type = 2)
            BEGIN
                SET @properties=JSON_MODIFY(@properties, CONCAT('$.', @key), CONVERT(INT, @value))
            END
        ELSE
            BEGIN
                SET @properties=JSON_MODIFY(@properties, CONCAT('$.', @key), @value)
            END
    END

    DECLARE @existingId AS NVARCHAR(64) = (SELECT [Id] FROM [dbo].[UserProfiles] WHERE [ObjectId]=@ObjectId)
    
    IF (@existingId IS NOT NULL)
    BEGIN       
        UPDATE
            [dbo].[UserProfiles]
        SET
            [Properties] = @properties,
            [LastModified] = GETUTCDATE()
        WHERE
            [ObjectId]=@ObjectId

        RETURN 2
        
    END ELSE
    BEGIN
        INSERT INTO
            [dbo].[UserProfiles] ([ObjectId], [Properties])
        VALUES
            (@ObjectId, @properties)
        
        RETURN 1
    END
END
GO
"@,
"Support for user profiles"
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2211, 1),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("00404f53-029f-4c4a-9e55-b6b2819e710a"),
                @"
-- ====================================================
-- Author: aldras
-- Create date: 11/17/2022
-- Modify date: 11/17/2022
-- Description: Adds field for additional item metadata
-- ====================================================

ALTER TABLE [dbo].[Notifications] ADD ExtendedProperties NVARCHAR(MAX) NULL
GO

-- ====================================================
-- Author: aldras
-- Create date: 11/17/2022
-- Modify date: 11/17/2022
-- Description: Sets or resets archive flag on item
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_SetArchiveFlag](
    @Id NVARCHAR(64),
    @Type NVARCHAR(32),
    @Archived BIT
)
AS
BEGIN
    DECLARE @existingId AS NVARCHAR(64) = (SELECT [Id] FROM [dbo].[Notifications] WHERE [ID]=@Id AND [Type]=@Type)
    IF (@existingId IS NOT NULL)
    BEGIN
        DECLARE @extendedProperties AS NVARCHAR(MAX) = (SELECT [ExtendedProperties] FROM [dbo].[Notifications] WHERE [ID]=@Id AND [Type]=@Type)
        if (@extendedProperties IS NULL)
        BEGIN
            SET @extendedProperties = '{}'
        END

        IF(@Archived <> CONVERT(BIT, JSON_VALUE(@extendedProperties, '$.Archived')))
        BEGIN
            SET @extendedProperties=JSON_MODIFY(@extendedProperties, '$.Archived', @Archived)

            UPDATE
                [dbo].[Notifications]
            SET
                [ExtendedProperties] = @extendedProperties
            WHERE
                [ID]=@Id AND
                [Type]=@Type

            RETURN 1
        END ELSE
        BEGIN
            RETURN 0
        END
    END ELSE
    BEGIN
        RETURN 0
    END
END
GO

CREATE OR ALTER VIEW [dbo].[AllRoadmapCommsDetailed]
AS
SELECT [ID], 
    JSON_VALUE([Data], '$.Title') AS [Title],
    JSON_VALUE([Data], '$.Status') AS [Status],
    COALESCE(JSON_QUERY([Data], '$.Tags'), JSON_QUERY([Data], '$.Category'), '[]') AS [Category],
    JSON_QUERY([Data], '$.Tags') AS [Tags],
    JSON_QUERY([Data], '$.CloudInstances') AS [CloudInstances],
    JSON_QUERY([Data], '$.Products') AS [Products],
    JSON_QUERY([Data], '$.ReleasePhase') AS [ReleasePhase],
    JSON_QUERY([Data], '$.Platforms') AS [Platforms],
    JSON_VALUE([Data], '$.Link') AS [Link],
    JSON_VALUE([Data], '$.MoreInfoLink') AS [MoreInfoLink],
    JSON_VALUE([Data], '$.Description') AS [Description],
    JSON_VALUE([Data], '$.AvailabilityDate') AS [AvailabilityDate],
    CONVERT(DATETIME2, JSON_VALUE([Data], '$.AvailabilityDateFrom')) AS [AvailabilityFrom],
    CONVERT(DATETIME2, JSON_VALUE([Data], '$.AvailabilityDateTo')) AS [AvailabilityTo], 
    CONVERT(DATETIME2, CONVERT(datetimeoffset, JSON_VALUE([Data], '$.Published'))) AS [Published],
    CONVERT(DATETIME2, CONVERT(datetimeoffset, JSON_VALUE([Data], '$.LastUpdated'))) AS [LastUpdated],
    JSON_VALUE([Data], '$.PublicPreviewDate') AS [PublicPreviewDate],
    CONVERT(DATETIME2, JSON_VALUE([Data], '$.PublicPreviewDateFrom')) AS [PublicPreviewFrom],
    CONVERT(DATETIME2, JSON_VALUE([Data], '$.PublicPreviewDateTo')) AS [PublicPreviewTo], 
    [WorkItemID],
    [WorkItemURL],
    [Public],
    [ExtendedProperties]
FROM
    [dbo].[Notifications]
WHERE
    [Type]='ROADMAPCOMMUNICATION'
GO
"@,
"Support for communication archival and restoring",
{
    Invoke-Expression -Command "$($this.m_modulePath)\PostUpgradeActions\2.0.2211.1.ps1"
}
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2211, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("4ff091df-74b4-42f9-aa97-1f06f4b7e8c3"),
                @"
BEGIN TRY
    BEGIN TRANSACTION 
        INSERT INTO [dbo].[Notifications] ([ID]
            ,[LastUpdatedTime]
            ,[Data]
            ,[WorkItemID]
            ,[WorkItemURL]
            ,[TargetSystem]
            ,[Type]
            ,[Public])
        SELECT [ID]
            ,[LastUpdatedTime]
            ,[Data]
            ,[WorkItemID]
            ,[WorkItemURL]
            ,[TargetSystem]
            ,'ROADMAPCOMMUNICATION'
            ,[Public]
        FROM [dbo].[Roadmap]

        DROP TABLE IF EXISTS [dbo].[Roadmap]

        DROP PROCEDURE IF EXISTS [dbo].[AddRoadmapNotification]
    COMMIT
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRAN

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE()
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY()
        DECLARE @ErrorState INT = ERROR_STATE()

    -- Use RAISERROR inside the CATCH block to return error  
    -- information about the original error that caused  
    -- execution to jump to the CATCH block.  
    RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
END CATCH
GO

ALTER VIEW [dbo].[AllRoadmapComms]
AS
    SELECT 
        [ID], '[' + [ID] + '] ' + JSON_VALUE([Data], '$.Title') AS [Title],
        CONVERT(DATETIME2, JSON_VALUE([Data], '$.AvailabilityDateFrom')) AS [AvailabilityFrom],
        CONVERT(DATETIME2, JSON_VALUE([Data], '$.AvailabilityDateTo')) AS AvailabilityTo, 
        JSON_QUERY([Data], '$.Category') AS [Category]
    FROM 
        [dbo].[Notifications]
    WHERE
        [Type] = 'ROADMAPCOMMUNICATION'
GO

ALTER VIEW [dbo].[AllRoadmapCommsDetailed]
AS
SELECT [ID], 
    JSON_VALUE([Data], '$.Title') AS [Title],
    JSON_VALUE([Data], '$.Status') AS [Status],
    COALESCE(JSON_QUERY([Data], '$.Tags'), JSON_QUERY([Data], '$.Category'), '[]') AS [Category],
    JSON_QUERY([Data], '$.Tags') AS [Tags],
    JSON_QUERY([Data], '$.CloudInstances') AS [CloudInstances],
    JSON_QUERY([Data], '$.Products') AS [Products],
    JSON_QUERY([Data], '$.ReleasePhase') AS [ReleasePhase],
    JSON_QUERY([Data], '$.Platforms') AS [Platforms],
    JSON_VALUE([Data], '$.Link') AS [Link],
    JSON_VALUE([Data], '$.MoreInfoLink') AS [MoreInfoLink],
    JSON_VALUE([Data], '$.Description') AS [Description],
    JSON_VALUE([Data], '$.AvailabilityDate') AS [AvailabilityDate],
    CONVERT(DATETIME2, JSON_VALUE([Data], '$.AvailabilityDateFrom')) AS [AvailabilityFrom],
    CONVERT(DATETIME2, JSON_VALUE([Data], '$.AvailabilityDateTo')) AS [AvailabilityTo], 
    CONVERT(DATETIME2, CONVERT(datetimeoffset, JSON_VALUE([Data], '$.Published'))) AS [Published],
    CONVERT(DATETIME2, CONVERT(datetimeoffset, JSON_VALUE([Data], '$.LastUpdated'))) AS [LastUpdated],
    JSON_VALUE([Data], '$.PublicPreviewDate') AS [PublicPreviewDate],
    CONVERT(DATETIME2, JSON_VALUE([Data], '$.PublicPreviewDateFrom')) AS [PublicPreviewFrom],
    CONVERT(DATETIME2, JSON_VALUE([Data], '$.PublicPreviewDateTo')) AS [PublicPreviewTo], 
    WorkItemID,
    WorkItemURL
FROM
    [dbo].[Notifications]
WHERE
    [Type]='ROADMAPCOMMUNICATION'
GO

ALTER VIEW [dbo].[vw_RoadmapStatistics]
AS
SELECT
    inDevelopment = (
        SELECT
            COUNT(*) AS ItemCount
        FROM
            [dbo].[Notifications]
        WHERE
            [Type]='ROADMAPCOMMUNICATION' AND
            (JSON_QUERY([Data], '$.Category') LIKE '%"In development"%' OR
            JSON_VALUE([Data], '$.Status') = 'In development')
    ),
    rollingOut = (
        SELECT
            COUNT(*) AS ItemCount
        FROM
            [dbo].[Notifications]
        WHERE
            [Type]='ROADMAPCOMMUNICATION' AND
            (JSON_QUERY([Data], '$.Category') LIKE '%"Rolling out"%' OR
            JSON_VALUE([Data], '$.Status') = 'Rolling out')
    )
GO

-- ====================================================
-- Author: aldras
-- Create date: 11/11/2022
-- Modify date: 11/11/2022
-- Description: Contains all versions of communications
-- ====================================================
CREATE TABLE [dbo].[AllVersions](
    [VersionID] UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
    [Version] INT NOT NULL,
    [Timestamp] DATETIME NOT NULL DEFAULT GETUTCDATE(),
	[ID] [nvarchar](64) NOT NULL,
	[LastUpdatedTime] [datetime] NOT NULL,
	[Data] [nvarchar](max) NOT NULL,
	[WorkItemID] [nvarchar](128) NULL,
	[WorkItemURL] [nvarchar](max) NULL,
	[TargetSystem] [nvarchar](64) NULL,
	[Type] [nvarchar](32) NOT NULL DEFAULT '',
	[Public] [bit] NULL DEFAULT 0,
	[Comments] [nvarchar](max) NULL,
	[LastModifiedBy] [nvarchar](512) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
ALTER TABLE [dbo].[AllVersions] ADD  CONSTRAINT [PK_AllVersions] PRIMARY KEY CLUSTERED 
(
	[VersionID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [idx_AllVersionsIdType] ON [dbo].[AllVersions]
(
	[ID] ASC,
	[Type] ASC,
    [Timestamp] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

-- ==========================================================
-- Author: aldras
-- Create date: 11/11/2022
-- Modify date: 11/11/2022
-- Description: Stores activity log records
-- ==========================================================
CREATE TABLE [dbo].[ActivityLog](
    [RowID] BIGINT IDENTITY(1,1) NOT NULL,
	[ID] [uniqueidentifier] NOT NULL DEFAULT NEWID(),
    [OrganizationID] [uniqueidentifier] NOT NULL,
    [CorrelationID] [uniqueidentifier] NULL,
	[Timestamp] [datetime] NOT NULL DEFAULT GETUTCDATE(),
	[IPAddress] [nvarchar](46) NULL,
	[User] [nvarchar](128) NULL,
	[Activity] [nvarchar](64) NOT NULL,
	[Item] [nvarchar](max) NOT NULL,
    [ItemType] [nvarchar](64) NOT NULL,
	[VersionId] [uniqueidentifier] NULL,
    [ItemUniqueId] [nvarchar](64) NOT NULL,
	[EventSource] [nvarchar](64) NOT NULL,
    [ComponentID] [uniqueidentifier] NULL,
	[ExtendedProperties] [nvarchar](max) NULL,
    [ModifiedProperties] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[ActivityLog] ADD CONSTRAINT [PK_ActivityLog] PRIMARY KEY NONCLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
CREATE UNIQUE CLUSTERED INDEX [CIX_ActivityLog] ON [dbo].[ActivityLog]([RowID])
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [idx_ActivityLog_Organization] ON [dbo].[ActivityLog]
(
	[ID] ASC,
	[OrganizationID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_ActivityLog_Activity] ON [dbo].[ActivityLog]
(
	[ID] ASC,
	[Activity] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_ActivityLog_ItemType] ON [dbo].[ActivityLog]
(
	[ID] ASC,
	[ItemType] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_ActivityLog_EventSource] ON [dbo].[ActivityLog]
(
	[ID] ASC,
	[EventSource] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

-- ====================================================
-- Author: aldras
-- Create date: 11/11/2022
-- Modify date: 11/11/2022
-- Description: Adds activity log record
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddActivityLogRecord]
    @OrganizationID [UNIQUEIDENTIFIER],
    @CorrelationID [UNIQUEIDENTIFIER] = NULL,
    @IPAddress [NVARCHAR](46) = NULL,
    @User [NVARCHAR](128) = NULL,
    @Activity [NVARCHAR](64),
    @Item [NVARCHAR](MAX),
    @ItemType [NVARCHAR](64),
    @VersionId [UNIQUEIDENTIFIER] = NULL,
    @ItemUniqueId [NVARCHAR](64),
    @EventSource [NVARCHAR](64),
    @ComponentID [UNIQUEIDENTIFIER] = NULL,
    @ExtendedProperties [NVARCHAR](MAX) = NULL,
    @ModifiedProperties [NVARCHAR](MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO [dbo].[ActivityLog] (
        [OrganizationID], [CorrelationID], [IPAddress], [User], [Activity],
        [Item], [ItemType], [VersionId], [ItemUniqueId], [EventSource], [ComponentID],
        [ExtendedProperties], [ModifiedProperties]
    )
    VALUES (
        @OrganizationID, @CorrelationID, @IPAddress, @User, @Activity,
        @Item, @ItemType, @VersionId, @ItemUniqueId, @EventSource, @ComponentID,
        @ExtendedProperties, @ModifiedProperties
    )
END
GO

CREATE FUNCTION [dbo].[Compare_JsonObject] (@SourceJSON NVARCHAR(MAX), @TargetJSON NVARCHAR(MAX))
/**
Summary: >
  This function 'diffs' a source JSON document with a target JSON document and produces an
  analysis of which properties are missing in either the source or target, or the values
  of these properties that are different. It reports on the properties and values for 
  both source and target as well as the path that references that scalar value. The 
  path reference to the object's parent is exposed in the result to enable a query to
  reference the value of any other object in the parent that is needed. 
Author: Phil Factor
Date: 06/07/2020
Revised:
	- mod: Added the parent reference to the difference report
	- Date: 09/07/2020
Database: PhilsRoutines
Examples:
   - SELECT * FROM dbo.Compare_JsonObject(@TheSourceJSON, @TheTargetJSON)
       WHERE SideIndicator <> '==';
   - SELECT *, Json_Value(@TheSourceJSON,TheParent+'.name')
       FROM dbo.Compare_JsonObject(@TheSourceJSON, @TheTargetJSON)
       WHERE SideIndicator <> '==';
Returns: >
  SideIndicator:  ( == equal, <- not in target, ->  not in source, <> not equal
  ThePath:   the JSON path used by the SQL JSON functions 
  TheKey:  the key field without the path
  TheSourceValue: the value IN the SOURCE JSON document
  TheTargetValue: the value IN the TARGET JSON document
 
**/
RETURNS @returntable TABLE
  (
  SideIndicator CHAR(2), -- == means equal, <- means not in target, -> means not in source, <> means not equal
  TheParent  NVARCHAR(MAX), --the parent object
  ThePath NVARCHAR(2000), -- the JSON path used by the SQL JSON functions 
  TheKey NVARCHAR(200), --the key field without the path
  TheSourceValue NVARCHAR(MAX), -- the value IN the SOURCE JSON document
  TheTargetValue NVARCHAR(MAX) -- the value IN the TARGET JSON document
  )
AS
  BEGIN
    IF (IsJson(@SourceJSON) = 1 AND IsJson(@TargetJSON) = 1) --don't try anything if either json is invalid
      BEGIN
        DECLARE @map TABLE --these contain all properties or array elements with scalar values
          (
          iteration INT, --the number of times that more arrays or objects were found
          SourceOrTarget CHAR(1), --is this the source 's' OR the target 't'
 		  TheParent NVARCHAR(80), --the parent object
		  ThePath NVARCHAR(80), -- the JSON path to the key/value pair or array element
          TheKey NVARCHAR(2000), --the key to the property
          TheValue NVARCHAR(MAX),-- the value
          TheType INT --the type of value it is
          );
        DECLARE @objects TABLE --this contains all the properties with arrays and objects 
          (
          iteration INT,
          SourceOrTarget CHAR(1),
		  TheParent NVARCHAR(80),
          ThePath NVARCHAR(80),
          TheKey NVARCHAR(2000),
          TheValue NVARCHAR(MAX),
          TheType INT
          );
        DECLARE @depth INT = 1; --we start in shallow water
        DECLARE @HowManyObjectsNext INT = 1, @SourceType INT, @TargetType INT;
        SELECT --firstly, we try to work out if the source is an array or object
          @SourceType = 
            CASE IsNumeric((SELECT TOP 1 [key] FROM OpenJson(@SourceJSON))) 
              WHEN 1 THEN 4 ELSE 5 END,
          @TargetType= --and if the target is an array or object
            CASE IsNumeric((SELECT TOP 1 [key] FROM OpenJson(@TargetJSON))) 
              WHEN 1 THEN 4 ELSE 5 END
        --now we insert the base objects or arrays into the object table      
        INSERT INTO @objects 
          (iteration, SourceOrTarget, TheParent, ThePath, TheKey, TheValue, TheType)
          SELECT 0, 's' AS SourceOrTarget,'' AS parent, '$' AS path, '', @SourceJSON, @SourceType;
        INSERT INTO @objects 
          (iteration, SourceOrTarget,TheParent, ThePath, TheKey, TheValue, TheType)
          SELECT 0, 't' AS SourceOrTarget, '' AS parent, '$' AS path,
          '', @TargetJSON, @TargetType;
        --we now set the depth and how many objects are in the next iteration
        SELECT @depth = 0, @HowManyObjectsNext = 2; 
        WHILE @HowManyObjectsNext > 0
          BEGIN
            INSERT INTO @map --get the scalar values into the @map table
              (iteration, SourceOrTarget, TheParent, ThePath, TheKey, TheValue, TheType)
              SELECT -- 
                o.iteration + 1, SourceOrTarget,
				ThePath,
                ThePath+CASE Thetype WHEN 4 THEN '['+[Key]+']' ELSE '.'+[key] END, 
                [key],[value],[type]
                FROM @objects AS o
                  CROSS APPLY OpenJson(TheValue)
                WHERE Type IN (1, 2, 3) AND o.iteration = @depth;
			--now we do the same for the objects and arrays
            INSERT INTO @objects (iteration, SourceOrTarget, TheParent, ThePath, TheKey,
            TheValue, TheType)
              SELECT o.iteration + 1, SourceOrTarget,ThePath,
               ThePath + CASE TheType WHEN 4 THEN '['+[Key]+']' ELSE '.'+[Key] END,
               [key],[value],[type]
              FROM @objects o 
			  CROSS APPLY OpenJson(TheValue) 
			  WHERE type IN (4,5) AND o.iteration=@depth    
           SELECT @HowManyObjectsNext=@@RowCount --how many objects or arrays?
           SELECT @depth=@depth+1 --and so to the next depth maybe
         END
--now we just do a full join on the columns we are comparing and work out the comparison
         INSERT INTO @returntable
          SELECT 
		   --first we work out the side-indicator that summarises the comparison
           CASE WHEN The_Source.TheValue=The_Target.TheValue THEN '=='
             ELSE 
             CASE  WHEN The_Source.ThePath IS NULL THEN '-' ELSE '<' end
               + CASE WHEN The_Target.ThePath IS NULL THEN '-' ELSE '>' END 
           END AS Sideindicator, 
		   --these columns could be in either table
		   Coalesce(The_source.TheParent, The_target.TheParent) AS TheParent,
           Coalesce(The_source.ThePath, The_target.ThePath) AS TheactualPath,
           Coalesce(The_source.TheKey, The_target.TheKey) AS TheKey,
           The_source.TheValue, The_target.TheValue
            FROM 
               (SELECT TheParent, ThePath, TheKey, TheValue FROM @map WHERE SourceOrTarget = 's')
			     AS The_source -- the source scalar literals
              FULL OUTER JOIN 
               (SELECT TheParent, ThePath, TheKey, TheValue FROM @map WHERE SourceOrTarget = 't')
			     AS The_target --the target scalar literals
                ON The_source.ThePath = The_target.ThePath
            ORDER BY TheactualPath;
      END;
    RETURN;
  END;
GO

CREATE TYPE CompareSetTableType AS TABLE (
    [Parent] NVARCHAR(MAX),
    [Path] NVARCHAR(MAX),   
    [Value] NVARCHAR(MAX)
)
GO

CREATE OR ALTER FUNCTION [dbo].[ProcessCompareSet] (
    @RootNode NVARCHAR(MAX),
    @CompareSet CompareSetTableType READONLY
)
RETURNS
    NVARCHAR(MAX)
AS
BEGIN
    DECLARE @jsonOutput NVARCHAR(MAX)='{}'
    DECLARE @path AS NVARCHAR(MAX) = ''
    DECLARE @parent AS NVARCHAR(MAX) = ''
    DECLARE @value AS NVARCHAR(MAX) = ''

    DECLARE @processedArrayTable AS TABLE(
        [Path] NVARCHAR(MAX),
        [RecordId] INT
    )

    DECLARE @temp CompareSetTableType

    INSERT INTO @temp
    SELECT 
        IIF (@RootNode = '', [Parent], IIF(LEN([Parent])-LEN(@RootNode) <= 0, '$', CONCAT('$.', RIGHT([Parent], LEN([Parent])-LEN(@RootNode)-1)))),
        IIF (@RootNode = '', [Path], IIF(LEN([Path])-LEN(@RootNode) <= 0, '$', CONCAT('$.', RIGHT([Path], LEN([Path])-LEN(@RootNode)-1)))),
        [Value]
    FROM
        @CompareSet
    WHERE
        [Parent] LIKE CONCAT(REPLACE(@RootNode, '[', '\['), '%') ESCAPE '\'


    DECLARE @cur CURSOR
        SET @cur = CURSOR STATIC FOR
            SELECT
                *
            FROM
                @temp
            ORDER BY [Parent]
        OPEN @cur
        WHILE 1 = 1
        BEGIN
            FETCH @cur INTO @parent, @path, @value
            IF @@fetch_status <> 0
                BREAK

            DECLARE @pathExists INT = JSON_PATH_EXISTS(@jsonOutput, @parent)
            IF (@pathExists = 0 OR @pathExists IS NULL)
            BEGIN
                DECLARE @parentObj AS NVARCHAR(MAX) = '{}'
                DECLARE @childKey AS NVARCHAR(MAX) = ''
                IF (@parent LIKE '%]')
                BEGIN -- parent is an array element
                    DECLARE @arrayRecordCount AS INT = (SELECT COUNT([RecordId]) FROM @processedArrayTable WHERE [Path] LIKE CONCAT(@parent,'%'))
                    IF (@arrayRecordCount <= 0)
                    BEGIN
                        SET @parentObj = (SELECT [dbo].[ProcessCompareSet](@parent, @CompareSet))
                        SET @parent =  LEFT(@parent, LEN(@parent) - CHARINDEX('[', REVERSE(@parent)))
                        SET @jsonOutput=JSON_MODIFY(@jsonOutput, CONCAT('append ', @parent), JSON_QUERY(@parentObj))
                    END
                    INSERT INTO @processedArrayTable VALUES (@parent, 1)
                END ELSE
                BEGIN              
                    SET @childKey = (SELECT REVERSE((SELECT TOP 1 value FROM string_split(REVERSE(@path), '.'))))
                    SET @parentObj = JSON_MODIFY(@parentObj, CONCAT('$.', @childKey), @value)
                    SET @jsonOutput=JSON_MODIFY(@jsonOutput, @parent, JSON_QUERY(@parentObj))
                END
            END ELSE
            BEGIN
                SET @jsonOutput=JSON_MODIFY(@jsonOutput, @path, @value)
            END
        END
    RETURN @jsonOutput
END
GO

CREATE OR ALTER FUNCTION [dbo].[fn_GetVersionDiff](
    @ID NVARCHAR(64),
    @Type NVARCHAR(32),
    @Version1 INT,
    @Version2 INT
)
RETURNS
    NVARCHAR(MAX)
AS
BEGIN
  DECLARE @json1 AS NVARCHAR(MAX) = (
        SELECT
            [ID]
            ,[Version]
            ,[LastUpdatedTime]
            ,[Timestamp] AS [VersionTimestamp]
            ,JSON_QUERY([Data]) AS [Data]
            ,[WorkItemID]
            ,[WorkItemURL]
            ,[TargetSystem]
            ,[Type]
            ,[Public]
            ,[Comments]
            ,JSON_QUERY([LastModifiedBy]) AS [LastModifiedBy]
        FROM
            [dbo].[AllVersions]
        WHERE
            [ID]=@ID AND
            [Type]=@Type AND
            [Version]=@Version1
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
    )

    DECLARE @json2 AS NVARCHAR(MAX) = (
        SELECT
            [ID]
            ,[Version]
            ,[LastUpdatedTime]
            ,[Timestamp] AS [VersionTimestamp]
            ,JSON_QUERY([Data]) AS [Data]
            ,[WorkItemID]
            ,[WorkItemURL]
            ,[TargetSystem]
            ,[Type]
            ,[Public]
            ,[Comments]
            ,JSON_QUERY([LastModifiedBy]) AS [LastModifiedBy]
        FROM
            [dbo].[AllVersions]
        WHERE
            [ID]=@ID AND
            [Type]=@Type AND
            [Version]=@Version2
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
    )

    DECLARE @tempTable CompareSetTableType
    DECLARE @version1Result NVARCHAR(MAX)
    DECLARE @version2Result NVARCHAR(MAX)

    if (@json1 IS NULL OR @json2 IS NULL)
    BEGIN
        SET @version1Result = IIF(@json1 IS NULL, 'null', @json1)
        SET @version2Result = IIF(@json2 IS NULL, 'null', @json2)
        
        RETURN CONCAT('{ "originalValues": ', @version1Result, ', "updatedValues": ', @version2Result, ' }')
    END

    INSERT INTO @tempTable
    SELECT [TheParent], [ThePath], [TheSourceValue] 
    FROM
        dbo.Compare_JsonObject(@json1, @json2)
    WHERE 
        [SideIndicator] <> '==' AND [TheSourceValue] IS NOT NULL


    SET @version1Result = (SELECT [dbo].[ProcessCompareSet]('', @tempTable))

    DELETE FROM @tempTable
    INSERT INTO @tempTable
    SELECT [TheParent], [ThePath], [TheTargetValue] 
    FROM
        dbo.Compare_JsonObject(@json1, @json2)
    WHERE 
        [SideIndicator] <> '==' AND [TheTargetValue] IS NOT NULL


    SET @version2Result = (SELECT [dbo].[ProcessCompareSet]('', @tempTable))

    RETURN CONCAT('{ "originalValues": ', @version1Result, ', "updatedValues": ', @version2Result, ' }')
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 11/11/2022
-- Modify date: 11/15/2022
-- Description: Adds version record for a communication
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_AddVersion]
    @Id nvarchar(64),
    @Type nvarchar(32),
    @Timestamp datetime = NULL
AS
BEGIN
SET NOCOUNT ON;
    DECLARE @existingId AS NVARCHAR(64) = (SELECT TOP(1) [ID] FROM [dbo].[Notifications] WHERE [ID] = @Id AND [Type] = @Type ORDER BY [LastUpdatedTime] DESC)

    IF (@existingId IS NOT NULL)
    BEGIN
        DECLARE @versionNumber AS INT = (SELECT TOP (1) [Version] FROM [dbo].[AllVersions] WHERE [ID] = @Id AND [Type] = @Type ORDER BY [Timestamp] DESC)
        DECLARE @oldVersionNumber AS INT
        IF (@versionNumber IS NULL)
        BEGIN
            SET @oldVersionNumber = 0
            SET @versionNumber = 1        
        END ELSE
        BEGIN
            SET @oldVersionNumber = @versionNumber
            SET @versionNumber = @versionNumber + 1
        END
        
        IF (@Timestamp IS NULL)
        BEGIN
            INSERT INTO [dbo].[AllVersions] (
                [Version], [ID], [LastUpdatedTime], [Data], [WorkItemID],
                [WorkItemURL], [TargetSystem], [Type], [Public], [Comments], [LastModifiedBy])
            SELECT TOP(1)
                @versionNumber, [ID], [LastUpdatedTime], [Data], [WorkItemID],
                [WorkItemURL], [TargetSystem], [Type], [Public], [Comments], [LastModifiedBy]
            FROM
                [dbo].[Notifications]
            WHERE
                [ID] = @Id AND
                [Type] = @Type
            ORDER BY
                [LastUpdatedTime] DESC
        END ELSE
        BEGIN
            INSERT INTO [dbo].[AllVersions] (
                [Timestamp], [Version], [ID], [LastUpdatedTime], [Data], [WorkItemID],
                [WorkItemURL], [TargetSystem], [Type], [Public], [Comments], [LastModifiedBy])
            SELECT TOP(1)
                @Timestamp, @versionNumber, [ID], [LastUpdatedTime], [Data], [WorkItemID],
                [WorkItemURL], [TargetSystem], [Type], [Public], [Comments], [LastModifiedBy]
            FROM
                [dbo].[Notifications]
            WHERE
                [ID] = @Id AND
                [Type] = @Type
            ORDER BY
                [LastUpdatedTime] DESC
        END
    END
END
GO

-- =======================================================
-- Author: aldras
-- Create date: 11/11/2022
-- Modify date: 11/15/2022
-- Description: Copy current version of all communications
--              to the dbo.AllVersions table as v1
--
--              This operation may take a couple of
--              minutes to complete
-- =======================================================

DECLARE @IdVar nvarchar(64), @TypeVar nvarchar(32), @LastUpdated DATETIME;

DECLARE @cur CURSOR
SET @cur = CURSOR STATIC FOR
    SELECT
        [ID], [Type], [LastUpdatedTime]
    FROM
        [dbo].[Notifications]
OPEN @cur
WHILE 1 = 1
BEGIN
     FETCH @cur INTO @IdVar, @TypeVar, @LastUpdated
     IF @@fetch_status <> 0
        BREAK

    EXEC [dbo].[proc_AddVersion] @Id=@IdVar, @Type=@TypeVar, @Timestamp=@LastUpdated

    DECLARE @versionNumber AS INT = (SELECT TOP (1) [Version] FROM [dbo].[AllVersions] WHERE [ID] = @IdVar AND [Type] = @TypeVar ORDER BY [Version] DESC)
    DECLARE @versionDiff AS NVARCHAR(MAX) = (SELECT [dbo].[fn_GetVersionDiff](@IdVar, @TypeVar, @versionNumber-1, @versionNumber))
    DECLARE @versionId AS UNIQUEIDENTIFIER = (SELECT TOP (1) [VersionId] FROM [dbo].[AllVersions] WHERE [ID]=@IdVar AND [Type]=@TypeVar ORDER BY [Version] DESC)
    DECLARE @activity AS NVARCHAR(32) = IIF(@versionNumber = 1, 'Created', 'Modified')
    DECLARE @item AS NVARCHAR(MAX) = CONCAT('item://', @TypeVar, '/', @IdVar)
    EXEC [dbo].[proc_AddActivityLogRecord]
        @OrganizationID = '00000000-0000-0000-0000-000000000000',
        @Activity = @activity,
        @Item = @item,
        @ItemType = 'Item',
        @VersionId = @versionId,
        @ItemUniqueId = @IdVar,
        @EventSource = 'DatabaseUpgrade',
        @ModifiedProperties = @versionDiff

END
GO

-- ==========================================================
-- Author: aldras
-- Create date: 11/11/2022
-- Modify date: 11/11/2022
-- Description: Automatically adds version record on a change
-- ==========================================================
CREATE TRIGGER [dbo].[onNotificationChanges] ON [dbo].[Notifications]
AFTER INSERT, UPDATE AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @IdVar nvarchar(64), @TypeVar nvarchar(32);

    DECLARE @cur CURSOR
    SET @cur = CURSOR STATIC FOR
        SELECT
            [ID], [Type]
        FROM
            inserted
    OPEN @cur
    WHILE 1 = 1
    BEGIN
        FETCH @cur INTO @IdVar, @TypeVar
        IF @@fetch_status <> 0
            BREAK

        EXEC [dbo].[proc_AddVersion] @Id=@IdVar, @Type=@TypeVar
    END
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 03/31/2022
-- Modify date: 11/15/2022
-- Description: Publishes notification for
--              company-wide communication
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_PublishNotification]
    @Id nvarchar(64),
    @Type nvarchar(32),
    @Comments nvarchar(max) = NULL,
    @LastModifiedBy nvarchar(512) = NULL,
    @Source nvarchar(64) = NULL
AS
    BEGIN
        SET NOCOUNT ON;

        DECLARE @isPublic AS NVARCHAR(64) = (SELECT [Public] FROM [dbo].[Notifications] WHERE [ID]=@Id AND [Type]=@Type)

        IF (@isPublic IS NOT NULL AND @isPublic=0)
        BEGIN
            UPDATE
                [dbo].[Notifications]
            SET
                [Public]=1,
                [Comments]=@Comments,
                [LastModifiedBy]=@LastModifiedBy
            WHERE
                [Id]=@Id AND
                [Type]=@Type

            DECLARE @item AS NVARCHAR(MAX) = CONCAT('item://', @Type, '/', @Id)
            DECLARE @publishingSource AS NVARCHAR(64) = IIF(@Source IS NULL, 'NotSpecified', @Source)
            DECLARE @extendedProperties AS NVARCHAR(MAX) = CONCAT('{ comments: "', @Comments, '" }')
            DECLARE @user AS NVARCHAR(128) = (SELECT JSON_VALUE(@LastModifiedBy, '$.UserName'))
            EXEC [dbo].[proc_AddActivityLogRecord]
                @OrganizationID = '00000000-0000-0000-0000-000000000000',
                @Activity = 'Published',
                @User = @user,
                @Item = @item,
                @ItemType = 'Item',
                @ItemUniqueId = @Id,
                @EventSource = @publishingSource,
                @ExtendedProperties = @extendedProperties
        END
    END
GO

-- ====================================================
-- Author: aldras
-- Create date: 03/31/2022
-- Modify date: 11/15/2022
-- Description: Unpublishes notification
-- ====================================================
CREATE OR ALTER PROCEDURE [dbo].[proc_UnpublishNotification]
    @Id nvarchar(64),
    @Type nvarchar(32),
    @LastModifiedBy nvarchar(512) = NULL,
    @Source nvarchar(64) = NULL
AS
    BEGIN
        SET NOCOUNT ON;

        DECLARE @isPublic AS NVARCHAR(64) = (SELECT [Public] FROM [dbo].[Notifications] WHERE [ID]=@Id AND [Type]=@Type)

        IF (@isPublic IS NOT NULL AND @isPublic=1)
        BEGIN
            UPDATE
                [dbo].[Notifications]
            SET
                [Public]=0,
			    [LastModifiedBy]=@LastModifiedBy
            WHERE
                [Id]=@Id AND
                [Type]=@Type

            DECLARE @item AS NVARCHAR(MAX) = CONCAT('item://', @Type, '/', @Id)
            DECLARE @publishingSource AS NVARCHAR(64) = IIF(@Source IS NULL, 'NotSpecified', @Source)
            EXEC [dbo].[proc_AddActivityLogRecord]
                @OrganizationID = '00000000-0000-0000-0000-000000000000',
                @Activity = 'Unpublished',
                @Item = @item,
                @ItemType = 'Item',
                @ItemUniqueId = @Id,
                @EventSource = @publishingSource
        END
    END
GO
"@,
"Roadmap communications migration to Notifications table, Notification versioning and Activity log"
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2208, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("2d356e53-ee3e-4bb2-b555-3ab623df6ded"),
                @"
-- =============================================================
-- Author: aldras
-- Create date: 01/10/2019
-- Modify date: 11/04/2022
-- Description: Retrieve detailed list of roadmap communications
-- =============================================================
ALTER VIEW [dbo].[AllRoadmapCommsDetailed]
AS
SELECT ID, 
        JSON_VALUE(Data, '$.Title') AS [Title],
        JSON_VALUE(Data, '$.Status') AS [Status],
        COALESCE(JSON_QUERY([Data], '$.Tags'), JSON_QUERY([Data], '$.Category'), '[]') AS [Category],
        JSON_QUERY([Data], '$.Tags') AS [Tags],
        JSON_QUERY([Data], '$.CloudInstances') AS [CloudInstances],
        JSON_QUERY([Data], '$.Products') AS [Products],
        JSON_QUERY([Data], '$.ReleasePhase') AS [ReleasePhase],
        JSON_QUERY([Data], '$.Platforms') AS [Platforms],
        JSON_VALUE(Data, '$.Link') AS [Link],
        JSON_VALUE(Data, '$.MoreInfoLink') AS [MoreInfoLink],
        JSON_VALUE(Data, '$.Description') AS [Description],
        JSON_VALUE(Data, '$.AvailabilityDate') AS [AvailabilityDate],
        CONVERT(DATETIME2, JSON_VALUE(Data, '$.AvailabilityDateFrom')) AS [AvailabilityFrom],
        CONVERT(DATETIME2, JSON_VALUE(Data, '$.AvailabilityDateTo')) AS [AvailabilityTo], 
        CONVERT(DATETIME2, CONVERT(datetimeoffset, JSON_VALUE(Data, '$.Published'))) AS [Published],
        CONVERT(DATETIME2, CONVERT(datetimeoffset, JSON_VALUE(Data, '$.LastUpdated'))) AS [LastUpdated],
        JSON_VALUE(Data, '$.PublicPreviewDate') AS [PublicPreviewDate],
        CONVERT(DATETIME2, JSON_VALUE(Data, '$.PublicPreviewDateFrom')) AS [PublicPreviewFrom],
        CONVERT(DATETIME2, JSON_VALUE(Data, '$.PublicPreviewDateTo')) AS [PublicPreviewTo], 
        WorkItemID,
        WorkItemURL
FROM    dbo.Roadmap
GO
                
-- ====================================================
-- Author: aldras
-- Create date: 10/08/2022
-- Modify date: 10/08/2022
-- Description: Retrieve list of routes
-- ====================================================
CREATE VIEW [dbo].[vw_GetComponentRouting]
AS
    SELECT 
        [Routing].*,
        [Components].[InternalName] AS [Entity]
    FROM [dbo].[Routing] AS [Routing]
    LEFT OUTER JOIN
        [dbo].[Components] AS [Components] ON [Routing].[ComponentId] = [Components].[ComponentId]
GO

-- ====================================================
-- Author:		aldras
-- Create date: 10/07/2022
-- Modify date: 10/07/2022
-- Description:	Adds configuration value
-- ====================================================
CREATE PROCEDURE [dbo].[proc_SetConfigValue]
@Key nvarchar(128),
@Value nvarchar(max),
@DataType nchar(64)
AS
    BEGIN
        SET NOCOUNT ON;

        declare @existingValue as nvarchar(max) = (select [SerializedValue] from [dbo].[Config] where [Key]=@Key)

        if (@existingValue IS NULL)
        begin
            insert into [dbo].[Config] ([Key], [SerializedValue], [DataType])
            values (@Key, @Value, @DataType)
        end
        else
        begin
            UPDATE
                [dbo].[Config]
            SET
                [SerializedValue] = @Value,
                [DataType] = @DataType
            WHERE
                [Key] = @Key
        end
    END
GO

CREATE TABLE [dbo].[ConnectorDefinitionTemplates](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [ConnectorDefinition] [uniqueidentifier] NOT NULL,
    [Entity] [nvarchar](255) NOT NULL,
    [Type] [nvarchar](255) NOT NULL,
    [Template] [nvarchar](max) NOT NULL,
    [Created] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](255) NOT NULL,
	[Modified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](255) NOT NULL
    CONSTRAINT [ConnectorDefinitionTemplates_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE INDEX idx_ConnectorDefinitionTemplates_Definition ON [dbo].[ConnectorDefinitionTemplates] ([Id] ASC, [ConnectorDefinition] ASC)
GO

CREATE INDEX idx_ConnectorDefinitionTemplates_Entity ON [dbo].[ConnectorDefinitionTemplates] ([Id] ASC, [Entity] ASC)
GO

CREATE INDEX idx_ConnectorDefinitionTemplates_Type ON [dbo].[ConnectorDefinitionTemplates] ([Id] ASC, [Type] ASC)
GO

ALTER TABLE [dbo].[ConnectorDefinitionTemplates] ADD  DEFAULT (getutcdate()) FOR [Created]
GO
ALTER TABLE [dbo].[ConnectorDefinitionTemplates] ADD  DEFAULT (getutcdate()) FOR [Modified]
GO

-- ====================================================
-- Author: aldras
-- Create date: 10/08/2022
-- Modify date: 10/08/2022
-- Description: Adds connector template
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddConnectorDefinitionTemplate]
    @ConnectorDefinition uniqueidentifier,
    @Entity nvarchar(255),
    @Type nvarchar(255),
    @Template nvarchar(max),
    @UserId nvarchar(255) = ''
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @existingId AS int = (
        SELECT
            [Id]
        FROM
            [dbo].[ConnectorDefinitionTemplates]
        WHERE
            [ConnectorDefinition]=@ConnectorDefinition AND
            [Entity]=@Entity AND
            [Type]=@Type
    )
    
    IF (@existingId IS NULL)
    BEGIN
        INSERT INTO
            [dbo].[ConnectorDefinitionTemplates] ([ConnectorDefinition], [Entity], [Type], [Template], [CreatedBy], [ModifiedBy])
        VALUES
            (@ConnectorDefinition, @Entity, @Type, @Template, @UserId, @UserId)
        END ELSE
    BEGIN
        UPDATE
            [dbo].[ConnectorDefinitionTemplates]
        SET
            [Template] = @Template,
            [Modified] = GETUTCDATE(),
            [ModifiedBy] = @UserId
        WHERE
            [Id]=@existingId
    END
END
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
  ,'SERVICEUPDATEMESSAGE'
  ,'notificationTemplate'
  ,'{
  "template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
      {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
      },
      {
        "text": "entity://Tags"
      },
      {
        "text": "entity://Description/translate"
      },
      {
        "facts": [
          {
            "value": "entity://StartTime",
            "name": "static://text/translate?value=Start time"
          },
          {
            "value": "entity://EndTime",
            "name": "static://text/translate?value=End time"
          },
          {
            "value": "entity://ActionRequiredBy",
            "name": "static://text/translate?value=Action required by"
          },
          {
            "value": "entity://LastModified",
            "name": "static://text/translate?value=Last update"
          }
        ]
      },
      {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
      }
    ],
    "potentialAction": [
      {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
          {
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
          }
        ],
        "name": "static://text/translate?value=Work item"
      },
      {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
          {
            "os": "default",
            "uri": "entity://HelpLink"
          }
        ],
        "name": "static://text/translate?value=Help link"
      },
      {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
          {
            "os": "default",
            "uri": "entity://ExternalLink"
          }
        ],
        "name": "static://text/translate?value=External link"
      },
      {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
          {
            "os": "default",
            "uri": "entity://BlogLink"
          }
        ],
        "name": "static://text/translate?value=Blog link"
      }
    ]
  }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
  ,'SERVICEHEALTHISSUE'
  ,'notificationTemplate'
  ,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "entity://Status/getStatusThemeColor",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "entity://ImpactDescription/translate",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://NotificationStatus"
            },
            {
                "text": "entity://Description/translate"
            },
            {
                "facts": [
                    {
                        "value": "entity://StartTime",
                        "name": "static://text/translate?value=Start time"
                    },
                    {
                        "value": "entity://EndTime",
                        "name": "static://text/translate?value=End time"
                    },
                    {
                        "value": "entity://LastModified",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            }
        ]
    }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
  ,'ROADMAPCOMMUNICATION'
  ,'notificationTemplate'
  ,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "entity://Category",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "facts": [
                    {
                        "value": "entity://Products",
                        "name": "static://text/translate?value=Products"
                    },
                    {
                        "value": "entity://Platforms",
                        "name": "static://text/translate?value=Platforms"
                    },
                    {
                        "value": "entity://CloudInstances",
                        "name": "static://text/translate?value=Cloud instances"
                    },
                    {
                        "value": "entity://ReleasePhase",
                        "name": "static://text/translate?value=Release phase"
                    }
                ]
            },
            {
                "text": "entity://Description/translate"
            },
            {
                "facts": [
                    {
                        "value": "entity://Id",
                        "name": "static://text/translate?value=Feature ID"
                    },
                    {
                        "value": "entity://PublicPreview",
                        "name": "static://text/translate?value=Public preview"
                    },
                    {
                        "value": "entity://Availability",
                        "name": "static://text/translate?value=Availability"
                    },
                    {
                        "value": "entity://Published/dateTimeToString",
                        "name": "static://text/translate?value=Published"
                    },
                    {
                        "value": "entity://LastModified/dateTimeToString",
                        "name": "static://text/translate?value=Last updated"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://RoadmapUrl"
                    }
                ],
                "name": "static://text/translate?value=Roadmap item"
            },
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://MoreInfoLink"
                    }
                ],
                "name": "static://text/translate?value=More info"
            }
        ]
    }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
  ,'RELEASEMESSAGE'
  ,'notificationTemplate'
  ,'{
    "template": {
        "summary": "entity://NotificationTitle/translate",
        "themeColor": "00FF00",
        "sections": [
            {
                "activityImage": "route://icon",
                "activityText": "static://text/translate?value=Please review the information provided below",
                "activityTitle": "entity://NotificationTitle/translate"
            },
            {
                "text": "entity://Tags"
            },
            {
                "text": "entity://Description/translate"
            },
            {
                "facts": [
                    {
                        "value": "entity://ReleaseDate/dateTimeToString",
                        "name": "static://text/translate?value=Release date"
                    },
                    {
                        "value": "entity://ActionRequiredBy/dateTimeToString",
                        "name": "static://text/translate?value=Action required by"
                    },
                    {
                        "value": "entity://LastModified/dateTimeToString",
                        "name": "static://text/translate?value=Last update"
                    }
                ]
            },
            {
                "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
            }
        ],
        "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "OpenUri",
                "targets": [
                    {
                        "os": "default",
                        "uri": "entity://WorkItemUrl/processWorkItemUrl"
                    }
                ],
                "name": "static://text/translate?value=Work item"
            }
        ]
    }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
  ,'AZURESERVICEHEALTHALERT'
  ,'notificationTemplate'
  ,'{
  "template": {
    "summary": "entity://NotificationTitle/translate",
    "themeColor": "00FF00",
    "sections": [
      {
        "activityImage": "route://icon",
        "activityText": "static://text/translate?value=Please review the information provided below",
        "activityTitle": "entity://NotificationTitle/translate"
      },
      {
        "text": "entity://Tags"
      },
      {
        "text": "entity://Description/translate"
      },
      {
        "text": "entity://ImpactedServicesDescription/translate"
      },
      {
        "facts": [
          {
            "value": "entity://StartTime",
            "name": "static://text/translate?value=Start time"
          },
          {
            "value": "entity://EndTime",
            "name": "static://text/translate?value=End time"
          },
          {
            "value": "entity://LastModified",
            "name": "static://text/translate?value=Last update"
          }
        ]
      },
      {
        "text": "static://text/translate?value=• ***NOTE*** *Times are provided in Coordinated Universal Time zone (UTC)*"
      }
    ],
    "potentialAction": [
      {
        "@context": "http://schema.org",
        "@type": "OpenUri",
        "targets": [
          { 
            "os": "default",
            "uri": "entity://WorkItemUrl/processWorkItemUrl"
          }
        ],
        "name": "static://text/translate?value=Work item"
      }
    ]
  }
}'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   'e865a99d-44b2-4f3d-9c94-523c30fce3b0'
  ,'SERVICEUPDATEMESSAGE'
  ,'notificationTemplate'
  ,'{
    "template": {
      "notificationType": "ServiceUpdateMessage",
      "title": "entity://NotificationTitle/translate",
      "subtitle": "static://text/translate?value=Please review the information provided below",
      "componentImage": "route://icon",
      "properties": "entity://Tags",
      "description": "entity://Description/convertToPlainText/translate",
      "releaseDate": "entity://ReleaseDate/dateTimeToString",
      "actionRequiredBy": "entity://ActionRequiredBy/dateTimeToString",
      "lastUpdate": "entity://LastModified/dateTimeToString",
      "workItemUrl": "entity://WorkItemUrl/processWorkItemUrl",
      "teamId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=TeamId",
      "channelId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=ChannelId"
    }
  }'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   'e865a99d-44b2-4f3d-9c94-523c30fce3b0'
  ,'SERVICEHEALTHISSUE'
  ,'notificationTemplate'
  ,'{
    "template": {
      "notificationType": "ServiceHealthIssue",
      "title": "entity://NotificationTitle/translate",
      "subtitle": "static://text/translate?value=Please review the information provided below",
      "componentImage": "route://icon",
      "properties": "entity://Tags",
      "description": "entity://Description/convertToPlainText/translate",
      "releaseDate": "entity://ReleaseDate/dateTimeToString",
      "actionRequiredBy": "entity://ActionRequiredBy/dateTimeToString",
      "lastUpdate": "entity://LastModified/dateTimeToString",
      "workItemUrl": "entity://WorkItemUrl/processWorkItemUrl",
      "teamId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=TeamId",
      "channelId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=ChannelId"
    }
  }
  '
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   'e865a99d-44b2-4f3d-9c94-523c30fce3b0'
  ,'ROADMAPCOMMUNICATION'
  ,'notificationTemplate'
  ,'{
    "template": {
      "notificationType": "RoadmapCommunication",
      "title": "entity://NotificationTitle/translate",
      "subtitle": "static://text/translate?value=Please review the information provided below",
      "componentImage": "route://icon",
      "properties": "entity://Tags",
      "description": "entity://Description/convertToPlainText/translate",
      "releaseDate": "entity://ReleaseDate/dateTimeToString",
      "actionRequiredBy": "entity://ActionRequiredBy/dateTimeToString",
      "lastUpdate": "entity://LastModified/dateTimeToString",
      "workItemUrl": "entity://WorkItemUrl/processWorkItemUrl",
      "teamId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=TeamId",
      "channelId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=ChannelId"
    }
  }
  '
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   'e865a99d-44b2-4f3d-9c94-523c30fce3b0'
  ,'RELEASEMESSAGE'
  ,'notificationTemplate'
  ,'{
    "template": {
      "notificationType": "ReleaseMessage",
      "title": "entity://NotificationTitle/translate",
      "subtitle": "static://text/translate?value=Please review the information provided below",
      "componentImage": "route://icon",
      "properties": "entity://Tags",
      "description": "entity://Description/convertToPlainText/translate",
      "releaseDate": "entity://ReleaseDate/dateTimeToString",
      "actionRequiredBy": "entity://ActionRequiredBy/dateTimeToString",
      "lastUpdate": "entity://LastModified/dateTimeToString",
      "workItemUrl": "entity://WorkItemUrl/processWorkItemUrl",
      "teamId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=TeamId",
      "channelId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=ChannelId"
    }
  }'
  ,'dbo'
GO

EXEC [dbo].[proc_AddConnectorDefinitionTemplate] 
   'e865a99d-44b2-4f3d-9c94-523c30fce3b0'
  ,'AZURESERVICEHEALTHALERT'
  ,'notificationTemplate'
  ,'{
    "template": {
      "notificationType": "AzureServiceHealthAlert",
      "title": "entity://NotificationTitle/translate",
      "subtitle": "static://text/translate?value=Please review the information provided below",
      "componentImage": "route://icon",
      "properties": "entity://Tags",
      "description": "entity://Description/convertToPlainText/translate",
      "releaseDate": "entity://ReleaseDate/dateTimeToString",
      "actionRequiredBy": "entity://ActionRequiredBy/dateTimeToString",
      "lastUpdate": "entity://LastModified/dateTimeToString",
      "workItemUrl": "entity://WorkItemUrl/processWorkItemUrl",
      "teamId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=TeamId",
      "channelId": "route://root/getConnectorConfigurationValue?getConnectorConfigurationValue_param1=ChannelId"
    }
  }'
  ,'dbo'
GO

CREATE TABLE [dbo].[Images](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [Name] [nvarchar](128) NOT NULL,
    [Type] [nvarchar](32) NOT NULL,
    [Format] [nvarchar](32) NOT NULL,
    [Content] [nvarchar](max)
    CONSTRAINT [Images_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE INDEX idx_ImagesName ON [dbo].[Images] ([Id] ASC, [Name] ASC)
GO

CREATE INDEX idx_ImagesType ON [dbo].[Images] ([Id] ASC, [Type] ASC)
GO

-- ====================================================
-- Author: aldras
-- Create date: 10/06/2022
-- Modify date: 10/06/2022
-- Description: Adds images to the local image store
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddImage]
    @Name nvarchar(128),
    @Type nvarchar(32),
    @Format nvarchar(32),
    @Content nvarchar(max)
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @existingImageId AS int = (SELECT [Id] FROM [dbo].[Images] WHERE [Name]=@Name AND [Type]=@Type)
    
    IF (@existingImageId IS NULL)
    BEGIN
        INSERT INTO
            [dbo].[Images] ([Name], [Type], [Format], [Content])
        VALUES
            (@Name, @Type, @Format, @Content)
        END ELSE
    BEGIN
        UPDATE
            [dbo].[Images]
        SET
            [Format] = @Format,
            [Content] = @Content
        WHERE
            [Name]=@Name AND
            [Type]=@Type
    END
END
GO

CREATE TABLE [dbo].[CustomActionTypes](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ActionTypeId] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](128) NOT NULL,
	[Icon] [nvarchar](max) NULL,
	[Parameters] [nvarchar](max) NOT NULL
    CONSTRAINT [CustomActionTypes_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE INDEX idx_CustomActionTypes_ActionId ON [dbo].[CustomActionTypes] ([Id] ASC, [ActionTypeId] ASC)
GO


CREATE INDEX idx_CustomActionTypes_Name ON [dbo].[CustomActionTypes] ([Id] ASC, [Name] ASC)
GO

ALTER TABLE [dbo].[CustomActionTypes] ADD DEFAULT (newid()) FOR [ActionTypeId]
GO

-- ====================================================
-- Author: aldras
-- Create date: 10/14/2022
-- Modify date: 10/14/2022
-- Description: Adds or updates a custom action type
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddCustomActionType]
    @ActionTypeId [uniqueidentifier],
    @Name [nvarchar](128),
    @Icon [nvarchar](max) NULL = null,
    @Parameters [nvarchar](max)
AS
BEGIN
    SET NOCOUNT ON;
    
    declare @existingId as UNIQUEIDENTIFIER = (SELECT [ActionTypeId] from [dbo].[CustomActionTypes] where [ActionTypeId]=@ActionTypeId)
    
    if (@existingId IS NULL)
    begin
        INSERT INTO [dbo].[CustomActionTypes] ([ActionTypeId], [Name], [Icon], [Parameters])
        values (@ActionTypeId, @Name, @Icon, @Parameters)
    end else
    begin
        UPDATE [dbo].[CustomActionTypes]
        SET
            [Name] = @Name,
            [Icon] = @Icon,
            [Parameters] = @Parameters
        WHERE [ActionTypeId]=@ActionTypeId
    end
END
GO

EXEC [dbo].[proc_AddCustomActionType]
    @ActionTypeId = '51ef2a0d-a192-4e91-bc7c-ca08544e5f45',
    @Name = 'HTTP Post',
    @Icon = '',
    @Parameters = '[
    {
        "internalName": "uri",
        "displayName": "Url",
        "type": "string"
    }
]'
GO

CREATE TABLE [dbo].[CustomActions](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ActionId] [uniqueidentifier] NOT NULL,
    [ComponentId] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](128) NOT NULL,
	[Icon] [nvarchar](256) NULL,
    [Type] [uniqueidentifier] NOT NULL,
	[Configuration] [nvarchar](max) NOT NULL
    CONSTRAINT [CustomActions_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE INDEX idx_CustomActions_ActionId ON [dbo].[CustomActions] ([Id] ASC, [ActionId] ASC)
GO

CREATE INDEX idx_CustomActions_ComponentId ON [dbo].[CustomActions] ([Id] ASC, [ComponentId] ASC)
GO

CREATE INDEX idx_CustomActions_Name ON [dbo].[CustomActions] ([Id] ASC, [Name] ASC)
GO

ALTER TABLE [dbo].[CustomActions] ADD DEFAULT (newid()) FOR [ActionId]
GO

-- ====================================================
-- Author: aldras
-- Create date: 10/14/2022
-- Modify date: 10/14/2022
-- Description: Adds or updates a custom action
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddCustomAction]
    @ActionId [uniqueidentifier] NULL = null,
    @ComponentId [uniqueidentifier],
    @Name [nvarchar](128),
    @Icon [nvarchar](256) NULL = null,
    @Type [uniqueidentifier],
    @Configuration [nvarchar](max)
AS
BEGIN
    SET NOCOUNT ON;

    declare @existingId as UNIQUEIDENTIFIER

    if (@ActionId IS NULL)
    BEGIN
        SET @existingId = (SELECT [ActionId] from [dbo].[CustomActions] where [Name]=@Name AND [ComponentId] = @ComponentId)

        if (@existingId IS NULL)
        begin
            INSERT INTO [dbo].[CustomActions] ([ComponentId], [Name], [Icon], [Type], [Configuration])
            values (@ComponentId, @Name, @Icon, @Type, @Configuration)
        end else
        begin
            UPDATE [dbo].[CustomActions]
            SET
                [Icon] = @Icon,
                [Type] = @Type,
                [Configuration] = @Configuration
            WHERE [Name] = @Name AND [ComponentId] = @ComponentId
        end
    END ELSE
    BEGIN
        SET @existingId = (SELECT [ActionId] from [dbo].[CustomActions] where [ActionId]=@ActionId)

        if (@existingId IS NULL)
        begin
            INSERT INTO [dbo].[CustomActions] ([ActionId], [ComponentId], [Name], [Icon], [Type], [Configuration])
            values (@ActionId, @ComponentId, @Name, @Icon, @Type, @Configuration)
        end else
        begin
            UPDATE [dbo].[CustomActions]
            SET
                [Name] = @Name,
                [ComponentId] = @ComponentId,
                [Icon] = @Icon,
                [Type] = @Type,
                [Configuration] = @Configuration
            WHERE [ActionId] = @ActionId
        end
    END
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 10/21/2022
-- Modify date: 10/21/2022
-- Description: Removes custom action
-- ====================================================
CREATE PROCEDURE [dbo].[proc_DeleteCustomAction]
    @ActionId UNIQUEIDENTIFIER
AS
BEGIN
    SET NOCOUNT ON;
    
    DELETE FROM
        [dbo].[CustomActions]
    WHERE
        [ActionId] = @ActionId
END
GO

"@,
"Image store, connector templates, configuration enhancements",
{
    Invoke-Expression -Command "$($this.m_modulePath)\PostUpgradeActions\2.0.2208.0.ps1"
}
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2207, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("c0a188fc-99b6-444b-bd8c-d0773deecc82"),
                @"
CREATE TABLE [dbo].[MonthlyActiveUsers](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [Service] [nvarchar](128) NOT NULL,
    [Active] [int] NOT NULL,
    [Inactive] [int] NOT NULL,
    [ReportDate] [datetime] NOT NULL DEFAULT GETUTCDATE()
    CONSTRAINT [MonthlyActiveUsers_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE INDEX idx_MonthlyActiveUsersService ON [dbo].[MonthlyActiveUsers] ([Id] ASC, [Service] ASC)
GO

CREATE INDEX idx_MonthlyActiveUsersReportDate ON [dbo].[MonthlyActiveUsers] ([Id] ASC, [ReportDate] ASC, [Service] ASC)
GO

-- ====================================================
-- Author: aldras
-- Create date: 08/02/2022
-- Modify date: 08/02/2022
-- Description: Adds Microsoft 365 usage statistics
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddMonthlyActiveUsersStats]
    @Service nvarchar(128),
    @Active int,
    @Inactive int,
    @ReportDate datetime
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @existingStatId AS int = (SELECT [Id] FROM [dbo].[MonthlyActiveUsers] WHERE [Service]=@Service AND [ReportDate]=@ReportDate)
    
    IF (@existingStatId IS NULL)
    BEGIN
        INSERT INTO
            [dbo].[MonthlyActiveUsers] ([Service], [Active], [Inactive], [ReportDate])
        VALUES
            (@Service, @Active, @Inactive, @ReportDate)
        END ELSE
    BEGIN
        UPDATE
            [dbo].[MonthlyActiveUsers]
        SET
            [Active] = @Active,
            [Inactive] = @Inactive
        WHERE
            [Service]=@Service AND
            [ReportDate]=@ReportDate
    END
END
GO

-- ============================================================
-- Author: aldras
-- Create date: 08/02/2022
-- Modify date: 08/02/2022
-- Description: Retrieve newest Microsoft 365 usage statistics
-- ============================================================
CREATE VIEW [dbo].[GetLatestMonthlyUsageReport]
AS
        SELECT
        [Service],
        [Active],
        [Inactive],
        [ReportDate]
    FROM (
        SELECT
            [Service],
            [Active],
            [Inactive],
            [ReportDate],
            ROW_NUMBER() OVER (PARTITION BY [Service] ORDER BY [ReportDate] DESC) as MAX_ID
        FROM
            [dbo].[MonthlyActiveUsers]) mau
    WHERE MAX_ID = 1
GO                
"@,
"Monthly active users statistics."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2206, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("166b6149-e7cb-4fa2-9d5b-a6ff0f0d1448"),
                @"
CREATE TABLE [dbo].[ConnectorDefinition](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [ConnectorId] UNIQUEIDENTIFIER NOT NULL,
    [Name] [nvarchar](128) NOT NULL,
    [Type] [nvarchar](64) NOT NULL,
    [Icon] [nvarchar](256) NULL,
    [Unique] [bit] NOT NULL,
    [System] [bit] NOT NULL,
    [Parameters] [nvarchar](max) NOT NULL
    CONSTRAINT [ConnectorDefinition_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE INDEX idx_ConnectorDefinitionTypes ON [dbo].[ConnectorDefinition] ([Id] ASC, [Type] ASC)
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/14/2022
-- Modify date: 06/14/2022
-- Description: Adds connector type definition
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddConnectorTypeDefinition]
    @ConnectorId UNIQUEIDENTIFIER,
    @Name [nvarchar](128),
    @Type [nvarchar](64),
    @Icon [nvarchar](256),
    @Unique [bit],
    @System [bit],
    @Parameters [nvarchar](max)
AS
BEGIN
    SET NOCOUNT ON;
    
    declare @existingId as UNIQUEIDENTIFIER = (SELECT [ConnectorId] from [dbo].[ConnectorDefinition] where [ConnectorId]=@ConnectorId)
    
    if (@existingId IS NULL)
    begin
        INSERT INTO [dbo].[ConnectorDefinition] ([ConnectorId], [Name], [Type], [Icon], [Unique], [System], [Parameters])
        values (@ConnectorId, @Name, @Type, @Icon, @Unique, @System, @Parameters)
    end else
    begin
        UPDATE [dbo].[ConnectorDefinition]
        SET
            [Name] = @Name,
            [Type] = @Type,
            [Icon] = @Icon,
            [Unique] = @Unique,
            [System] = @System,
            [Parameters] = @Parameters
        WHERE [ConnectorId]=@ConnectorId
    end
END
GO

EXECUTE [dbo].[proc_AddConnectorTypeDefinition] 
   @ConnectorId = '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
  ,@Name = 'Teams (via WebHook - deprecated)'
  ,@Type = 'notificationManager'
  ,@Icon = '/images/teams.png'
  ,@Unique = true
  ,@System = true
  ,@Parameters = '[
            {
                "id": 100,
                "name": "TeamsChannelUri",
                "displayName": "Teams channel incoming webhook url",
                "type": "string",
                "description": "Enter the url of the Teams channel",
                "parameterType": "routing"
            }
        ]'
GO

EXECUTE [dbo].[proc_AddConnectorTypeDefinition] 
   @ConnectorId = 'e865a99d-44b2-4f3d-9c94-523c30fce3b0'
  ,@Name = 'Teams (via Logic App)'
  ,@Type = 'notificationManager'
  ,@Icon = '/images/logicApps.png'
  ,@Unique = false
  ,@System = false
  ,@Parameters = '[
            {
                "id": 1,
                "name": "Endpoint",
                "displayName": "Logic App endpoint url",
                "type": "string",
                "description": "Enter the URI of the Logic App",
                "parameterType": "configuration"
            },
            {
                "id": 100,
                "name": "teamId",
                "displayName": "Team ID",
                "type": "string",
                "description": "Enter the id of the target Microsoft Teams team",
                "parameterType": "routing"
            },
            {
                "id": 101,
                "name": "channelId",
                "displayName": "Channel ID",
                "type": "string",
                "description": "Enter the id of the target Microsoft Teams channel",
                "parameterType": "routing"
            }
        ]'
GO

CREATE TABLE [dbo].[Connectors](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [ConnectorId] UNIQUEIDENTIFIER NOT NULL,
    [Name] [nvarchar](128) NOT NULL,
    [Type] UNIQUEIDENTIFIER,
    [Configuration] [nvarchar](max) NOT NULL
    CONSTRAINT [Connector_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/14/2022
-- Modify date: 06/14/2022
-- Description: Adds connector
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddConnector]
    @ConnectorId UNIQUEIDENTIFIER,
    @Name [nvarchar](128),
    @Type UNIQUEIDENTIFIER,
    @Configuration [nvarchar](max)
AS
BEGIN
    SET NOCOUNT ON;
    
    declare @existingId as UNIQUEIDENTIFIER = (SELECT [ConnectorId] from [dbo].[Connectors] where [ConnectorId]=@ConnectorId)
    
    if (@existingId IS NULL)
    begin
        INSERT INTO [dbo].[Connectors] ([ConnectorId], [Name], [Type], [Configuration])
        values (@ConnectorId, @Name, @Type, @Configuration)
    end else
    begin
        UPDATE [dbo].[Connectors]
        SET
            [Name] = @Name,
            [Type] = @Type,
            [Configuration] = @Configuration
        WHERE [ConnectorId]=@ConnectorId
    end
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/15/2022
-- Modify date: 06/15/2022
-- Description: Removes connector and associated
--              routing rules
-- ====================================================
CREATE PROCEDURE [dbo].[proc_DeleteConnector]
    @ConnectorId UNIQUEIDENTIFIER
AS
BEGIN
    SET NOCOUNT ON;
    
    DELETE FROM
        [dbo].[Routing]
    WHERE
        [Connector] = @ConnectorId

    DELETE FROM
        [dbo].[Connectors]
    WHERE
        [ConnectorId] = @ConnectorId
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/14/2022
-- Modify date: 06/14/2022
-- Description: Retrieve list of connectors
-- ====================================================
CREATE VIEW [dbo].[vw_GetConnectors]
AS
    SELECT 
        [Connector].*,
        [ConnectorDefinition].[Name] AS [ConnectorTypeName],
        [ConnectorDefinition].[Icon] AS [Icon],
        [ConnectorDefinition].[System] AS [System],
        [ConnectorDefinition].[Parameters] AS [ParameterDefinition],
        [ConnectorDefinition].[Type] AS [ConnectorType]
    FROM [dbo].[Connectors] AS [Connector]
    LEFT OUTER JOIN
        [dbo].[ConnectorDefinition] AS [ConnectorDefinition] on [Connector].[Type] = [ConnectorDefinition].[ConnectorId]
GO

EXECUTE [dbo].[proc_AddConnector] 
   @ConnectorId = 'e3990fbe-4fb9-4967-884c-2dc76ac819f4'
  ,@Name = 'Microsoft Teams'
  ,@Type = '2b650c59-bc1b-429c-9da9-ae09ba576cc7'
  ,@Configuration = '[]'
GO

CREATE TABLE [dbo].[Components](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [ComponentId] UNIQUEIDENTIFIER NOT NULL UNIQUE DEFAULT NEWID(),
    [Name] [nvarchar](128) NOT NULL,
    [InternalName] [nvarchar](128) NOT NULL UNIQUE,
    [Icon] [nvarchar](256) NULL,
    [Capabilities] [nvarchar](max) NOT NULL,
    [EntityProperties] [nvarchar](max) NULL
    CONSTRAINT [Components_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/15/2022
-- Modify date: 06/15/2022
-- Description: Adds or updates a component
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddComponent]
    @Name [nvarchar](128),
    @InternalName [nvarchar](128),
    @Icon [nvarchar](256) NULL = null,
    @Capabilities [nvarchar](max),
    @EntityProperties [nvarchar](max) NULL = null
AS
BEGIN
    SET NOCOUNT ON;
    
    declare @existingId as UNIQUEIDENTIFIER = (SELECT [ComponentId] from [dbo].[Components] where [InternalName]=@InternalName)
    
    if (@existingId IS NULL)
    begin
        INSERT INTO [dbo].[Components] ([Name], [InternalName], [Icon], [Capabilities], [EntityProperties])
        values (@Name, @InternalName, @Icon, @Capabilities, @EntityProperties)
    end else
    begin
        UPDATE [dbo].[Components]
        SET
            [Name] = @Name,
            [Icon] = @Icon,
            [Capabilities] = @Capabilities,
            [EntityProperties] = @EntityProperties
        WHERE [InternalName]=@InternalName
    end
END
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Microsoft 365 Message Center',
    @InternalName='ServiceUpdateMessage',
    @Capabilities='[
        "Sync",
        "Routing",
        "Notifications",
        "TaskManagement",
        "Portal",
        "CustomActions"
    ]',
    @EntityProperties='[
        { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
        { "displayName": "Last updated", "entityProperty": "LastUpdatedTime", "type": "System.DateTime", "hidden": true },
        { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
        { "displayName": "Title", "entityProperty": "OriginalTitle", "type": "System.String", "hidden": false },
        { "displayName": "Task title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
        { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
        { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": false },
        { "displayName": "Severity", "entityProperty": "Severity", "type": "System.String", "hidden": false },
        { "displayName": "Services", "entityProperty": "ServicesArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Category", "entityProperty": "Category", "type": "System.String", "hidden": false },
        { "displayName": "Major change", "entityProperty": "MajorChange", "type": "System.Boolean", "hidden": false },
        { "displayName": "Start time", "entityProperty": "StartTime", "type": "System.DateTime", "hidden": false },
        { "displayName": "End time", "entityProperty": "EndTime", "type": "System.DateTime", "hidden": false },
        { "displayName": "Action required by", "entityProperty": "ActionRequiredBy", "type": "System.DateTime", "hidden": false },
        { "displayName": "Last modified", "entityProperty": "LastModified", "type": "System.DateTime", "hidden": false },
        { "displayName": "Help link", "entityProperty": "HelpLink", "type": "System.String", "hidden": false },
        { "displayName": "Blog link", "entityProperty": "BlogLink", "type": "System.String", "hidden": false },
        { "displayName": "External link", "entityProperty": "ExternalLink", "type": "System.String", "hidden": false }
    ]'
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Microsoft 365 Service Health',
    @InternalName='ServiceHealthIssue',
    @Icon=null,
    @Capabilities='[
        "Sync",
        "Routing",
        "Notifications",
        "TaskManagement",
        "Portal",
        "CustomActions"
    ]',
    @EntityProperties='[
        { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
        { "displayName": "Last updated", "entityProperty": "LastUpdatedTime", "type": "System.DateTime", "hidden": true },
        { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
        { "displayName": "Title", "entityProperty": "OriginalTitle", "type": "System.String", "hidden": false },
        { "displayName": "Task title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
        { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
        { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": false },
        { "displayName": "Service", "entityProperty": "Service", "type": "System.String", "hidden": false },
        { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Feature", "entityProperty": "Feature", "type": "System.String", "hidden": false },
        { "displayName": "Feature group", "entityProperty": "FeatureGroup", "type": "System.String", "hidden": false },
        { "displayName": "Status", "entityProperty": "Status", "type": "System.String", "hidden": false },
        { "displayName": "Origin", "entityProperty": "Origin", "type": "System.String", "hidden": false },
        { "displayName": "Resolved", "entityProperty": "Resolved", "type": "System.Boolean", "hidden": false },
        { "displayName": "Impact description", "entityProperty": "ImpactDescription", "type": "System.String", "hidden": false },
        { "displayName": "Start time", "entityProperty": "StartTime", "type": "System.DateTime", "hidden": false },
        { "displayName": "End time", "entityProperty": "EndTime", "type": "System.DateTime", "hidden": false },
        { "displayName": "Last modified", "entityProperty": "LastModified", "type": "System.DateTime", "hidden": false },
        { "displayName": "High impact", "entityProperty": "HighImpact", "type": "System.String", "hidden": false }
    ]'
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Microsoft 365 Roadmap',
    @InternalName='RoadmapCommunication',
    @Icon=null,
    @Capabilities='[
        "Sync",
        "Routing",
        "Notifications",
        "TaskManagement",
        "Portal",
        "CustomActions"
    ]',
    @EntityProperties='[
        { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
        { "displayName": "Last updated", "entityProperty": "LastUpdatedTime", "type": "System.DateTime", "hidden": true },
        { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
        { "displayName": "Title", "entityProperty": "OriginalTitle", "type": "System.String", "hidden": false },
        { "displayName": "Task title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
        { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
        { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": false },
        { "displayName": "Status", "entityProperty": "Status", "type": "System.String", "hidden": false },
        { "displayName": "Tags", "entityProperty": "CategoryArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Roadmap item url", "entityProperty": "RoadmapUrl", "type": "System.String", "hidden": false },
        { "displayName": "More information", "entityProperty": "MoreInfoLink", "type": "System.String", "hidden": false },
        { "displayName": "Products", "entityProperty": "ProductsArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Cloud instances", "entityProperty": "CloudInstancesArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Release phase", "entityProperty": "ReleasePhaseArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Platforms", "entityProperty": "PlatformsArray", "type": "System.String[]", "hidden": false },
        { "displayName": "General availability", "entityProperty": "Availability", "type": "System.String", "hidden": false },
        { "displayName": "GA date (from)", "entityProperty": "AvailabilityFrom", "type": "System.DateTime", "hidden": false },
        { "displayName": "GA date (to)", "entityProperty": "AvailabilityTo", "type": "System.DateTime", "hidden": false },
        { "displayName": "Public preview", "entityProperty": "PublicPreview", "type": "System.String", "hidden": false },
        { "displayName": "Public preview date (from)", "entityProperty": "PublicPreviewFrom", "type": "System.DateTime", "hidden": false },
        { "displayName": "Public preview date (to)", "entityProperty": "PublicPreviewTo", "type": "System.DateTime", "hidden": false },
        { "displayName": "Published", "entityProperty": "Published", "type": "System.DateTime", "hidden": false }
    ]'
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Microsoft Service Health Hub',
    @InternalName='ReleaseMessage',
    @Capabilities='[
        "Sync",
        "Routing",
        "Notifications",
        "TaskManagement"
    ]',
    @EntityProperties='[
        { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
        { "displayName": "Last updated", "entityProperty": "LastUpdatedTime", "type": "System.DateTime", "hidden": true },
        { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
        { "displayName": "Title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Task title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
        { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
        { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": false },
        { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Release date", "entityProperty": "ReleaseDate", "type": "System.DateTime", "hidden": false },
        { "displayName": "Action required by", "entityProperty": "ActionRequiredBy", "type": "System.DateTime", "hidden": false },
        { "displayName": "Last modified", "entityProperty": "LastModified", "type": "System.DateTime", "hidden": false }
    ]'
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Azure Service Health Alert',
    @InternalName='AzureServiceHealthAlert',
    @Icon=null,
    @Capabilities='[
        "Sync",
        "Routing",
        "Notifications",
        "TaskManagement",
        "Webhook"
    ]',
    @EntityProperties='[
        { "displayName": "Id", "entityProperty": "Id", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemId", "entityProperty": "WorkItemId", "type": "System.String", "hidden": true },
        { "displayName": "WorkItemUrl", "entityProperty": "WorkItemUrl", "type": "System.String", "hidden": true },
        { "displayName": "Last updated", "entityProperty": "LastUpdatedTime", "type": "System.DateTime", "hidden": true },
        { "displayName": "Raw data", "entityProperty": "RawData", "type": "System.Object", "hidden": true },
        { "displayName": "Title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Task title", "entityProperty": "Title", "type": "System.String", "hidden": false },
        { "displayName": "Notification title", "entityProperty": "NotificationTitle", "type": "System.String", "hidden": true },
        { "displayName": "Description", "entityProperty": "Description", "type": "System.String", "hidden": false },
        { "displayName": "History", "entityProperty": "History", "type": "System.String", "hidden": false },
        { "displayName": "Tags", "entityProperty": "TagsArray", "type": "System.String[]", "hidden": false },
        { "displayName": "Stage", "entityProperty": "Stage", "type": "System.String", "hidden": false },
        { "displayName": "Services", "entityProperty": "Service", "type": "System.String[]", "hidden": false },
        { "displayName": "Impacted service details", "entityProperty": "ImpactedServiceDescription", "type": "System.String", "hidden": false },
        { "displayName": "Subscriptions", "entityProperty": "Subscriptions", "type": "System.String[]", "hidden": false },
        { "displayName": "Resolved", "entityProperty": "IsResolved", "type": "System.Boolean", "hidden": false },
        { "displayName": "Type", "entityProperty": "Type", "type": "System.String", "hidden": false },
        { "displayName": "Impact type", "entityProperty": "ImpactType", "type": "System.String", "hidden": false },
        { "displayName": "Region", "entityProperty": "Region", "type": "System.String", "hidden": true },
        { "displayName": "Regions", "entityProperty": "Region", "type": "System.String[]", "hidden": false },
        { "displayName": "Start time", "entityProperty": "StartTime", "type": "System.DateTime", "hidden": false },
        { "displayName": "End time", "entityProperty": "EndTime", "type": "System.DateTime", "hidden": false },
        { "displayName": "Last modified", "entityProperty": "LastModified", "type": "System.DateTime", "hidden": false }
    ]'
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Microsoft 365 license analytics',
    @InternalName='LicenseAnalytics',
    @Icon=null,
    @Capabilities='[
        "Sync"
    ]'
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Task mapping',
    @InternalName='TaskMapping',
    @Icon=null,
    @Capabilities='[]'
GO

EXEC [dbo].[proc_AddComponent]
    @Name='Microsoft 365 license forecast - HR data import',
    @InternalName='HRStatsImport',
    @Icon=null,
    @Capabilities='[
        "Webhook"
    ]'
GO

CREATE TABLE [dbo].[Routing](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [RouteId] UNIQUEIDENTIFIER NOT NULL,
    [ComponentId] UNIQUEIDENTIFIER NOT NULL,
    [Order] int NOT NULL,
    [Name] [nvarchar](128) NOT NULL,
    [Icon] [nvarchar](256) NULL,
    [Language] [nvarchar](32) NULL,
    [StopProcessingOnMatch] [bit] NOT NULL,
    [HideWorkItemLink] [bit] NOT NULL,
    [Conditions] [nvarchar](max) NOT NULL,
    [Connector] UNIQUEIDENTIFIER,
    [ConnectorConfiguration] [nvarchar](max) NOT NULL
    CONSTRAINT [Routing_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE INDEX idx_RoutingOrder ON [dbo].[Routing] ([Id] ASC, [Connector] ASC, [Order] ASC)
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/14/2022
-- Modify date: 06/14/2022
-- Description: Retrieve list of routes
-- ====================================================
CREATE VIEW [dbo].[vw_GetRoutes]
AS
    SELECT 
        [Routing].*,
        [Connector].[Name] AS [ConnectorName],
        [ConnectorDefinition].[Type] AS [ConnectorType]
    FROM [dbo].[Routing] AS [Routing]
    LEFT OUTER JOIN
        [dbo].[Connectors] AS [Connector] ON [Routing].[Connector] = [Connector].[ConnectorId]
    LEFT OUTER JOIN
        [dbo].[ConnectorDefinition] AS [ConnectorDefinition] on [Connector].[Type] = [ConnectorDefinition].[ConnectorId]
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/14/2022
-- Modify date: 06/15/2022
-- Description: Adds or updates a route
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddRoute]
    @RouteId UNIQUEIDENTIFIER NULL = NULL,
    @ComponentId UNIQUEIDENTIFIER,
    @Order int NULL = NULL,
    @Name [nvarchar](128),
    @Icon [nvarchar](256) NULL,
    @Language [nvarchar](32) NULL = NULL,
    @StopProcessingOnMatch [bit],
    @HideWorkItemLink [bit],
    @Conditions [nvarchar](max),
    @Connector UNIQUEIDENTIFIER,
    @ConnectorConfiguration [nvarchar](max)
AS
BEGIN
    SET NOCOUNT ON;

    if (@RouteId IS NULL)
    begin
        set @RouteId = NEWID()
    END

    declare @existingId as UNIQUEIDENTIFIER = (SELECT [RouteId] from [dbo].[Routing] where [RouteId]=@RouteId)
    
    if (@existingId IS NULL)
    begin
    DECLARE @lastOrderNumber int = (SELECT TOP(1)
                                        [Order]
                                    FROM
                                        [dbo].[vw_GetRoutes]
                                    WHERE
                                        [ComponentId] = @ComponentId
                                    AND
                                        [ConnectorType] = (
                                            SELECT TOP(1)
                                                [ConnectorDefinition].[Type] AS [ConnectorDefinitionType]
                                            FROM
                                                [dbo].[Connectors] AS [Connector]
                                            LEFT OUTER JOIN
                                                [dbo].[ConnectorDefinition] AS [ConnectorDefinition] ON [Connector].[Type] = [ConnectorDefinition].[ConnectorId]
                                            WHERE
                                                [Connector].[ConnectorId] = @Connector
                                        )
                                    ORDER BY [Order] DESC)
        IF (@lastOrderNumber IS NULL)
        BEGIN
            set @Order = 0
        END ELSE
        BEGIN
            SET @Order = @lastOrderNumber + 1
        END

        INSERT INTO [dbo].[Routing] ([RouteId], [ComponentId], [Order], [Name], [Icon], [Language], [StopProcessingOnMatch], [HideWorkItemLink], [Conditions], [Connector], [ConnectorConfiguration])
        values (@RouteId, @ComponentId, @Order, @Name, @Icon, @Language, @StopProcessingOnMatch, @HideWorkItemLink, @Conditions, @Connector, @ConnectorConfiguration)
    end else
    begin
        UPDATE [dbo].[Routing]
        SET
            [ComponentId] = @ComponentId,
            [Name] = @Name,
            [Order] = @Order,
            [Icon] = @Icon,
            [Language] = @Language,
            [StopProcessingOnMatch] = @StopProcessingOnMatch,
            [HideWorkItemLink] = @HideWorkItemLink,
            [Conditions] = @Conditions,
            [Connector] = @Connector,
            [ConnectorConfiguration] = @ConnectorConfiguration
        WHERE [RouteId]=@RouteId
    end
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/16/2022
-- Modify date: 06/16/2022
-- Description: Removes route
-- ====================================================
CREATE PROCEDURE [dbo].[proc_DeleteRoute]
    @RouteId UNIQUEIDENTIFIER
AS
BEGIN
    SET NOCOUNT ON;
    
    DELETE FROM
        [dbo].[Routing]
    WHERE
        [RouteId] = @RouteId
END
GO
"@,
"Admin Center v2.0 database schema extensions."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2205, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("76789e3f-1a02-4e31-a621-8a4f8a2af13c"),
                @"
ALTER VIEW [dbo].[vw_RoadmapStatistics]
AS
SELECT
    inDevelopment = (
        SELECT
            COUNT(*) AS ItemCount
        FROM
            [dbo].[Roadmap]
        WHERE
            JSON_QUERY([Data], '$.Category') LIKE '%"In development"%' OR
            JSON_VALUE([Data], '$.Status') = 'In development'
    ),
    rollingOut = (
        SELECT
            COUNT(*) AS ItemCount
        FROM
            [dbo].[Roadmap]
        WHERE
            JSON_QUERY([Data], '$.Category') LIKE '%"Rolling out"%' OR
            JSON_VALUE([Data], '$.Status') = 'Rolling out'
    )
GO              

CREATE TABLE [dbo].[LicenseStatistics](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [SkuPartNumber] [nvarchar](512) NOT NULL,
    [ConsumedUnits] [int] NOT NULL,
    [Enabled] [int] NOT NULL,
    [Suspended] [int] NOT NULL,
    [Warning] [int] NOT NULL,
    [Timestamp] [datetime] NOT NULL DEFAULT GETUTCDATE()
    CONSTRAINT [LicenseStatistics_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE INDEX idx_LicenseStatisticsSku ON [dbo].[LicenseStatistics] ([Id] ASC, [SkuPartNumber] ASC)
GO

CREATE INDEX idx_LicenseStatisticsTime ON [dbo].[LicenseStatistics] ([Id] ASC, [Timestamp] ASC, [SkuPartNumber] ASC)
GO

-- ====================================================
-- Author: aldras
-- Create date: 05/27/2022
-- Modify date: 05/27/2022
-- Description: Adds Microsoft 365 license statistics
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddLicenseStats]
    @SkuPartNumber nvarchar(512),
    @ConsumedUnits int,
    @Enabled int,
    @Suspended int,
    @Warning int
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO
        [dbo].[LicenseStatistics] ([SkuPartNumber], [ConsumedUnits], [Enabled], [Suspended], [Warning])
    VALUES
        (@SkuPartNumber, @ConsumedUnits, @Enabled, @Suspended, @Warning)
END
GO

CREATE TABLE [dbo].[LicenseProductNames](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [DisplayName] [nvarchar](512) NOT NULL,
    [SkuPartNumber] [nvarchar](512) NOT NULL,
    [Guid] [uniqueidentifier] NOT NULL
    CONSTRAINT [LicenseProductNames_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE INDEX idx_LicenseProducNamesSku ON [dbo].[LicenseProductNames] ([Id] ASC, [SkuPartNumber] ASC)
GO

CREATE INDEX idx_LicenseProductNamesGuid ON [dbo].[LicenseProductNames] ([Id] ASC, [Guid] ASC)
GO

-- ====================================================
-- Author: aldras
-- Create date: 05/27/2022
-- Modify date: 05/27/2022
-- Description: Adds or updates sync configuration
--				element
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddLicenseProductName]
    @DisplayName nvarchar(512),
    @SkuPartNumber nvarchar(512),
    @Guid UNIQUEIDENTIFIER
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @existingProductNameId AS UNIQUEIDENTIFIER = (SELECT [Guid] FROM [dbo].[LicenseProductNames] WHERE [Guid]=@Guid)
    
    IF (@existingProductNameId IS NULL)
    BEGIN
        INSERT INTO
            [dbo].[LicenseProductNames] ([DisplayName], [SkuPartNumber], [Guid])
        VALUES
            (@DisplayName, @SkuPartNumber, @Guid)
    END ELSE
    BEGIN
        UPDATE
            [dbo].[LicenseProductNames]
        SET
            [DisplayName] = @DisplayName,
            [SkuPartNumber] = @SkuPartNumber
        WHERE
            [Guid]=@Guid
    END
END
GO

EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Advanced Communications', @SkuPartNumber = 'ADV_COMMS', @Guid = 'e4654015-5daf-4a48-9b37-4f309dddd88b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'AI Builder Capacity add-on', @SkuPartNumber = 'CDSAICAPACITY', @Guid = 'd2dea78b-507c-4e56-b400-39447f4738f8'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'APP CONNECT IW', @SkuPartNumber = 'SPZA_IW', @Guid = '8f0c5670-4e56-4892-b06d-91c085d7004f'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 Audio Conferencing', @SkuPartNumber = 'MCOMEETADV', @Guid = '0c266dff-15dd-4b49-8397-2bb16070ed52'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'AZURE ACTIVE DIRECTORY BASIC', @SkuPartNumber = 'AAD_BASIC', @Guid = '2b9c8e7c-319c-43a2-a2a0-48c5c6161de7'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'AZURE ACTIVE DIRECTORY PREMIUM P1', @SkuPartNumber = 'AAD_PREMIUM', @Guid = '078d2b04-f1bd-4111-bbd4-b4b1b354cef4'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'AZURE ACTIVE DIRECTORY PREMIUM P2', @SkuPartNumber = 'AAD_PREMIUM_P2', @Guid = '84a661c4-e949-4bd2-a560-ed7766fcaf2b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'AZURE INFORMATION PROTECTION PLAN 1', @SkuPartNumber = 'RIGHTSMANAGEMENT', @Guid = 'c52ea49f-fe5d-4e95-93ba-1de91d380f89'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Business Apps (free)', @SkuPartNumber = 'SMB_APPS', @Guid = '90d8b3f8-712e-4f7b-aa1e-62e7ae6cbe96'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'COMMON AREA PHONE', @SkuPartNumber = 'MCOCAP', @Guid = '295a8eb0-f78d-45c7-8b5b-1eed5ed02dff'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Common Area Phone for GCC', @SkuPartNumber = 'MCOCAP_GOV', @Guid = 'b1511558-69bd-4e1b-8270-59ca96dba0f3'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Common Data Service Database Capacity', @SkuPartNumber = 'CDS_DB_CAPACITY', @Guid = 'e612d426-6bc3-4181-9658-91aa906b0ac0'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Common Data Service Database Capacity for Government', @SkuPartNumber = 'CDS_DB_CAPACITY_GOV', @Guid = 'eddf428b-da0e-4115-accf-b29eb0b83965'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Common Data Service Log Capacity', @SkuPartNumber = 'CDS_LOG_CAPACITY', @Guid = '448b063f-9cc6-42fc-a0e6-40e08724a395'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'COMMUNICATIONS CREDITS', @SkuPartNumber = 'MCOPSTNC', @Guid = '47794cd0-f0e5-45c5-9033-2eb6b5fc84e0'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Compliance Manager Premium Assessment Add-On for GCC', @SkuPartNumber = 'CMPA_addon_GCC', @Guid = 'a9d7ef53-9bea-4a2a-9650-fa7df58fe094'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 - Additional Database Storage (Qualified Offer)', @SkuPartNumber = 'CRMSTORAGE', @Guid = '328dc228-00bc-48c6-8b09-1fbc8bc3435d'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 - Additional Production Instance (Qualified Offer)', @SkuPartNumber = 'CRMINSTANCE', @Guid = '9d776713-14cb-4697-a21d-9a52455c738a'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 - Additional Non-Production Instance (Qualified Offer)', @SkuPartNumber = 'CRMTESTINSTANCE', @Guid = 'e06abcc2-7ec5-4a79-b08b-d9c282376f72'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 AI for Market Insights (Preview)', @SkuPartNumber = 'SOCIAL_ENGAGEMENT_APP_USER ', @Guid = 'c6df1e30-1c9f-427f-907c-3d913474a1c7 '
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Asset Management Addl Assets', @SkuPartNumber = 'DYN365_ASSETMANAGEMENT', @Guid = '673afb9d-d85b-40c2-914e-7bf46cd5cd75'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Business Central Additional Environment Addon', @SkuPartNumber = 'DYN365_BUSCENTRAL_ADD_ENV_ADDON', @Guid = 'a58f5506-b382-44d4-bfab-225b2fbf8390'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Business Central Database Capacity', @SkuPartNumber = 'DYN365_BUSCENTRAL_DB_CAPACITY', @Guid = '7d0d4f9a-2686-4cb8-814c-eff3fdab6d74'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Business Central Essentials', @SkuPartNumber = 'DYN365_BUSCENTRAL_ESSENTIAL', @Guid = '2880026b-2b0c-4251-8656-5d41ff11e3aa'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Business Central External Accountant', @SkuPartNumber = 'DYN365_FINANCIALS_ACCOUNTANT_SKU', @Guid = '9a1e33ed-9697-43f3-b84c-1b0959dbb1d4'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Business Central for IWs', @SkuPartNumber = 'PROJECT_MADEIRA_PREVIEW_IW_SKU', @Guid = '6a4a1628-9b9a-424d-bed5-4118f0ede3fd'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Business Central Premium', @SkuPartNumber = 'DYN365_BUSCENTRAL_PREMIUM', @Guid = 'f991cecc-3f91-4cd0-a9a8-bf1c8167e029'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Customer Engagement Plan', @SkuPartNumber = 'DYN365_ENTERPRISE_PLAN1', @Guid = 'ea126fc5-a19e-42e2-a731-da9d437bffcf'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Talent: Attract ', @SkuPartNumber = 'DYN365_CUSTOMER_INSIGHTS_VIRAL ', @Guid = 'ea126fc5-a19e-42e2-a731-da9d437bffcf'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Customer Service Enterprise Viral Trial ', @SkuPartNumber = 'Dynamics_365_Customer_Service_Enterprise_viral_trial ', @Guid = '1e615a51-59db-4807-9957-aa83c3657351 '
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Customer Service Insights Trial', @SkuPartNumber = 'DYN365_AI_SERVICE_INSIGHTS', @Guid = '61e6bd70-fbdb-4deb-82ea-912842f39431'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Customer Voice Trial', @SkuPartNumber = 'FORMS_PRO', @Guid = 'bc946dac-7877-4271-b2f7-99d2db13cd2c'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Customer Service Professional', @SkuPartNumber = 'DYN365_CUSTOMER_SERVICE_PRO', @Guid = '1439b6e2-5d59-4873-8c59-d60e2a196e92'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Customer Voice Additional Responses', @SkuPartNumber = 'Forms_Pro_AddOn', @Guid = '446a86f8-a0cb-4095-83b3-d100eb050e3d'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Customer Voice Additional Responses', @SkuPartNumber = 'DYN365_CUSTOMER_VOICE_ADDON', @Guid = '65f71586-ade3-4ce1-afc0-1b452eaf3782'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Customer Voice USL', @SkuPartNumber = 'Forms_Pro_USL', @Guid = 'e2ae107b-a571-426f-9367-6d4c8f1390ba'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Enterprise Edition - Additional Portal (Qualified Offer)', @SkuPartNumber = 'CRM_ONLINE_PORTAL', @Guid = 'a4bfb28e-becc-41b0-a454-ac680dc258d3'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Field Service Viral Trial ', @SkuPartNumber = 'Dynamics_365_Field_Service_Enterprise_viral_trial ', @Guid = '29fcd665-d8d1-4f34-8eed-3811e3fca7b3 '
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Finance', @SkuPartNumber = 'DYN365_FINANCE', @Guid = '55c9eb4e-c746-45b4-b255-9ab6b19d5c62'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'DYNAMICS 365 FOR CUSTOMER SERVICE ENTERPRISE EDITION', @SkuPartNumber = 'DYN365_ENTERPRISE_CUSTOMER_SERVICE', @Guid = '749742bf-0d37-4158-a120-33567104deeb'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'DYNAMICS 365 FOR FINANCIALS BUSINESS EDITION', @SkuPartNumber = 'DYN365_FINANCIALS_BUSINESS_SKU', @Guid = 'cc13a803-544e-4464-b4e4-6d6169a138fa'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'DYNAMICS 365 FOR SALES AND CUSTOMER SERVICE ENTERPRISE EDITION', @SkuPartNumber = 'DYN365_ENTERPRISE_SALES_CUSTOMERSERVICE', @Guid = '8edc2cf8-6438-4fa9-b6e3-aa1660c640cc'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'DYNAMICS 365 FOR SALES ENTERPRISE EDITION', @SkuPartNumber = 'DYN365_ENTERPRISE_SALES', @Guid = '1e1a282c-9c54-43a2-9310-98ef728faace'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Marketing Business Edition ', @SkuPartNumber = 'DYN365_BUSINESS_MARKETING ', @Guid = '238e2f8d-e429-4035-94db-6926be4ffe7b '
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Regulatory Service - Enterprise Edition Trial ', @SkuPartNumber = 'DYN365_REGULATORY_SERVICE ', @Guid = '7ed4877c-0863-4f69-9187-245487128d4f '
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Sales Premium Viral Trial ', @SkuPartNumber = 'Dynamics_365_Sales_Premium_Viral_Trial ', @Guid = '6ec92958-3cc1-49db-95bd-bc6b3798df71 '
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 For Sales Professional', @SkuPartNumber = 'D365_SALES_PRO ', @Guid = 'be9f9771-1c64-4618-9907-244325141096'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 For Sales Professional Trial ', @SkuPartNumber = 'D365_SALES_PRO_IW ', @Guid = '9c7bff7a-3715-4da7-88d3-07f57f8d0fb6 '
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Sales Professional Attach to Qualifying Dynamics 365 Base Offer', @SkuPartNumber = 'D365_SALES_PRO_ATTACH', @Guid = '245e6bf9-411e-481e-8611-5c08595e2988'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'DYNAMICS 365 FOR SUPPLY CHAIN MANAGEMENT', @SkuPartNumber = 'DYN365_SCM', @Guid = 'f2e48cb3-9da0-42cd-8464-4a54ce198ad0'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 for Talent', @SkuPartNumber = 'SKU_Dynamics_365_for_HCM_Trial', @Guid = '3a256e9a-15b6-4092-b0dc-82993f4debc6'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Talent: Attract ', @SkuPartNumber = 'Dynamics_365_Hiring_SKU ', @Guid = 'e561871f-74fa-4f02-abee-5b0ef54dd36d '
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'DYNAMICS 365 FOR TEAM MEMBERS ENTERPRISE EDITION', @SkuPartNumber = 'DYN365_ENTERPRISE_TEAM_MEMBERS', @Guid = '8e7a3d30-d97d-43ab-837c-d7701cef83dc'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Guides', @SkuPartNumber = 'GUIDES_USER', @Guid = '0a389a77-9850-4dc4-b600-bc66fdfefc60'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Operations - Device', @SkuPartNumber = 'Dynamics_365_for_Operations_Devices', @Guid = '3bbd44ed-8a70-4c07-9088-6232ddbd5ddd'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Operations - Sandbox Tier 2:Standard Acceptance Testing', @SkuPartNumber = 'Dynamics_365_for_Operations_Sandbox_Tier2_SKU', @Guid = 'e485d696-4c87-4aac-bf4a-91b2fb6f0fa7'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Operations - Sandbox Tier 4:Standard Performance Testing', @SkuPartNumber = 'Dynamics_365_for_Operations_Sandbox_Tier4_SKU', @Guid = 'f7ad4bca-7221-452c-bdb6-3e6089f25e06'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'DYNAMICS 365 P1 TRIAL FOR INFORMATION WORKERS', @SkuPartNumber = 'DYN365_ENTERPRISE_P1_IW', @Guid = '338148b6-1b11-4102-afb9-f92b6cdc0f8d'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Remote Assist', @SkuPartNumber = 'MICROSOFT_REMOTE_ASSIST', @Guid = '7a551360-26c4-4f61-84e6-ef715673e083'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Remote Assist HoloLens', @SkuPartNumber = 'MICROSOFT_REMOTE_ASSIST_HOLOLENS', @Guid = 'e48328a2-8e98-4484-a70f-a99f8ac9ec89'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Dynamics 365 Sales Enterprise Attach to Qualifying Dynamics 365 Base Offer', @SkuPartNumber = 'D365_SALES_ENT_ATTACH', @Guid = '5b22585d-1b71-4c6b-b6ec-160b1a9c2323'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'DYNAMICS 365 TALENT: ONBOARD', @SkuPartNumber = 'DYNAMICS_365_ONBOARDING_SKU', @Guid = 'b56e7ccc-d5c7-421f-a23b-5c18bdbad7c0'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'DYNAMICS 365 TEAM MEMBERS', @SkuPartNumber = 'DYN365_TEAM_MEMBERS', @Guid = '7ac9fe77-66b7-4e5e-9e46-10eed1cff547'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'DYNAMICS 365 UNF OPS PLAN ENT EDITION', @SkuPartNumber = 'Dynamics_365_for_Operations', @Guid = 'ccba3cfe-71ef-423a-bd87-b6df3dce59a9'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'ENTERPRISE MOBILITY + SECURITY E3', @SkuPartNumber = 'EMS', @Guid = 'efccb6f7-5641-4e0e-bd10-b4976e1bf68e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'ENTERPRISE MOBILITY + SECURITY E5', @SkuPartNumber = 'EMSPREMIUM', @Guid = 'b05e124f-c7cc-45a0-a6aa-8cf78c946968'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Enterprise Mobility + Security G3 GCC', @SkuPartNumber = 'EMS_GOV', @Guid = 'c793db86-5237-494e-9b11-dcd4877c2c8c'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Enterprise Mobility + Security G5 GCC', @SkuPartNumber = 'EMSPREMIUM_GOV', @Guid = '8a180c2b-f4cf-4d44-897c-3d32acc4a60b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Exchange Enterprise CAL Services (EOP DLP)', @SkuPartNumber = 'EOP_ENTERPRISE_PREMIUM', @Guid = 'e8ecdf70-47a8-4d39-9d15-093624b7f640'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Exchange Online (Plan 1)', @SkuPartNumber = 'EXCHANGESTANDARD', @Guid = '4b9405b0-7788-4568-add1-99614e613b69'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Exchange Online (Plan 1) for GCC', @SkuPartNumber = 'EXCHANGESTANDARD_GOV', @Guid = 'f37d5ebf-4bf1-4aa2-8fa3-50c51059e983'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'EXCHANGE ONLINE (PLAN 2)', @SkuPartNumber = 'EXCHANGEENTERPRISE', @Guid = '19ec0d23-8335-4cbd-94ac-6050e30712fa'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'EXCHANGE ONLINE ARCHIVING FOR EXCHANGE ONLINE', @SkuPartNumber = 'EXCHANGEARCHIVE_ADDON', @Guid = 'ee02fd1b-340e-4a4b-b355-4a514e4c8943'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'EXCHANGE ONLINE ARCHIVING FOR EXCHANGE SERVER', @SkuPartNumber = 'EXCHANGEARCHIVE', @Guid = '90b5e015-709a-4b8b-b08e-3200f994494c'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'EXCHANGE ONLINE ESSENTIALS (ExO P1 BASED)', @SkuPartNumber = 'EXCHANGEESSENTIALS', @Guid = '7fc0182e-d107-4556-8329-7caaa511197b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'EXCHANGE ONLINE ESSENTIALS', @SkuPartNumber = 'EXCHANGE_S_ESSENTIALS', @Guid = 'e8f81a67-bd96-4074-b108-cf193eb9433b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'EXCHANGE ONLINE KIOSK', @SkuPartNumber = 'EXCHANGEDESKLESS', @Guid = '80b2d799-d2ba-4d2a-8842-fb0d0f3a4b82'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'EXCHANGE ONLINE POP', @SkuPartNumber = 'EXCHANGETELCO', @Guid = 'cb0a98a8-11bc-494c-83d9-c1b1ac65327e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Exchange Online Protection', @SkuPartNumber = 'EOP_ENTERPRISE', @Guid = '45a2423b-e884-448d-a831-d9e139c52d2f'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'INTUNE', @SkuPartNumber = 'INTUNE_A', @Guid = '061f9ace-7d42-4136-88ac-31dc755f143f'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Dynamics AX7 User Trial', @SkuPartNumber = 'AX7_USER_TRIAL', @Guid = 'fcecd1f9-a91e-488d-a918-a96cdb6ce2b0'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Azure Multi-Factor Authentication', @SkuPartNumber = 'MFA_STANDALONE', @Guid = 'cb2020b1-d8f6-41c0-9acd-8ff3d6d7831b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Defender for Office 365 (Plan 2)', @SkuPartNumber = 'THREAT_INTELLIGENCE', @Guid = '3dd6cf57-d688-4eed-ba52-9e40b5468c3e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 A1', @SkuPartNumber = 'M365EDU_A1', @Guid = 'b17653a4-2443-4e8c-a550-18249dda78bb'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 A3 for Faculty', @SkuPartNumber = 'M365EDU_A3_FACULTY', @Guid = '4b590615-0888-425a-a965-b3bf7789848d'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 A3 FOR STUDENTS', @SkuPartNumber = 'M365EDU_A3_STUDENT', @Guid = '7cfd9a2b-e110-4c39-bf20-c6a3f36a3121'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 A3 for students use benefit', @SkuPartNumber = 'M365EDU_A3_STUUSEBNFT', @Guid = '18250162-5d87-4436-a834-d795c15c80f3'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 A3 - Unattended License for students use benefit', @SkuPartNumber = 'M365EDU_A3_STUUSEBNFT_RPA1', @Guid = '1aa94593-ca12-4254-a738-81a5972958e8'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 A5 for Faculty', @SkuPartNumber = 'M365EDU_A5_FACULTY', @Guid = 'e97c048c-37a4-45fb-ab50-922fbf07a370'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 A5 FOR STUDENTS', @SkuPartNumber = 'M365EDU_A5_STUDENT', @Guid = '46c119d4-0379-4a9d-85e4-97c66d3f909e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 A5 for students use benefit', @SkuPartNumber = 'M365EDU_A5_STUUSEBNFT', @Guid = '31d57bc7-3a05-4867-ab53-97a17835a411'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 A5 without Audio Conferencing for students use benefit', @SkuPartNumber = 'M365EDU_A5_NOPSTNCONF_STUUSEBNFT', @Guid = '81441ae1-0b31-4185-a6c0-32b6b84d419f'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 APPS FOR BUSINESS', @SkuPartNumber = 'O365_BUSINESS', @Guid = 'cdd28e44-67e3-425e-be4c-737fab2899d3'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 APPS FOR BUSINESS', @SkuPartNumber = 'SMB_BUSINESS', @Guid = 'b214fe43-f5a3-4703-beeb-fa97188220fc'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 APPS FOR ENTERPRISE', @SkuPartNumber = 'OFFICESUBSCRIPTION', @Guid = 'c2273bd0-dff7-4215-9ef5-2c7bcfb06425'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 Apps for Faculty', @SkuPartNumber = 'OFFICESUBSCRIPTION_FACULTY', @Guid = '12b8c807-2e20-48fc-b453-542b6ee9d171'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 AUDIO CONFERENCING FOR GCC', @SkuPartNumber = 'MCOMEETADV_GOC', @Guid = '2d3091c7-0712-488b-b3d8-6b97bde6a1f5'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 BUSINESS BASIC', @SkuPartNumber = 'O365_BUSINESS_ESSENTIALS', @Guid = '3b555118-da6a-4418-894f-7df1e2096870'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 BUSINESS BASIC', @SkuPartNumber = 'SMB_BUSINESS_ESSENTIALS', @Guid = 'dab7782a-93b1-4074-8bb1-0e61318bea0b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 BUSINESS STANDARD', @SkuPartNumber = 'O365_BUSINESS_PREMIUM', @Guid = 'f245ecc8-75af-4f8e-b61f-27d8114de5f3'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 BUSINESS STANDARD - PREPAID LEGACY', @SkuPartNumber = 'SMB_BUSINESS_PREMIUM', @Guid = 'ac5cef5d-921b-4f97-9ef3-c99076e5470f'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 BUSINESS PREMIUM', @SkuPartNumber = 'SPB', @Guid = 'cbdc14ab-d96c-4c30-b9f4-6ada7cdc1d46'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 Business Voice', @SkuPartNumber = 'BUSINESS_VOICE_MED2', @Guid = 'a6051f20-9cbc-47d2-930d-419183bf6cf1'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 Business Voice (US)', @SkuPartNumber = 'BUSINESS_VOICE_MED2_TELCO', @Guid = '08d7bce8-6e16-490e-89db-1d508e5e9609'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 Business Voice (without calling plan) ', @SkuPartNumber = 'BUSINESS_VOICE_DIRECTROUTING', @Guid = 'd52db95a-5ecb-46b6-beb0-190ab5cda4a8'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 Business Voice (without Calling Plan) for US', @SkuPartNumber = 'BUSINESS_VOICE_DIRECTROUTING_MED', @Guid = '8330dae3-d349-44f7-9cad-1b23c64baabe'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 DOMESTIC CALLING PLAN (120 Minutes)', @SkuPartNumber = 'MCOPSTN_5', @Guid = '11dee6af-eca8-419f-8061-6864517c1875'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 Domestic Calling Plan for GCC', @SkuPartNumber = 'MCOPSTN_1_GOV', @Guid = '923f58ab-fca1-46a1-92f9-89fda21238a8'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 E3', @SkuPartNumber = 'SPE_E3', @Guid = '05e9a617-0261-4cee-bb44-138d3ef5d965'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 E3 - Unattended License', @SkuPartNumber = 'SPE_E3_RPA1', @Guid = 'c2ac2ee4-9bb1-47e4-8541-d689c7e83371'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 E3_USGOV_DOD', @SkuPartNumber = 'SPE_E3_USGOV_DOD', @Guid = 'd61d61cc-f992-433f-a577-5bd016037eeb'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 E3_USGOV_GCCHIGH', @SkuPartNumber = 'SPE_E3_USGOV_GCCHIGH', @Guid = 'ca9d1dd9-dfe9-4fef-b97c-9bc1ea3c3658'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 E5', @SkuPartNumber = 'SPE_E5', @Guid = '06ebc4ee-1bb5-47dd-8120-11324bc54e06'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 E5 Developer (without Windows and Audio Conferencing)', @SkuPartNumber = 'DEVELOPERPACK_E5', @Guid = 'c42b9cae-ea4f-4ab7-9717-81576235ccac'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 E5 Compliance', @SkuPartNumber = 'INFORMATION_PROTECTION_COMPLIANCE', @Guid = '184efa21-98c3-4e5d-95ab-d07053a96e67'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 E5 Security', @SkuPartNumber = 'IDENTITY_THREAT_PROTECTION', @Guid = '26124093-3d78-432b-b5dc-48bf992543d5'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 E5 Security for EMS E5', @SkuPartNumber = 'IDENTITY_THREAT_PROTECTION_FOR_EMS_E5', @Guid = '44ac31e7-2999-4304-ad94-c948886741d4'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 E5 without Audio Conferencing ', @SkuPartNumber = 'SPE_E5_NOPSTNCONF', @Guid = 'cd2925a3-5076-4233-8931-638a8c94f773'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 F1', @SkuPartNumber = 'M365_F1', @Guid = '44575883-256e-4a79-9da4-ebe9acabe2b2'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 F3', @SkuPartNumber = 'SPE_F1', @Guid = '66b55226-6b4f-492c-910c-a3b7a3c9d993'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 F3 GCC', @SkuPartNumber = 'M365_F1_GOV', @Guid = '2a914830-d700-444a-b73c-e3f31980d833'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 F5 Security Add-on', @SkuPartNumber = 'SPE_F5_SEC', @Guid = '67ffe999-d9ca-49e1-9d2c-03fb28aa7a48'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 F5 Security + Compliance Add-on ', @SkuPartNumber = 'SPE_F5_SECCOMP ', @Guid = '32b47245-eb31-44fc-b945-a8b1576c439f '
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 GCC G5', @SkuPartNumber = 'M365_G5_GCC', @Guid = 'e2be619b-b125-455f-8660-fb503e431a5d'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT FLOW FREE', @SkuPartNumber = 'FLOW_FREE', @Guid = 'f30db892-07e9-47e9-837c-80727f46fd3d'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 AUDIO CONFERENCING FOR GCC', @SkuPartNumber = 'MCOMEETADV_GOV', @Guid = '2d3091c7-0712-488b-b3d8-6b97bde6a1f5'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 E5 Suite features', @SkuPartNumber = 'M365_E5_SUITE_COMPONENTS', @Guid = '99cc8282-2f74-4954-83b7-c6a9a1999067'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 F1', @SkuPartNumber = 'M365_F1_COMM', @Guid = '50f60901-3181-4b75-8a2c-4c8e4c1d5a72'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 G3 GCC', @SkuPartNumber = 'M365_G3_GOV', @Guid = 'e823ca47-49c4-46b3-b38d-ca11d5abe3d2'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 PHONE SYSTEM', @SkuPartNumber = 'MCOEV', @Guid = 'e43b5b99-8dfb-405f-9987-dc307f34bcbd'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 PHONE SYSTEM FOR DOD', @SkuPartNumber = 'MCOEV_DOD', @Guid = 'd01d9287-694b-44f3-bcc5-ada78c8d953e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 PHONE SYSTEM FOR FACULTY', @SkuPartNumber = 'MCOEV_FACULTY', @Guid = 'd979703c-028d-4de5-acbf-7955566b69b9'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 PHONE SYSTEM FOR GCC', @SkuPartNumber = 'MCOEV_GOV', @Guid = 'a460366a-ade7-4791-b581-9fbff1bdaa85'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 PHONE SYSTEM FOR GCCHIGH', @SkuPartNumber = 'MCOEV_GCCHIGH', @Guid = '7035277a-5e49-4abc-a24f-0ec49c501bb5'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 PHONE SYSTEM FOR SMALL AND MEDIUM BUSINESS', @SkuPartNumber = 'MCOEVSMB_1', @Guid = 'aa6791d3-bb09-4bc2-afed-c30c3fe26032'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 PHONE SYSTEM FOR STUDENTS', @SkuPartNumber = 'MCOEV_STUDENT', @Guid = '1f338bbc-767e-4a1e-a2d4-b73207cc5b93'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 PHONE SYSTEM FOR TELSTRA', @SkuPartNumber = 'MCOEV_TELSTRA', @Guid = 'ffaf2d68-1c95-4eb3-9ddd-59b81fba0f61'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 PHONE SYSTEM_USGOV_DOD', @SkuPartNumber = 'MCOEV_USGOV_DOD', @Guid = 'b0e7de67-e503-4934-b729-53d595ba5cd1'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 PHONE SYSTEM_USGOV_GCCHIGH', @SkuPartNumber = 'MCOEV_USGOV_GCCHIGH', @Guid = '985fcb26-7b94-475b-b512-89356697be71'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT 365 PHONE SYSTEM - VIRTUAL USER', @SkuPartNumber = 'PHONESYSTEM_VIRTUALUSER', @Guid = '440eaaa8-b3e0-484b-a8be-62870b9ba70a'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 Phone System - Virtual User for GCC', @SkuPartNumber = 'PHONESYSTEM_VIRTUALUSER_GOV', @Guid = '2cf22bcb-0c9e-4bc6-8daf-7e7654c0f285'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft 365 Security and Compliance for Firstline Workers', @SkuPartNumber = 'M365_SECURITY_COMPLIANCE_FOR_FLW', @Guid = '2347355b-4e81-41a4-9c22-55057a399791'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT BUSINESS CENTER', @SkuPartNumber = 'MICROSOFT_BUSINESS_CENTER', @Guid = '726a0894-2c77-4d65-99da-9775ef05aad1'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Cloud App Security', @SkuPartNumber = 'ADALLOM_STANDALONE', @Guid = 'df845ce7-05f9-4894-b5f2-11bbfbcfd2b6'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT DEFENDER FOR ENDPOINT', @SkuPartNumber = 'WIN_DEF_ATP', @Guid = '111046dd-295b-4d6d-9724-d52ac90bd1f2'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Defender for Endpoint P1', @SkuPartNumber = 'DEFENDER_ENDPOINT_P1', @Guid = '16a55f2f-ff35-4cd5-9146-fb784e3761a5'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Defender for Endpoint Server', @SkuPartNumber = 'MDATP_Server', @Guid = '509e8ab6-0274-4cda-bcbd-bd164fd562c4'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT DYNAMICS CRM ONLINE BASIC', @SkuPartNumber = 'CRMPLAN2', @Guid = '906af65a-2970-46d5-9b58-4e9aa50f0657'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Defender for Identity', @SkuPartNumber = 'ATA', @Guid = '98defdf7-f6c1-44f5-a1f6-943b6764e7a5'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Defender for Office 365 (Plan 1) GCC ', @SkuPartNumber = 'ATP_ENTERPRISE_GOV', @Guid = 'd0d1ca43-b81a-4f51-81e5-a5b1ad7bb005'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Defender for Office 365 (Plan 2) GCC', @SkuPartNumber = 'THREAT_INTELLIGENCE_GOV', @Guid = '56a59ffb-9df1-421b-9e61-8b568583474d'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT DYNAMICS CRM ONLINE', @SkuPartNumber = 'CRMSTANDARD', @Guid = 'd17b27af-3f49-4822-99f9-56a661538792'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MS IMAGINE ACADEMY', @SkuPartNumber = 'IT_ACADEMY_AD', @Guid = 'ba9a34de-4489-469d-879c-0f0f145321cd'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Intune Device', @SkuPartNumber = 'INTUNE_A_D', @Guid = '2b317a4a-77a6-4188-9437-b68a77b4e2c6'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT INTUNE DEVICE FOR GOVERNMENT', @SkuPartNumber = 'INTUNE_A_D_GOV', @Guid = '2c21e77a-e0d6-4570-b38a-7ff2dc17d2ca'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Power Apps for Developer ', @SkuPartNumber = 'POWERAPPS_DEV ', @Guid = '5b631642-bd26-49fe-bd20-1daaa972ef80 '
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Power Apps Plan 2 Trial', @SkuPartNumber = 'POWERAPPS_VIRAL', @Guid = 'dcb1a3ae-b33f-4487-846a-a640262fadf4'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT POWER AUTOMATE PLAN 2', @SkuPartNumber = 'FLOW_P2', @Guid = '4755df59-3f73-41ab-a249-596ad72b5504'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT INTUNE SMB', @SkuPartNumber = 'INTUNE_SMB', @Guid = 'e6025b08-2fa5-4313-bd0a-7e5ffca32958'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Power Apps Plan 2 (Qualified Offer)', @SkuPartNumber = 'POWERFLOW_P2', @Guid = 'ddfae3e3-fcb2-4174-8ebd-3023cb213c8b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT STREAM', @SkuPartNumber = 'STREAM', @Guid = '1f2f344a-700d-42c9-9427-5cea1d5d7ba6'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Stream Plan 2', @SkuPartNumber = 'STREAM_P2', @Guid = 'ec156933-b85b-4c50-84ec-c9e5603709ef'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Stream Storage Add-On (500 GB)', @SkuPartNumber = 'STREAM_STORAGE', @Guid = '9bd7c846-9556-4453-a542-191d527209e8'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT TEAMS (FREE)', @SkuPartNumber = 'TEAMS_FREE', @Guid = '16ddbbfc-09ea-4de2-b1d7-312db6112d70'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'MICROSOFT TEAMS EXPLORATORY', @SkuPartNumber = 'TEAMS_EXPLORATORY', @Guid = '710779e8-3d4a-4c88-adb9-386c958d1fdf'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Teams Rooms Standard', @SkuPartNumber = 'MEETING_ROOM', @Guid = '6070a4c8-34c6-4937-8dfb-39bbc6397a60'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Teams Rooms Standard without Audio Conferencing', @SkuPartNumber = 'MEETING_ROOM_NOAUDIOCONF', @Guid = '61bec411-e46a-4dab-8f46-8b58ec845ffe'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Teams Trial', @SkuPartNumber = 'MS_TEAMS_IW', @Guid = '74fbf1bb-47c6-4796-9623-77dc7371723b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Threat Experts - Experts on Demand', @SkuPartNumber = 'EXPERTS_ON_DEMAND', @Guid = '9fa2f157-c8e4-4351-a3f2-ffa506da1406'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Multi-Geo Capabilities in Office 365', @SkuPartNumber = 'OFFICE365_MULTIGEO', @Guid = '84951599-62b7-46f3-9c9d-30551b2ad607'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Nonprofit Portal', @SkuPartNumber = 'NONPROFIT_PORTAL', @Guid = 'aa2695c9-8d59-4800-9dc8-12e01f1735af'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 A1 for faculty', @SkuPartNumber = 'STANDARDWOFFPACK_FACULTY', @Guid = '94763226-9b3c-4e75-a931-5c89701abe66'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 A1 Plus for faculty', @SkuPartNumber = 'STANDARDWOFFPACK_IW_FACULTY', @Guid = '78e66a63-337a-4a9a-8959-41c6654dfb56'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 A1 for students ', @SkuPartNumber = 'STANDARDWOFFPACK_STUDENT ', @Guid = '314c4481-f395-4525-be8b-2ec4bb1e9d91 '
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 A1 Plus for students', @SkuPartNumber = 'STANDARDWOFFPACK_IW_STUDENT', @Guid = 'e82ae690-a2d5-4d76-8d30-7c6e01e6022e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 A3 for faculty', @SkuPartNumber = 'ENTERPRISEPACKPLUS_FACULTY', @Guid = 'e578b273-6db4-4691-bba0-8d691f4da603'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 A3 for students', @SkuPartNumber = 'ENTERPRISEPACKPLUS_STUDENT', @Guid = '98b6e773-24d4-4c0d-a968-6e787a1f8204'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 A5 for faculty', @SkuPartNumber = 'ENTERPRISEPREMIUM_FACULTY', @Guid = 'a4585165-0533-458a-97e3-c400570268c4'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 A5 for students', @SkuPartNumber = 'ENTERPRISEPREMIUM_STUDENT', @Guid = 'ee656612-49fa-43e5-b67e-cb1fdf7699df'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 Advanced Compliance', @SkuPartNumber = 'EQUIVIO_ANALYTICS', @Guid = '1b1b1f7a-8355-43b6-829f-336cfccb744c'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 Advanced Compliance for GCC', @SkuPartNumber = 'EQUIVIO_ANALYTICS_GOV', @Guid = '1a585bba-1ce3-416e-b1d6-9c482b52fcf6'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Defender for Office 365 (Plan 1)', @SkuPartNumber = 'ATP_ENTERPRISE', @Guid = '4ef96642-f096-40de-a3e9-d83fb2f90211'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 Extra File Storage for GCC', @SkuPartNumber = 'SHAREPOINTSTORAGE_GOV', @Guid = 'e5788282-6381-469f-84f0-3d7d4021d34d'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Teams Commercial Cloud', @SkuPartNumber = 'TEAMS_COMMERCIAL_TRIAL', @Guid = '29a2f828-8f39-4837-b8ff-c957e86abe3c'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 Cloud App Security', @SkuPartNumber = 'ADALLOM_O365', @Guid = '84d5f90f-cd0d-4864-b90b-1c7ba63b4808'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 Extra File Storage', @SkuPartNumber = 'SHAREPOINTSTORAGE', @Guid = '99049c9c-6011-4908-bf17-15f496e6519d'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 E1', @SkuPartNumber = 'STANDARDPACK', @Guid = '18181a46-0d4e-45cd-891e-60aabd171b4e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'OFFICE 365 E2', @SkuPartNumber = 'STANDARDWOFFPACK', @Guid = '6634e0ce-1a9f-428c-a498-f84ec7b8aa2e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 E3', @SkuPartNumber = 'ENTERPRISEPACK', @Guid = '6fd2c87f-b296-42f0-b197-1e91e994b900'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'OFFICE 365 E3 DEVELOPER', @SkuPartNumber = 'DEVELOPERPACK', @Guid = '189a915c-fe4f-4ffa-bde4-85b9628d07a0'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 E3_USGOV_DOD', @SkuPartNumber = 'ENTERPRISEPACK_USGOV_DOD', @Guid = 'b107e5a3-3e60-4c0d-a184-a7e4395eb44c'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 E3_USGOV_GCCHIGH', @SkuPartNumber = 'ENTERPRISEPACK_USGOV_GCCHIGH', @Guid = 'aea38a85-9bd5-4981-aa00-616b411205bf'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'OFFICE 365 E4', @SkuPartNumber = 'ENTERPRISEWITHSCAL', @Guid = '1392051d-0cb9-4b7a-88d5-621fee5e8711'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 E5', @SkuPartNumber = 'ENTERPRISEPREMIUM', @Guid = 'c7df2760-2c81-4ef7-b578-5b5392b571df'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'OFFICE 365 E5 WITHOUT AUDIO CONFERENCING', @SkuPartNumber = 'ENTERPRISEPREMIUM_NOPSTNCONF', @Guid = '26d45bd9-adf1-46cd-a9e1-51e9a5524128'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'OFFICE 365 F3', @SkuPartNumber = 'DESKLESSPACK', @Guid = '4b585984-651b-448a-9e53-3b10f069cf7f'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 G1 GCC', @SkuPartNumber = 'STANDARDPACK_GOV', @Guid = '3f4babde-90ec-47c6-995d-d223749065d1'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'OFFICE 365 G3 GCC', @SkuPartNumber = 'ENTERPRISEPACK_GOV', @Guid = '535a3a29-c5f0-42fe-8215-d3b9e1f38c4a'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Office 365 G5 GCC', @SkuPartNumber = 'ENTERPRISEPREMIUM_GOV', @Guid = '8900a2c0-edba-4079-bdf3-b276e293b6a8'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'OFFICE 365 MIDSIZE BUSINESS', @SkuPartNumber = 'MIDSIZEPACK', @Guid = '04a7fb0d-32e0-4241-b4f5-3f7618cd1162'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'OFFICE 365 SMALL BUSINESS', @SkuPartNumber = 'LITEPACK', @Guid = 'bd09678e-b83c-4d3f-aaba-3dad4abd128b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'OFFICE 365 SMALL BUSINESS PREMIUM', @SkuPartNumber = 'LITEPACK_P2', @Guid = 'fc14ec4a-4169-49a4-a51e-2c852931814b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'ONEDRIVE FOR BUSINESS (PLAN 1)', @SkuPartNumber = 'WACONEDRIVESTANDARD', @Guid = 'e6778190-713e-4e4f-9119-8b8238de25df'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'ONEDRIVE FOR BUSINESS (PLAN 2)', @SkuPartNumber = 'WACONEDRIVEENTERPRISE', @Guid = 'ed01faf2-1d88-4947-ae91-45ca18703a96'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'POWERAPPS AND LOGIC FLOWS', @SkuPartNumber = 'POWERAPPS_INDIVIDUAL_USER', @Guid = '87bbbc60-4754-4998-8c88-227dca264858'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'PowerApps per app baseline access', @SkuPartNumber = 'POWERAPPS_PER_APP_IW', @Guid = 'bf666882-9c9b-4b2e-aa2f-4789b0a52ba2'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Apps per app plan', @SkuPartNumber = 'POWERAPPS_PER_APP', @Guid = 'a8ad7d2b-b8cf-49d6-b25a-69094a0be206'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Apps per user plan', @SkuPartNumber = 'POWERAPPS_PER_USER', @Guid = 'b30411f5-fea1-4a59-9ad9-3db7c7ead579'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Apps per user plan for Government', @SkuPartNumber = 'POWERAPPS_PER_USER_GCC', @Guid = '8e4c6baa-f2ff-4884-9c38-93785d0d7ba1'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'PowerApps Plan 1 for Government', @SkuPartNumber = 'POWERAPPS_P1_GOV', @Guid = 'eca22b68-b31f-4e9c-a20c-4d40287bc5dd'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Apps Portals login capacity add-on Tier 2 (10 unit min) for Government', @SkuPartNumber = 'POWERAPPS_PORTALS_LOGIN_T2_GCC', @Guid = '26c903d5-d385-4cb1-b650-8d81a643b3c4'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Apps Portals page view capacity add-on for Government', @SkuPartNumber = 'POWERAPPS_PORTALS_PAGEVIEW_GCC', @Guid = '15a64d3e-5b99-4c4b-ae8f-aa6da264bfe7'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Automate per flow plan', @SkuPartNumber = 'FLOW_BUSINESS_PROCESS', @Guid = 'b3a42176-0a8c-4c3f-ba4e-f2b37fe5be6b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Automate per user plan', @SkuPartNumber = 'FLOW_PER_USER', @Guid = '4a51bf65-409c-4a91-b845-1121b571cc9d'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Automate per user plan dept', @SkuPartNumber = 'FLOW_PER_USER_DEPT', @Guid = 'd80a4c5d-8f05-4b64-9926-6574b9e6aee4'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Automate per user plan for Government', @SkuPartNumber = 'FLOW_PER_USER_GCC', @Guid = 'c8803586-c136-479a-8ff3-f5f32d23a68e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Automate per user with attended RPA plan', @SkuPartNumber = 'POWERAUTOMATE_ATTENDED_RPA', @Guid = 'eda1941c-3c4f-4995-b5eb-e85a42175ab9'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Automate unattended RPA add-on', @SkuPartNumber = 'POWERAUTOMATE_UNATTENDED_RPA', @Guid = '3539d28c-6e35-4a30-b3a9-cd43d5d3e0e2'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power BI', @SkuPartNumber = 'POWER_BI_INDIVIDUAL_USER', @Guid = 'e2767865-c3c9-4f09-9f99-6eee6eef861a'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power BI (free)', @SkuPartNumber = 'POWER_BI_STANDARD', @Guid = 'a403ebcc-fae0-4ca2-8c8c-7a907fd6c235'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'POWER BI FOR OFFICE 365 ADD-ON', @SkuPartNumber = 'POWER_BI_ADDON', @Guid = '45bc2c81-6072-436a-9b0b-3b12eefbc402'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power BI Premium P1', @SkuPartNumber = 'PBI_PREMIUM_P1_ADDON', @Guid = '7b26f5ab-a763-4c00-a1ac-f6c4b5506945'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power BI Premium Per User', @SkuPartNumber = 'PBI_PREMIUM_PER_USER', @Guid = 'c1d032e0-5619-4761-9b5c-75b6831e1711'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power BI Premium Per User Add-On', @SkuPartNumber = 'PBI_PREMIUM_PER_USER_ADDON', @Guid = 'de376a03-6e5b-42ec-855f-093fb50b8ca5'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power BI Premium Per User Dept', @SkuPartNumber = 'PBI_PREMIUM_PER_USER_DEPT', @Guid = 'f168a3fb-7bcf-4a27-98c3-c235ea4b78b4'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power BI Pro', @SkuPartNumber = 'POWER_BI_PRO', @Guid = 'f8a1db68-be16-40ed-86d5-cb42ce701560'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power BI Pro CE', @SkuPartNumber = 'POWER_BI_PRO_CE', @Guid = '420af87e-8177-4146-a780-3786adaffbca'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power BI Pro Dept', @SkuPartNumber = 'POWER_BI_PRO_DEPT', @Guid = '3a6a908c-09c5-406a-8170-8ebb63c42882'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power BI Pro for GCC', @SkuPartNumber = 'POWERBI_PRO_GOV', @Guid = 'f0612879-44ea-47fb-baf0-3d76d9235576'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Virtual Agent', @SkuPartNumber = 'VIRTUAL_AGENT_BASE', @Guid = 'e4e55366-9635-46f4-a907-fc8c3b5ec81f'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Power Virtual Agents Viral Trial', @SkuPartNumber = 'CCIBOTS_PRIVPREV_VIRAL', @Guid = '606b54a9-78d8-4298-ad8b-df6ef4481c80'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'PROJECT FOR OFFICE 365', @SkuPartNumber = 'PROJECTCLIENT', @Guid = 'a10d5e58-74da-4312-95c8-76be4e5b75a0'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Project Online Essentials', @SkuPartNumber = 'PROJECTESSENTIALS', @Guid = '776df282-9fc0-4862-99e2-70e561b9909e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Project Online Essentials for GCC', @SkuPartNumber = 'PROJECTESSENTIALS_GOV', @Guid = 'ca1a159a-f09e-42b8-bb82-cb6420f54c8e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'PROJECT ONLINE PREMIUM', @SkuPartNumber = 'PROJECTPREMIUM', @Guid = '09015f9f-377f-4538-bbb5-f75ceb09358a'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'PROJECT ONLINE PREMIUM WITHOUT PROJECT CLIENT', @SkuPartNumber = 'PROJECTONLINE_PLAN_1', @Guid = '2db84718-652c-47a7-860c-f10d8abbdae3'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'PROJECT ONLINE WITH PROJECT FOR OFFICE 365', @SkuPartNumber = 'PROJECTONLINE_PLAN_2', @Guid = 'f82a60b8-1ee3-4cfb-a4fe-1c6a53c2656c'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'PROJECT PLAN 1', @SkuPartNumber = 'PROJECT_P1', @Guid = 'beb6439c-caad-48d3-bf46-0c82871e12be'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Project Plan 1 (for Department)', @SkuPartNumber = 'PROJECT_PLAN1_DEPT', @Guid = '84cd610f-a3f8-4beb-84ab-d9d2c902c6c9'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Project Plan 3', @SkuPartNumber = 'PROJECTPROFESSIONAL', @Guid = '53818b1b-4a27-454b-8896-0dba576410e6'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Project Plan 3 (for Department)', @SkuPartNumber = 'PROJECT_PLAN3_DEPT', @Guid = '46102f44-d912-47e7-b0ca-1bd7b70ada3b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Project Plan 3 for GCC', @SkuPartNumber = 'PROJECTPROFESSIONAL_GOV', @Guid = '074c6829-b3a0-430a-ba3d-aca365e57065'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Project Plan 5 for GCC', @SkuPartNumber = 'PROJECTPREMIUM_GOV', @Guid = 'f2230877-72be-4fec-b1ba-7156d6f75bd6'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Rights Management Adhoc', @SkuPartNumber = 'RIGHTSMANAGEMENT_ADHOC', @Guid = '8c4ce438-32a7-4ac5-91a6-e22ae08d9c8b'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Rights Management Service Basic Content Protection', @SkuPartNumber = 'RMSBASIC', @Guid = '093e8d14-a334-43d9-93e3-30589a8b47d0'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Sensor Data Intelligence Additional Machines Add-in for Dynamics 365 Supply Chain Management', @SkuPartNumber = 'DYN365_IOT_INTELLIGENCE_ADDL_MACHINES', @Guid = '08e18479-4483-4f70-8f17-6f92156d8ea9'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Sensor Data Intelligence Scenario Add-in for Dynamics 365 Supply Chain Management', @SkuPartNumber = 'DYN365_IOT_INTELLIGENCE_SCENARIO', @Guid = '9ea4bdef-a20b-4668-b4a7-73e1f7696e0a'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'SHAREPOINT ONLINE (PLAN 1)', @SkuPartNumber = 'SHAREPOINTSTANDARD', @Guid = '1fc08a02-8b3d-43b9-831e-f76859e04e1a'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'SHAREPOINT ONLINE (PLAN 2)', @SkuPartNumber = 'SHAREPOINTENTERPRISE', @Guid = 'a9732ec9-17d9-494c-a51c-d6b45b384dcb'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'SharePoint Syntex', @SkuPartNumber = 'Intelligent_Content_Services', @Guid = 'f61d4aba-134f-44e9-a2a0-f81a5adb26e4'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'SKYPE FOR BUSINESS ONLINE (PLAN 1)', @SkuPartNumber = 'MCOIMP', @Guid = 'b8b749f8-a4ef-4887-9539-c95b1eaa5db7'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'SKYPE FOR BUSINESS ONLINE (PLAN 2)', @SkuPartNumber = 'MCOSTANDARD', @Guid = 'd42c793f-6c78-4f43-92ca-e8f6a02b035f'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'SKYPE FOR BUSINESS PSTN DOMESTIC AND INTERNATIONAL CALLING', @SkuPartNumber = 'MCOPSTN2', @Guid = 'd3b4fe1f-9992-4930-8acb-ca6ec609365e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'SKYPE FOR BUSINESS PSTN DOMESTIC CALLING', @SkuPartNumber = 'MCOPSTN1', @Guid = '0dab259f-bf13-4952-b7f8-7db8f131b28d'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'SKYPE FOR BUSINESS PSTN DOMESTIC CALLING (120 Minutes)', @SkuPartNumber = 'MCOPSTN5', @Guid = '54a152dc-90de-4996-93d2-bc47e670fc06'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Skype for Business PSTN Usage Calling Plan', @SkuPartNumber = 'MCOPSTNPP', @Guid = '06b48c5f-01d9-4b18-9015-03b52040f51a'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Teams Phone with Calling Plan', @SkuPartNumber = 'MCOTEAMS_ESSENTIALS', @Guid = 'ae2343d1-0999-43f6-ae18-d816516f6e78'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Teams Rooms Premium', @SkuPartNumber = 'MTR_PREM', @Guid = '4fb214cb-a430-4a91-9c91-4976763aa78f'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'TELSTRA CALLING FOR O365', @SkuPartNumber = 'MCOPSTNEAU2', @Guid = 'de3312e1-c7b0-46e6-a7c3-a515ff90bc86'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Universal Print', @SkuPartNumber = 'UNIVERSAL_PRINT', @Guid = '9f3d9c1d-25a5-4aaa-8e59-23a1e6450a67'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Visio Plan 1', @SkuPartNumber = 'VISIO_PLAN1_DEPT', @Guid = 'ca7f3140-d88c-455b-9a1c-7f0679e31a76'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Visio Plan 2', @SkuPartNumber = 'VISIO_PLAN2_DEPT', @Guid = '38b434d2-a15e-4cde-9a98-e737c75623e1'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'VISIO ONLINE PLAN 1', @SkuPartNumber = 'VISIOONLINE_PLAN1', @Guid = '4b244418-9658-4451-a2b8-b5e2b364e9bd'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'VISIO ONLINE PLAN 2', @SkuPartNumber = 'VISIOCLIENT', @Guid = 'c5928f49-12ba-48f7-ada3-0d743a3601d5'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'VISIO PLAN 2 FOR GCC', @SkuPartNumber = 'VISIOCLIENT_GOV', @Guid = '4ae99959-6b0f-43b0-b1ce-68146001bdba'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Viva Topics', @SkuPartNumber = 'TOPIC_EXPERIENCES', @Guid = '4016f256-b063-4864-816e-d818aad600c9'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 10/11 Enterprise E5 (Original)', @SkuPartNumber = 'WIN_ENT_E5', @Guid = '1e7e1070-8ccb-4aca-b470-d7cb538cb07e'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 10 Enterprise A3 for faculty', @SkuPartNumber = 'WIN10_ENT_A3_FAC', @Guid = '8efbe2f6-106e-442f-97d4-a59aa6037e06'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 10 Enterprise A3 for students', @SkuPartNumber = 'WIN10_ENT_A3_STU', @Guid = 'd4ef921e-840b-4b48-9a90-ab6698bc7b31'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'WINDOWS 10 ENTERPRISE E3', @SkuPartNumber = 'WIN10_PRO_ENT_SUB', @Guid = 'cb10e6cd-9da4-4992-867b-67546b1db821'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'WINDOWS 10 ENTERPRISE E3', @SkuPartNumber = 'WIN10_VDA_E3', @Guid = '6a0f6da5-0b87-4190-a6ae-9bb5a2b9546a'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 10 Enterprise E5', @SkuPartNumber = 'WIN10_VDA_E5', @Guid = '488ba24a-39a9-4473-8ee5-19291e71b002'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 10 Enterprise E5 Commercial (GCC Compatible)', @SkuPartNumber = 'WINE5_GCC_COMPAT', @Guid = '938fd547-d794-42a4-996c-1cc206619580'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 365 Business 2 vCPU 4 GB 64 GB', @SkuPartNumber = 'CPC_B_2C_4RAM_64GB', @Guid = '42e6818f-8966-444b-b7ac-0027c83fa8b5'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 365 Business 4 vCPU 16 GB 128 GB (with Windows Hybrid Benefit)', @SkuPartNumber = 'CPC_B_4C_16RAM_128GB_WHB', @Guid = '439ac253-bfbc-49c7-acc0-6b951407b5ef'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 365 Enterprise 2 vCPU 4 GB 64 GB', @SkuPartNumber = 'CPC_E_2C_4GB_64GB', @Guid = '7bb14422-3b90-4389-a7be-f1b745fc037f'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 365 Enterprise 2 vCPU', @SkuPartNumber = '8 GB, 128 GB', @Guid = '113feb6c-3fe4-4440-bddc-54d774bf0318'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 365 Enterprise 2 vCPU', @SkuPartNumber = '8 GB, 128 GB', @Guid = '3efff3fe-528a-4fc5-b1ba-845802cc764f'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 365 Enterprise 2 vCPU', @SkuPartNumber = '8 GB, 128 GB (Preview)', @Guid = '113feb6c-3fe4-4440-bddc-54d774bf0318'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 365 Enterprise 2 vCPU', @SkuPartNumber = '8 GB, 128 GB (Preview)', @Guid = '3efff3fe-528a-4fc5-b1ba-845802cc764f'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 365 Enterprise 4 vCPU', @SkuPartNumber = '16 GB, 256 GB (Preview)', @Guid = '113feb6c-3fe4-4440-bddc-54d774bf0318'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows 365 Enterprise 4 vCPU', @SkuPartNumber = '16 GB, 256 GB (Preview)', @Guid = '9ecf691d-8b82-46cb-b254-cd061b2c02fb'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'WINDOWS STORE FOR BUSINESS', @SkuPartNumber = 'WINDOWS_STORE', @Guid = '6470687e-a428-4b7a-bef2-8a291ad947c9'
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Windows Store for Business EDU Faculty', @SkuPartNumber = 'WSFB_EDU_FACULTY ', @Guid = 'c7e9d9e6-1981-4bf3-bb50-a5bdfaa06fb2 '
EXEC [dbo].[proc_AddLicenseProductName] @DisplayName = 'Microsoft Workplace Analytics', @SkuPartNumber = 'WORKPLACE_ANALYTICS', @Guid = '3d957427-ecdc-4df2-aacd-01cc9d519da8'
GO

-- ====================================================
-- Author: aldras
-- Create date: 05/27/2022
-- Modify date: 05/27/2022
-- Description: Retrieve license statistics
-- ====================================================
CREATE VIEW [dbo].[AllLicenseStatistics]
AS
SELECT COALESCE([DisplayName], [ls].[SkuPartNumber]) AS [DisplayName]
      ,[ls].[SkuPartNumber] AS [SkuPartNumber]
      ,[ConsumedUnits]
      ,[Enabled]
      ,[Suspended]
      ,[Warning]
      ,[Timestamp]
  FROM [dbo].[LicenseStatistics] ls LEFT JOIN [dbo].[LicenseProductNames] lpn ON ([ls].[SkuPartNumber] = [lpn].[SkuPartNumber])
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/04/2022
-- Modify date: 06/04/2022
-- Description: Retrieve license statistics for a last
--              day in a month
-- ====================================================
CREATE VIEW [dbo].[AllLicenseStatisticsPerMonth]
AS
    SELECT
        [DisplayName],
        [SkuPartNumber],
        [Enabled],
        [ConsumedUnits],
        [Enabled]-[ConsumedUnits] AS [AvailableUnits],
        CAST([Timestamp] AS DATE) AS [Date]
    FROM (
        SELECT
            [DisplayName],
            [SkuPartNumber],
            [Enabled],
            [ConsumedUnits],
            [Timestamp],
            ROW_NUMBER() OVER (PARTITION BY [SkuPartNumber], YEAR([Timestamp]), Month([Timestamp]) ORDER BY [Timestamp] DESC) as MAX_ID
        FROM
            [dbo].[AllLicenseStatistics]) ls
    WHERE MAX_ID = 1
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/04/2022
-- Modify date: 06/04/2022
-- Description: Retrieve newest license statistics
-- ====================================================
CREATE VIEW [dbo].[LastLicenseStatistics]
AS
     SELECT
        [DisplayName],
        [SkuPartNumber],
        [Enabled],
        [ConsumedUnits],
        [Enabled]-[ConsumedUnits] AS [AvailableUnits],
        CAST([Timestamp] AS DATE) AS [Date]
    FROM (
        SELECT
            [DisplayName],
            [SkuPartNumber],
            [Enabled],
            [ConsumedUnits],
            [Timestamp],
            ROW_NUMBER() OVER (PARTITION BY [SkuPartNumber] ORDER BY [Timestamp] DESC) as MAX_ID
        FROM
            [dbo].[AllLicenseStatistics]) ls
    WHERE MAX_ID = 1
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/04/2022
-- Modify date: 06/04/2022
-- Description: Employee forecast
-- ====================================================
CREATE TABLE [dbo].[LicenseHREmployeeForecast](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [Month] DATETIME NOT NULL,
    [NewHires] INT NOT NULL DEFAULT 0,
    [Leavers] INT NOT NULL DEFAULT 0
    CONSTRAINT [LicenseHREmployeeForecast_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE INDEX idx_LicenseHREmployeeForecast ON [dbo].[LicenseHREmployeeForecast] ([Month] ASC, [Id] ASC)
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/04/2022
-- Modify date: 06/04/2022
-- Description: Adds HR employee forecast
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddLicenseHREmployeeForecast]
    @Month DATETIME,
    @NewHires INT,
    @Leavers INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @calculatedMonth AS DATETIME = DATEADD(month, DATEDIFF(month, 0, @Month), 0)
    
    declare @existingId as INT = (select [Id] from [dbo].[LicenseHREmployeeForecast] where [Month]=@calculatedMonth)
    
    if (@existingId IS NULL)
    begin
        INSERT INTO [dbo].[LicenseHREmployeeForecast] ([Month], [NewHires], [Leavers])
        values (@calculatedMonth, @NewHires, @Leavers)
    end else
    begin
        UPDATE [dbo].[LicenseHREmployeeForecast]
        SET
            [NewHires] = @NewHires,
            [Leavers] = @Leavers
        WHERE [Month]=@calculatedMonth
    end
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/04/2022
-- Modify date: 06/04/2022
-- Description: Retrieves license forecast for a SKU
-- ====================================================

CREATE FUNCTION [dbo].[fn_GetLicenseForecast] ( @Sku nvarchar(255) )
RETURNS @calc TABLE (
    [SkuPartNumber] nvarchar(255),
    [Month] DATETIME,
    [NewHires] INT,
    [Leavers] INT,
    [Balance] INT
)
AS
BEGIN
    DECLARE @temp TABLE (
        [SkuPartNumber] nvarchar(255),
        [Month] DATETIME,
        [NewHires] INT,
        [Leavers] INT,
        [Balance] INT
    );

    declare @Enabled AS INT = (SELECT
                [Enabled]
            FROM
                [dbo].[LastLicenseStatistics]
            WHERE
                [SkuPartNumber]=@Sku)

    if (@Enabled < 1000000)
    BEGIN

        INSERT INTO @temp 
            ([SkuPartNumber], [Month], [NewHires], [Leavers], [Balance])
        VALUES
            (@Sku, DATEADD(month, DATEDIFF(month, 0, GETUTCDATE()), -1), 0, 0, (
                SELECT
                    [AvailableUnits]
                FROM
                    [dbo].[LastLicenseStatistics]
                WHERE
                    [SkuPartNumber]=@Sku
            ));

        INSERT INTO @temp ([SkuPartNumber], [Month], [NewHires], [Leavers], [Balance]) SELECT @Sku, [Month], [NewHires], [Leavers], 0 from [dbo].[LicenseHREmployeeForecast]; 

        INSERT INTO @calc ([SkuPartNumber], [Month], [NewHires], [Leavers], [Balance])
        SELECT 
            [SkuPartNumber], [Month], [NewHires], [Leavers], 
            SUM([Balance] - [NewHires] + [Leavers]) OVER (ORDER BY [Month]
                                        ROWS BETWEEN UNBOUNDED PRECEDING
                                                AND CURRENT ROW)
                AS [Balance]
        FROM
            @temp
        ORDER BY
            [Month];

        DELETE FROM
            @calc
        WHERE
            [Month] < DATEADD(month, DATEDIFF(month, 0, GETUTCDATE()), 0);
    END
    RETURN;
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 06/04/2022
-- Modify date: 06/04/2022
-- Description: Retrieves license forecast for all SKUs
-- ====================================================

CREATE VIEW [dbo].[vw_GetAllLicenseForecast]
AS
    SELECT 
        lf.*
    FROM
        [dbo].[LastLicenseStatistics] lls CROSS APPLY [dbo].[fn_GetLicenseForecast]([lls].[SkuPartNumber]) lf
GO

-- ====================================================
-- Author: aldras
-- Create date: 12/23/2021
-- Modify date: 06/07/2022
-- Description: Retrieves Roadmap communication from
--              the Roadmap table
-- ====================================================
ALTER VIEW [dbo].[AllRoadmapCommsDetailed]
AS
SELECT ID, 
        JSON_VALUE(Data, '$.Title') AS [Title],
        CONVERT(DATETIME2, JSON_VALUE(Data, '$.AvailabilityDateFrom')) AS [AvailabilityFrom],
        CONVERT(DATETIME2, JSON_VALUE(Data, '$.AvailabilityDateTo')) AS [AvailabilityTo], 
        COALESCE(JSON_QUERY([Data], '$.Tags'), JSON_QUERY([Data], '$.Category'), '[]') AS [Category],
        JSON_VALUE(Data, '$.Description') AS [Description],
        JSON_VALUE(Data, '$.AvailabilityDate') AS [AvailabilityDate],
        CONVERT(DATETIME2, CONVERT(datetimeoffset, JSON_VALUE(Data, '$.Published'))) AS [Published],
        CONVERT(DATETIME2, CONVERT(datetimeoffset, JSON_VALUE(Data, '$.LastUpdated'))) AS [LastUpdated],
        WorkItemID,
        WorkItemURL
FROM    dbo.Roadmap
GO
"@,
"Roadmap support pefrormance fix, Microsoft 365 license statistics."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2204, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("c30ca867-6964-4291-95ce-23dc14e21bd7"),
                @"
CREATE TABLE [dbo].[SyncConfig](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [Component] [nvarchar](255) NOT NULL,
    [Element] [nvarchar](255) NOT NULL,
    [Config] [nvarchar](max) NOT NULL,
    [Created] [datetime] NOT NULL DEFAULT GETUTCDATE(),
    [CreatedBy] [nvarchar](255) NOT NULL,
    [Modified] [datetime] NOT NULL DEFAULT GETUTCDATE(),
    [ModifiedBy] [nvarchar](255) NOT NULL
    CONSTRAINT [SyncConfig_PK] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE INDEX idx_SyncConfig ON [dbo].[SyncConfig] ([Component] ASC, [Element] ASC)
GO


-- ====================================================
-- Author: aldras
-- Create date: 04/10/2022
-- Modify date: 04/10/2022
-- Description: Updates sync configuration element
-- ====================================================
CREATE PROCEDURE [dbo].[proc_UpdateSyncConfig]
    @Component nvarchar(255),
    @Element nvarchar(255),
    @Config nvarchar(MAX),
    @User nvarchar(255)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE
        [dbo].[SyncConfig]
    SET
        [Config]=@Config,
        [Modified]=GETUTCDATE(),
        [ModifiedBy]=@User
    WHERE
        [Component]=@Component AND
        [Element]=@Element
END
GO

-- ====================================================
-- Author: aldras
-- Create date: 04/10/2022
-- Modify date: 04/10/2022
-- Description: Adds or updates sync configuration
--				element
-- ====================================================
CREATE PROCEDURE [dbo].[proc_AddSyncConfig]
    @Component nvarchar(255),
    @Element nvarchar(255),
    @Config nvarchar(MAX),
    @User nvarchar(255)
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @existingConfigId AS INT = (SELECT [Id] FROM [dbo].[SyncConfig] WHERE [Component]=@Component and [Element]=@Element)
    
    IF (@existingConfigId IS NULL)
    BEGIN
        INSERT INTO
            [dbo].[SyncConfig] ([Component], [Element], [Config], [CreatedBy], [ModifiedBy])
        VALUES
            (@Component, @Element, @Config, @User, @User)
    END ELSE
    BEGIN
        EXEC [dbo].[proc_UpdateSyncConfig] @Component=@Component, @Element=@Element, @Config=@Config, @User=@User
    END
END
GO                
"@,
"Admin center support."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2203, 1),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("1552f46c-1073-4795-85f9-1c99009afccc"),
                @"
ALTER TABLE [dbo].[Notifications] ADD [isIncidentResolved] AS JSON_VALUE([Data],'$.isResolved')
GO
CREATE INDEX [idx_Notifications_json_isResolved] ON [dbo].[Notifications]([isIncidentResolved])
GO
ALTER TABLE [dbo].[Notifications] ADD [Comments] nvarchar(max)
GO
ALTER TABLE [dbo].[Notifications] ADD [LastModifiedBy] nvarchar(512) NULL
GO
ALTER TABLE [dbo].[Notifications] ADD [EndTime] AS JSON_VALUE([Data],'$.endDateTime')
GO
CREATE INDEX [idx_Notifications_json_endDateTime] ON [dbo].[Notifications]([EndTime])
GO

CREATE VIEW [dbo].[AllPublicIncidents]
AS
    SELECT
        [ID],
        JSON_VALUE([Data], '$.title') AS [Title],
        JSON_VALUE([Data], '$.service') AS [Service],
        CONVERT(DateTime, JSON_VALUE([Data], '$.startDateTime')) AS [StartTime],
        CONVERT(DateTime, JSON_VALUE([Data], '$.endDateTime')) AS [EndTime],
        CONVERT(DateTime, JSON_VALUE([Data], '$.lastModifiedDateTime')) AS [lastModifiedDateTime],
        [Comments],
        [LastModifiedBy]
    FROM
        [dbo].[Notifications]
    WHERE
        [Type] = 'SERVICEHEALTHISSUE' AND
        [Public] = 'true' AND
        [isIncidentResolved] = 'false'
GO

CREATE VIEW [dbo].[AllPublicMessages]
AS
    SELECT
        [ID],
        JSON_VALUE([Data], '$.title') AS [Title],
        JSON_QUERY([Data], '$.services') AS [Services],
        (SELECT content FROM OPENJSON([Data], '$.body') WITH (content nvarchar(max) '$.content')) AS [Content],
        CONVERT(DateTime, JSON_VALUE([Data], '$.startDateTime')) AS [StartTime],
        [EndTime],
        CONVERT(DateTime, JSON_VALUE([Data], '$.lastModifiedDateTime')) AS [lastModifiedDateTime],
        [Comments],
        [LastModifiedBy]

    FROM
        [dbo].[Notifications]
    WHERE
        [Type] = 'SERVICEUPDATEMESSAGE' AND
        [Public] = 'true' AND
        [EndTime] >= GETUTCDATE()
GO

-- ====================================================
-- Author: aldras
-- Create date: 03/31/2022
-- Modify date: 03/31/2022
-- Description: Publishes notification for
--              company-wide communication
-- ====================================================
CREATE PROCEDURE [dbo].[proc_PublishNotification]
    @Id nvarchar(64),
    @Comments nvarchar(max) = NULL,
    @LastModifiedBy nvarchar(512) = NULL
AS
    BEGIN
        SET NOCOUNT ON;

        UPDATE
            [dbo].[Notifications]
        SET
            [Public]=1,
            [Comments]=@Comments,
            [LastModifiedBy]=@LastModifiedBy
        WHERE
            [Id]=@Id
    END
GO

-- ====================================================
-- Author: aldras
-- Create date: 03/31/2022
-- Modify date: 04/07/2022
-- Description: Unpublishes notification
-- ====================================================
CREATE PROCEDURE [dbo].[proc_UnpublishNotification]
    @Id nvarchar(64),
    @LastModifiedBy nvarchar(512) = NULL
AS
    BEGIN
        SET NOCOUNT ON;

        UPDATE
            [dbo].[Notifications]
        SET
            [Public]=0,
            [LastModifiedBy]=@LastModifiedBy
        WHERE
            [Id]=@Id
    END
GO

-- ====================================================
-- Author: aldras
-- Create date: 02/27/2022
-- Modify date: 04/06/2022
-- Description: Adds translation in translation cache
-- ====================================================
ALTER PROCEDURE [dbo].[proc_CacheTranslation]
    @Hash nvarchar(40),
    @Language nvarchar(16),
    @Message nvarchar(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    
    declare @existingHash as nvarchar(40) = (select [Hash] from [dbo].[TranslationCache] where [Hash]=@Hash and [Language]=@Language)
    
    if (@existingHash IS NULL)
    begin
        INSERT INTO [dbo].[TranslationCache] ([Hash], [Language], [Message])
        values (@Hash, @Language, @Message)
    end else
    begin
        UPDATE [dbo].[TranslationCache]
        SET
            [Message] = @Message
        WHERE [Hash]=@Hash and [Language]=@Language
    end
END
GO

EXEC [dbo].[proc_CacheTranslation] @Hash='4078E029D86559A033707B1F7AF7F04D', @Language='bs', @Message='Nove funkcije'
EXEC [dbo].[proc_CacheTranslation] @Hash='7C77070192C0237252AF6643EC4BE168', @Language='bs', @Message='Nije moguće učitati podatke. Greška:'
EXEC [dbo].[proc_CacheTranslation] @Hash='447B7147E84BE512208DCC0995D67EBC', @Language='bs', @Message='element'
EXEC [dbo].[proc_CacheTranslation] @Hash='691D502CFD0E0626CD3B058E5682AD1C', @Language='bs', @Message='elemenata'
EXEC [dbo].[proc_CacheTranslation] @Hash='63D1919EB3FDFC42FBBDB5A73EBA635C', @Language='bs', @Message='Nove funkcije'
EXEC [dbo].[proc_CacheTranslation] @Hash='D3D2E617335F08DF83599665EEF8A418', @Language='bs', @Message='Sačuvaj'
EXEC [dbo].[proc_CacheTranslation] @Hash='C9CC8CCE247E49BAE79F15173CE97354', @Language='bs', @Message='Sačuvaj'
EXEC [dbo].[proc_CacheTranslation] @Hash='75D0742D754502668D86D49A37470433', @Language='de', @Message='Aktive Probleme'
EXEC [dbo].[proc_CacheTranslation] @Hash='CB8634524E7FBD6CC733E34A63194918', @Language='de', @Message='Dienste auswählen'
EXEC [dbo].[proc_CacheTranslation] @Hash='C9CC8CCE247E49BAE79F15173CE97354', @Language='de', @Message='Speichern'
EXEC [dbo].[proc_CacheTranslation] @Hash='29E7E87423B40C01D3E57F7F5272DDE9', @Language='hr', @Message='Akcija zahtijevana do'
EXEC [dbo].[proc_CacheTranslation] @Hash='D3D2E617335F08DF83599665EEF8A418', @Language='hr', @Message='Sačuvaj'
EXEC [dbo].[proc_CacheTranslation] @Hash='447B7147E84BE512208DCC0995D67EBC', @Language='hr', @Message='element'
EXEC [dbo].[proc_CacheTranslation] @Hash='691D502CFD0E0626CD3B058E5682AD1C', @Language='hr', @Message='elemenata'
EXEC [dbo].[proc_CacheTranslation] @Hash='F53B6F6BA5A4C2C190041FE59D8926A0', @Language='hr', @Message='Očisti filter'
EXEC [dbo].[proc_CacheTranslation] @Hash='4078E029D86559A033707B1F7AF7F04D', @Language='hr', @Message='Nove funkcije'
EXEC [dbo].[proc_CacheTranslation] @Hash='1027A0E13EC28E18C2E6D52E77AB4842', @Language='hr', @Message='Nove funkcije'
EXEC [dbo].[proc_CacheTranslation] @Hash='C29AEF95212613F5E3FF8189DFA84F4C', @Language='sr-Cyrl', @Message='Нема објављених инцидената.'
EXEC [dbo].[proc_CacheTranslation] @Hash='3C3BB4B20414D32F6AA2E14FD4720F92', @Language='sr-Cyrl', @Message='Нема објављених активитета!'
EXEC [dbo].[proc_CacheTranslation] @Hash='3DFED1051CC2FFF36ED1E15EEE3C8E40', @Language='sr-Cyrl', @Message='Порука'
EXEC [dbo].[proc_CacheTranslation] @Hash='3C3BB4B20414D32F6AA2E14FD4720F92', @Language='sr-Latn', @Message='Nema objavljenih incidenata!'
EXEC [dbo].[proc_CacheTranslation] @Hash='C29AEF95212613F5E3FF8189DFA84F4C', @Language='sr-Latn', @Message='Nema objavljenih incidenata!'
EXEC [dbo].[proc_CacheTranslation] @Hash='3DFED1051CC2FFF36ED1E15EEE3C8E40', @Language='sr-Latn', @Message='Poruka'
GO
"@,
"Company dashboard support."
            )
        );

        $this.m_databaseUpgradeScripts.Add(
            [Version]::new(2, 0, 2203, 0),
            [SHHDatabaseUpgradeAction]::new(
                [Guid]::new("a9a5de80-1bfa-4175-9251-92c71b770b22"),
                @"
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TranslationCache](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [Hash] [nvarchar](40) NOT NULL,
    [Language] [nvarchar](16) NULL,
    [Message] [nvarchar](max) NOT NULL,
    [Timestamp] [datetime] NOT NULL DEFAULT GETUTCDATE()
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

SET ANSI_PADDING ON
GO
ALTER TABLE [dbo].[TranslationCache] ADD  CONSTRAINT [TranslationCache_PK] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
CREATE INDEX idx_Translation ON [dbo].[TranslationCache] ([Hash] ASC, [Language] ASC, [Timestamp] ASC)
GO

-- ====================================================
-- Author: aldras
-- Create date: 02/27/2022
-- Modify date: 02/28/2022
-- Description: Adds translation in translation cache
-- ====================================================
CREATE PROCEDURE [dbo].[proc_CacheTranslation]
    @Hash nvarchar(40),
    @Language nvarchar(16),
    @Message nvarchar(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    
    declare @existingHash as nvarchar(40) = (select [Hash] from [dbo].[TranslationCache] where [Hash]=@Hash and [Language]=@Language)
    
    if (@existingHash IS NULL)
    begin
        INSERT INTO [dbo].[TranslationCache] ([Hash], [Language], [Message])
        values (@Hash, @Language, @Message)
    end
END
GO

ALTER TABLE [dbo].[Notifications] ADD [Public] BIT DEFAULT 0
CREATE INDEX ix_Notifications ON [dbo].[Notifications] ([Public] ASC)
GO
ALTER TABLE [dbo].[Roadmap] ADD [Public] BIT DEFAULT 0
CREATE INDEX ix_Roadmap ON [dbo].[Roadmap] ([Public] ASC)
GO
"@,
"Translation caching support."
            )
        );
    }

    M365ServiceHealthHubDB(): base([BaseConfiguration]::ConnectionString)
    {

    }

    M365ServiceHealthHubDB([bool]$SkipUpgrade): base([BaseConfiguration]::ConnectionString, $SkipUpgrade)
    {

    }

    M365ServiceHealthHubDB([string]$ConnectionString): base($ConnectionString)
    {

    }

    M365ServiceHealthHubDB([string]$ConnectionString, [bool]$SkipUpgrade): base($ConnectionString, $SkipUpgrade)
    {

    }

    M365ServiceHealthHubDB([string]$ConnectionString, [AuthManager]$AuthManager): base($ConnectionString, $AuthManager)
    {

    }

    [void]PerformSchemaCheck()
    {
        if ($null -eq $global:M365HHDBSchemaCheckCompleted -and $this.m_skipUpgrade -ne $true)
        {
            if (![string]::IsNullOrWhiteSpace([BaseConfiguration]::SkipDatabaseCreation)) {
                $this.EnsureDatabase([BaseConfiguration]::SkipDatabaseCreation);
            } else {
                $this.EnsureDatabase();
            }
            
            $global:M365HHDBSchemaCheckCompleted = $true;
        }
    }

    [void]PerformSchemaCheck([bool]$SkipPostUpgradeProcedures)
    {
        $skipPIP = $this.m_skipPostUpgradeProcedures
        $this.m_skipPostUpgradeProcedures = $SkipPostUpgradeProcedures;
        $this.EnsureDatabase($true);
        $global:M365HHDBSchemaCheckCompleted = $true;
    }

    [System.Data.DataTableCollection]GetServiceCommunication(
        [string]$Id,
        [string]$CommunicationType
    )
    {
        $this.PerformSchemaCheck();
        return $this.sqlHelper.GetTSQLDataTableCollection("SELECT * FROM [dbo].[Notifications] WHERE [ID]='$Id' AND [Type]='$CommunicationType'");
    }

    [System.Data.DataTableCollection]GetServiceCommunicationCollection(
        [string]$idList,
        [string]$CommunicationType
    )
    {
        $this.PerformSchemaCheck();
        $query = "SELECT * FROM [dbo].[Notifications] WHERE [ID] IN ($idList) AND ([Type]='$CommunicationType' OR [Type]='')";
        return $this.sqlHelper.GetTSQLDataTableCollection($query)
    }

    [System.Data.DataTableCollection]GetServiceCommunicationCollection(
        [string]$CommunicationType
    )
    {
        $this.PerformSchemaCheck();
        $query = "SELECT * FROM [dbo].[Notifications] WHERE [Type]='$CommunicationType'";
        return $this.sqlHelper.GetTSQLDataTableCollection($query)
    }

    [System.Data.DataTableCollection]GetIndexedServiceCommunicationCollection()
    {
        $this.PerformSchemaCheck();
        $query = "SELECT * FROM [dbo].[Notifications] WHERE [Indexed]=1";
        return $this.sqlHelper.GetTSQLDataTableCollection($query)
    }

    [System.Data.DataTableCollection]GetServiceCommunicationsForReindexing()
    {
        $this.PerformSchemaCheck();
        $query = "SELECT [ID], [Type] FROM [dbo].[Notifications] WHERE [Indexed]=-1";
        return $this.sqlHelper.GetTSQLDataTableCollection($query)
    }

    [void]SetServiceCommunication(
        [string]$Id,
        [DateTime]$LastUpdatedTime,
        [string]$MessageJson,
        [string]$WorkItemId,
        [string]$WorkItemUrl,
        [string]$CommunicationType
    )
    {
        $this.PerformSchemaCheck();
        $currentServiceCommunication = $this.GetServiceCommunication($Id, $CommunicationType);

        $op = '';
        if ($null -eq $currentServiceCommunication.Rows -or $currentServiceCommunication.Rows.Count -lt 1)
        {
            $op = 'Created'
        } else {
            $op = 'Modified'
        }

        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Id", $Id))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("LastUpdatedTime", $LastUpdatedTime)))  | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Data", $MessageJson)))  | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("WorkItemId", $WorkItemId)))  | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("WorkItemUrl", $WorkItemUrl)))  | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Type", $CommunicationType)))  | Out-Null
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_AddNotification]", $parameters) | Out-Null  

        $modifiedPropertiesStr = $this.GetLatestVersionDiff($Id, $CommunicationType);
        $modifiedProperties = $null

        try {
            $modifiedProperties = $modifiedPropertiesStr | ConvertFrom-Json
        } catch {
            
        }

        $this.AddActivityLogRecord(
            [Guid]::Empty,
            [TraceLogging]::CorrelationID,
            '',
            'app-' + [BaseConfiguration]::ClientId + '@'+ [BaseConfiguration]::TenantDomain,
            $op,
            'item://' + $CommunicationType + '/' + $Id,
            'Item',
            $this.GetLatestVersionId($Id, $CommunicationType),
            $Id,
            'Sync',
            [Guid]::Empty,
            $null,
            $modifiedProperties
        )
    }

    [System.Object]GetLastSyncTime(
        [string]$CommunicationType
    )
    {
        $this.PerformSchemaCheck();
        $tsql = "SELECT [SerializedValue] FROM [dbo].[Config] WHERE [Key] = 'LastSync$($CommunicationType)Timestamp'" # keep the key in sync with [proc_RegisterSyncHeartbeat] stored procedure.
        $val = $this.sqlHelper.GetTSQLValue($tsql, "SerializedValue")
        return $val
    }

    [void]SetLastSyncTime(
        [string]$CommunicationType
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("CommunicationType", $CommunicationType))) | Out-Null
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_RegisterSyncHeartbeat]", $parameters) | Out-Null
    }

    [System.Object]GetConfigValue(
        [string]$Key
    )
    {
        $this.PerformSchemaCheck();
        $tsql = "SELECT [SerializedValue] FROM [dbo].[Config] WHERE [Key] = '$Key'"
        $val = $this.sqlHelper.GetTSQLValue($tsql, "SerializedValue")
        # add deserialzation

        if ($null -eq $val)
        {
            return $null
        }

        try {
            return $($val | ConvertFrom-Json)
        } catch {
            return $val
        }
    }

    [void]SetConfigValue(
        [string]$Key,
        [object]$Value
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Key", $Key))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Value", $($Value | ConvertTo-Json -Depth 10)))) | Out-Null # replace with serialization
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("DataType", $($null -eq $Value ? "null" : $Value.GetType().FullName)))) | Out-Null
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_SetConfigValue]", $parameters) | Out-Null
    }

    [System.Object]GetLastRoadmapSyncTime()
    {
        $this.PerformSchemaCheck();
        $tsql = "SELECT [SerializedValue] FROM [dbo].[Config] WHERE [Key] = 'LastRoadmapSyncTimestamp'"
        $val = $this.sqlHelper.GetTSQLValue($tsql, "SerializedValue")
        return $val
    }

    [System.Object]GetTranslationFromCache(
        [string]$Message,
        [string]$Language
    )
    {
        $this.PerformSchemaCheck();

        $md5 = New-Object -TypeName System.Security.Cryptography.MD5CryptoServiceProvider;
        $utf8 = New-Object -TypeName System.Text.UTF8Encoding;
        $Hash = [System.BitConverter]::ToString($md5.ComputeHash($utf8.GetBytes($Message)));
        $Hash = $Hash.Replace("-","");

        return $this.sqlHelper.GetTSQLDataTableCollection("SELECT * FROM [dbo].[TranslationCache] WHERE [Hash]='$Hash' AND [Language]='$Language'");
    }

    [void]CacheTranslation(
        [string]$Message,
        [string]$Translation,
        [string]$Language
    )
    {
        $this.PerformSchemaCheck();
        
        $md5 = New-Object -TypeName System.Security.Cryptography.MD5CryptoServiceProvider;
        $utf8 = New-Object -TypeName System.Text.UTF8Encoding;
        $Hash = [System.BitConverter]::ToString($md5.ComputeHash($utf8.GetBytes($Message)));
        $Hash = $Hash.Replace("-","");

        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Hash", $Hash))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Language", $Language))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Message", $Translation))) | Out-Null
        
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_CacheTranslation]", $parameters) | Out-Null
    }

    [string]GetSyncConfigEntry(
        [string]$Component,
        [string]$Element
    )
    {
        $this.PerformSchemaCheck();
        $tsql = "SELECT [Config] FROM [dbo].[SyncConfig] WHERE [Component] = '$Component' AND [Element] = '$Element'"
        $val = $this.sqlHelper.GetTSQLValue($tsql, "Config")
        return $val
    }

    [void]SetLastRoadmapSyncTime()
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_RegisterRoadmapSyncHeartbeat]", $parameters) | Out-Null
    }

    [string]GetConfigEntry(
        [string]$Key
    )
    {
        $this.PerformSchemaCheck();
        $tsql = "SELECT [SerializedValue] FROM [dbo].[Config] WHERE [Key] = '$Key'"
        $val = $this.sqlHelper.GetTSQLValue($tsql, "SerializedValue")
        return $val
    }

    [void]SetConfigEntry(
        [string]$Key,
        [Object]$Value
    )
    {
        $this.PerformSchemaCheck();
        $SerializedValue = $null -eq $Value ? $null : $Value.ToString();
        $DataType = $null -eq $Value ? "" : $Value.GetType().FullName;
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Key", $Key))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("SerializedValue", $SerializedValue))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("DataType", $DataType))) | Out-Null
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_AddConfigEntry]", $parameters) | Out-Null
    }

    [void]AddLicenseStatistics(
        [string]$SkuPartNumber,
        [Int32]$ConsumedUnits,
        [Int32]$Enabled,
        [Int32]$Suspended,
        [Int32]$Warning
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("SkuPartNumber", $SkuPartNumber))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ConsumedUnits", $ConsumedUnits))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Enabled", $Enabled))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Suspended", $Suspended))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Warning", $Warning))) | Out-Null
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_AddLicenseStats]", $parameters) | Out-Null
    }

    [void]AddLicenseHREmployeeForecast(
        [datetime]$Month,
        [Int32]$NewHires,
        [Int32]$Leavers
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Month", $Month))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("NewHires", $NewHires))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Leavers", $Leavers))) | Out-Null
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_AddLicenseHREmployeeForecast]", $parameters) | Out-Null
    }

    [void]AddMonthlyActiveUsersStatistics(
        [string]$Service,
        [Int32]$Active,
        [Int32]$Inactive,
        [string]$ReportDate
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Service", $Service))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Active", $Active))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Inactive", $Inactive))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ReportDate", $ReportDate))) | Out-Null
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_AddMonthlyActiveUsersStats]", $parameters) | Out-Null
    }

    [void]AddImage(
        [string]$Name,
        [string]$Type,
        [string]$Format,
        [string]$Content
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Name", $Name))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Type", $Type))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Format", $Format))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Content", $Content))) | Out-Null
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_AddImage]", $parameters) | Out-Null
    }

    [System.Object]GetImage(
        [string]$Name,
        [string]$Type
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Name", $Name))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Type", $Type))) | Out-Null
        $dataset = $this.sqlHelper.GetParametrizedDataSet("SELECT * FROM [dbo].[Images] WHERE [Name]=@Name AND [Type]=@Type", $parameters, -1)
        $res = $null

        if ($dataset.Tables.Count -ge 1)
        {
            if ($dataset.Tables[0].Rows.Count -ge 1)
            {
                $res = $dataset.Tables[0].Rows[0]
            }
        }

        return $res
    }

    [System.Data.DataTableCollection]GetNotificationManagerConnectors()
    {
        $this.PerformSchemaCheck();
        return $this.sqlHelper.GetTSQLDataTableCollection("SELECT * FROM [dbo].[vw_GetConnectors] WHERE [ConnectorType]='notificationManager'");
    }

    [System.Object]GetConnector(
        [Guid]$ConnectorId
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ConnectorId", $ConnectorId))) | Out-Null

        $dataset = $this.sqlHelper.GetParametrizedDataSet("SELECT * FROM [dbo].[vw_GetConnectors] WHERE [ConnectorId]=@ConnectorId", $parameters, -1);
        $res = $null

        if ($dataset.Tables.Count -ge 1)
        {
            if ($dataset.Tables[0].Rows.Count -ge 1)
            {
                $res = $dataset.Tables[0].Rows[0]
            }
        }
        return $res
    }

    [void]AddConnector(
        $Connector
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'

        if ($null -ne $Connector.ConnectorId)
        {
            $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ConnectorId", $Connector.ConnectorId))) | Out-Null
        }
        
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Name", $Connector.Name))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Type", $Connector.Type))) | Out-Null

        if ($Connector.Configuration.GetType().Name -eq "String")
        {
            $configurationStr = $Connector.Configuration # already serialized
        } else {
            $configurationStr = $(ConvertTo-Json -InputObject $Connector.Configuration -Depth 10)
        }

        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Configuration", $configurationStr))) | Out-Null

        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_AddConnector]", $parameters) | Out-Null
    }

    [System.Data.DataTableCollection]GetComponents()
    {
        $this.PerformSchemaCheck();
        return $this.sqlHelper.GetTSQLDataTableCollection("SELECT * FROM [dbo].[Components]");
    }

    [System.Data.DataRowCollection]GetNotificationTemplates()
    {
        return $this.GetNotificationTemplates("");
    }

    [System.Data.DataRowCollection]GetNotificationTemplates(
        [string]$Component
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]';
        $query = "SELECT * FROM [dbo].[ConnectorDefinitionTemplates] WHERE [Type]='notificationTemplate'";
        if (![string]::IsNullOrWhiteSpace($Component))
        {
            $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Component", $Component))) | Out-Null
            $query = "SELECT * FROM [dbo].[ConnectorDefinitionTemplates] WHERE [Type]='notificationTemplate' AND [Entity]=@Component";
        }

        $dataset = $this.sqlHelper.GetParametrizedDataSet($query, $parameters, -1);
        $res = $null

        if ($dataset.Tables.Count -ge 1)
        {
            $res = $dataset.Tables[0].Rows
        }

        return $res
    }

    [System.Data.DataRow]GetNotificationTemplate(
        [Guid]$ConnectorDefinition,
        [string]$Entity
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]';
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Entity", $Entity))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ConnectorDefinition", $ConnectorDefinition))) | Out-Null
        $query = "SELECT * FROM [dbo].[ConnectorDefinitionTemplates] WHERE [Type]='notificationTemplate' AND [Entity]=@Entity AND [ConnectorDefinition]=@ConnectorDefinition";

        $dataset = $this.sqlHelper.GetParametrizedDataSet($query, $parameters, -1);
        $res = $null

        if ($dataset.Tables.Count -ge 1)
        {
            if ($dataset.Tables[0].Rows.Count -ge 1)
            {
                $res = $dataset.Tables[0].Rows[0]
            }
        }

        return $res
    }

    [void]AddRoute(
        $Route
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'

        if ($null -ne $Route.Id)
        {
            $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("RouteId", $Route.Id))) | Out-Null
        }
        
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Name", $Route.Name))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ComponentId", $Route.Component))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Order", $Route.Order))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Icon", $Route.Icon))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Language", $Route.Language))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("StopProcessingOnMatch", $Route.StopProcessingOnMatch))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("HideWorkItemLink", $Route.HideWorkItemLink))) | Out-Null

        $conditionsStr = $Route.Conditions | ConvertTo-Json -Depth 5
        if ([string]::IsNullOrWhiteSpace($conditionsStr) -or !$conditionsStr.Trim().StartsWith('['))
        {
            $conditionsStr = "[" + $conditionsStr + "]";
        }
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Conditions", $conditionsStr))) | Out-Null
        
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Connector", $Route.Connector))) | Out-Null

        $connectorConfigStr = $Route.ConnectorConfiguration | ConvertTo-Json -Depth 5
        if ([string]::IsNullOrWhiteSpace($connectorConfigStr) -or !$connectorConfigStr.Trim().StartsWith('['))
        {
            $connectorConfigStr = "[" + $connectorConfigStr + "]";
        }

        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ConnectorConfiguration", $($connectorConfigStr)))) | Out-Null

        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_AddRoute]", $parameters) | Out-Null
    }

    [System.Data.DataRowCollection]GetRoute(
        [string]$Component
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]';
        $query = "SELECT * FROM [dbo].[vw_GetComponentRouting]";
        if (![string]::IsNullOrWhiteSpace($Component))
        {
            $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Component", $Component))) | Out-Null
            $query = "SELECT * FROM [dbo].[vw_GetComponentRouting] WHERE [Entity] = @Component";
        }

        $dataset = $this.sqlHelper.GetParametrizedDataSet($query, $parameters, -1);
        $res = $null

        if ($dataset.Tables.Count -ge 1)
        {
            $res = $dataset.Tables[0].Rows
        }

        return $res
    }

    [void]AddActivityLogRecord(
        [Guid]$OrganizationId,
        [Guid]$CorrelationId,
        [string]$IPAddress,
        [string]$User,
        [string]$Activity,
        [string]$Item,
        [string]$ItemType,
        [Guid]$VersionId,
        [string]$ItemUniqueId,
        [string]$EventSource,
        [Guid]$ComponentID,
        [object]$ExtendedProperties,
        [object]$ModifiedProperties
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'

        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("OrganizationId", $OrganizationId))) | Out-Null

        if ($CorrelationId -ne [Guid]::Empty)
        {
            $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("CorrelationId", $CorrelationId))) | Out-Null
        }

        if (![string]::IsNullOrWhiteSpace($IPAddress))
        {
            $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("IPAddress", $IPAddress))) | Out-Null
        }

        if (![string]::IsNullOrWhiteSpace($User))
        {
            $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("User", $User))) | Out-Null
        }
        
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Activity", $Activity))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Item", $Item))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ItemType", $ItemType))) | Out-Null

        if ($VersionId -ne [Guid]::Empty)
        {
            $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("VersionId", $VersionId))) | Out-Null
        }

        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ItemUniqueId", $ItemUniqueId))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("EventSource", $EventSource))) | Out-Null

        if ($ComponentId -ne [Guid]::Empty)
        {
            $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ComponentId", $ComponentId))) | Out-Null
        }
        
        if ($null -ne $ExtendedProperties)
        {
            $ep = ConvertTo-Json -InputObject $ExtendedProperties -Depth 100
            $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ExtendedProperties", $ep))) | Out-Null
        }
        
        if ($null -ne $ModifiedProperties)
        {
            $mp = ConvertTo-Json -InputObject $ModifiedProperties -Depth 100
            $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ModifiedProperties", $mp))) | Out-Null
        }
        
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_AddActivityLogRecord]", $parameters) | Out-Null
    }

    [System.Data.DataRowCollection]GetActivityLogEntries(
        [int]$PastDays
        
    )
    {
        return $this.GetActivityLogEntries($PastDays, $false)
    }

    [System.Data.DataRowCollection]GetActivityLogEntries(
        [int]$PastDays,
        [bool]$ErrorsOnly
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]';
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("PastDays", $(0-$PastDays)))) | Out-Null
        $query = @"
SELECT
    [al].[ID],
    [al].[CorrelationId],
    [al].[Timestamp],
    [al].[ItemUniqueId],
    [al].[EventSource],
    [al].[Item] AS [ActivityLogItem],
    [al].[ItemType],
    [al].[Activity],
    [al].[ExtendedProperties],
    [c].[Name],
    [c].[InternalName]
FROM 
    [dbo].[ActivityLog] AS [al]
LEFT JOIN 
    [dbo].[Components] AS c ON ([al].ComponentID = [c].ComponentId)
WHERE
    [al].[Timestamp] > DATEADD(day, @PastDays, GETUTCDATE())
"@

        if ($ErrorsOnly)
        {
            $query += " AND ([al].[Activity] LIKE '%Fail%' OR [al].[Activity] LIKE '%Error%')"
        }

        $dataset = $this.sqlHelper.GetParametrizedDataSet($query, $parameters, -1);
        $res = $null

        if ($dataset.Tables.Count -ge 1)
        {
            $res = $dataset.Tables[0].Rows
        }

        return $res
    }

    [string]GetVersionDiff(
        [string]$Id,
        [string]$Type,
        [int]$OldVersionNumber,
        [int]$NewVersionNumber
    )
    {
        $this.PerformSchemaCheck();
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]';
        $query = "SELECT [dbo].[fn_GetVersionDiff](@Id, @Type, @oldVersionNumber, @versionNumber) AS [Diff]";
        
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Id", $Id))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Type", $Type))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("oldVersionNumber", $OldVersionNumber))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("versionNumber", $NewVersionNumber))) | Out-Null

        $dataset = $this.sqlHelper.GetParametrizedDataSet($query, $parameters, -1);
        
        return $dataset.Tables.Diff;
    }

    [string]GetLatestVersionDiff(
        [string]$Id,
        [string]$Type
    )
    {
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]';
        $query = "SELECT TOP (2) [Version] FROM [dbo].[AllVersions] WHERE [Id] = @Id AND [Type]=@Type ORDER BY [Version] DESC";

        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Id", $Id))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Type", $Type))) | Out-Null

        $dataset = $this.sqlHelper.GetParametrizedDataSet($query, $parameters, -1);
        $res = $null

        if ($dataset.Tables.Count -ge 1)
        {
            $res = $dataset.Tables[0].Rows
        }

        $oldVersionNumber = $null -ne $res -and $res.Count -gt 1 ? $res[1]["Version"] : 0;
        $newVersionNumber = $null -ne $res -and $res.Count -gt 0 ? $res[0]["Version"] : 0;

        return $this.GetVersionDiff($Id, $Type, $oldVersionNumber, $newVersionNumber)
    }

    [Guid]GetLatestVersionId(
        [string]$Id,
        [string]$Type
    )
    {
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]';
        $query = "SELECT TOP (1) [VersionId] FROM [dbo].[AllVersions] WHERE [Id] = @Id AND [Type]=@Type ORDER BY [Version] DESC";

        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Id", $Id))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Type", $Type))) | Out-Null

        $dataset = $this.sqlHelper.GetParametrizedDataSet($query, $parameters, -1);
        $res = $null

        if ($dataset.Tables.Count -ge 1)
        {
            $res = $dataset.Tables[0].Rows
        }

        return $($null -ne $res -and $res.Count -gt 0 ? $res[0]["VersionId"] : [Guid]::Empty);
    }

    [string]GetLatestO365EndpointChangeVersion()
    {
        $version = $this.GetConfigValue("SyncedOffice365EndpointChangeVersion");


        return $(![string]::IsNullOrWhiteSpace($version) ? $version : "0000000000");
    }

    [void]SetLatestO365EndpointChangeVersion(
        [string]$Version
    )
    {
        $this.SetConfigValue("SyncedOffice365EndpointChangeVersion", $Version);
    }

    [System.Object]GetComponentConfig(
        [string]$Component
    )
    {
        $this.PerformSchemaCheck();
        $config = $null;
        $parametersComponent = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]';
        $parametersComponent.Add($(New-Object System.Data.SqlClient.SqlParameter("InternalName", $Component))) | Out-Null

        $componentsDataset = $this.sqlHelper.GetParametrizedDataSet("SELECT * FROM [dbo].[Components] WHERE [InternalName]=@InternalName", $parametersComponent, -1);
        if ($componentsDataset.Tables.Count -ge 1)
        {
            $res = $componentsDataset.Tables[0].Rows
            $componentId = $null;
            if ($res.Count -gt 0)
            {
                $componentId = $res[0].ComponentId           
        
                $config = $this.GetConfigValue("Config-" + $componentId);
                if ($null -eq $config)
                {
                    $config = @{
                        enabled = $false
                    }
                }
            }
        }

        return $config
    }

    [System.Object]GetSummaryFromCache(
        [string]$Message
    )
    {
        $this.PerformSchemaCheck();

        $md5 = New-Object -TypeName System.Security.Cryptography.MD5CryptoServiceProvider;
        $utf8 = New-Object -TypeName System.Text.UTF8Encoding;
        $Hash = [System.BitConverter]::ToString($md5.ComputeHash($utf8.GetBytes($Message)));
        $Hash = $Hash.Replace("-","");

        $parametersComponent = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]';
        $parametersComponent.Add($(New-Object System.Data.SqlClient.SqlParameter("Hash", $Hash))) | Out-Null

        $summaryCacheDataset = $this.sqlHelper.GetParametrizedDataSet("SELECT * FROM [dbo].[SummaryCache] WHERE [Hash]=@Hash", $parametersComponent, -1);
        if ($summaryCacheDataset.Tables.Count -ge 1)
        {
            return $summaryCacheDataset.Tables[0]
        } else {
            return $null;
        }  
    }

    [void]CacheSummary(
        [string]$MessageId,
        [string]$Message,
        [string]$Summary
    )
    {
        $this.PerformSchemaCheck();
        
        $md5 = New-Object -TypeName System.Security.Cryptography.MD5CryptoServiceProvider;
        $utf8 = New-Object -TypeName System.Text.UTF8Encoding;
        $Hash = [System.BitConverter]::ToString($md5.ComputeHash($utf8.GetBytes($Message)));
        $Hash = $Hash.Replace("-","");

        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("MessageId", $MessageId))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Hash", $Hash))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Summary", $Summary))) | Out-Null
        
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_CacheSummary]", $parameters) | Out-Null
    }

    [void]RegisterIndexEvent(
        [string]$Id
    )
    {
        $this.PerformSchemaCheck();
        
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Id", $Id))) | Out-Null
        
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_RegisterIndexEvent]", $parameters) | Out-Null
    }

    [void]SetIndexFlag(
        [string]$Id,
        [int]$IndexFlag = 1
    )
    {
        $this.PerformSchemaCheck();
        
        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Id", $Id))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Flag", $IndexFlag))) | Out-Null
        
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_SetIndexFlag]", $parameters) | Out-Null
    }

    [void]ResetIndexFlag()
    {
        # this will reset index flags on all indexed items and with that, retrigger full index
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[ResetIndexFlag]", $null) | Out-Null
    }

    [System.Object]GetCredential(
        [guid]$ObjectId
    )
    {
        $this.PerformSchemaCheck();

        $parametersComponent = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]';
        $parametersComponent.Add($(New-Object System.Data.SqlClient.SqlParameter("ObjectId", $ObjectId))) | Out-Null

        $credentialsDataset = $this.sqlHelper.GetParametrizedDataSet("SELECT * FROM [dbo].[Credentials] WHERE [ObjectId]=@ObjectId", $parametersComponent, -1);
        if ($credentialsDataset.Tables.Count -ge 1)
        {
            return $credentialsDataset.Tables[0]
        } else {
            return $null;
        }  
    }

    [System.Data.DataRowCollection]GetCredentials()
    {
        return $this.GetCredentials([string]::Empty);
    }

    [System.Data.DataRowCollection]GetCredentials(
        [string]$Type
    )
    {
        $this.PerformSchemaCheck();
        $parametersComponent = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]';
        $query = "SELECT * FROM [dbo].[Credentials]";
        if (![string]::IsNullOrWhiteSpace($Type))
        {
            $parametersComponent.Add($(New-Object System.Data.SqlClient.SqlParameter("Type", $Type))) | Out-Null
            $query = "SELECT * FROM [dbo].[Credentials] WHERE [Type]=@Type";
        }

        $dataset = $this.sqlHelper.GetParametrizedDataSet($query, $parametersComponent, -1);
        if ($dataset.Tables.Count -ge 1)
        {
            return $dataset.Tables[0].Rows
        } else {
            return @()
        }
    }


    [void]SetCredential(
        [Guid]$ObjectId,
        [string]$Name,
        [string]$Type,
        [string]$Description,
        [string]$SerializedObject

    )
    {
        $this.PerformSchemaCheck();

        $parameters = New-Object 'System.Collections.Generic.List[System.Data.SqlClient.SqlParameter]'
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("ObjectId", $ObjectId))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Name", $Name))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Type", $Type))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("Description", $Description))) | Out-Null
        $parameters.Add($(New-Object System.Data.SqlClient.SqlParameter("SerializedObject", $SerializedObject))) | Out-Null
        
        $this.sqlHelper.InvokeSQLProcedure("[dbo].[proc_AddCredential]", $parameters) | Out-Null
    }
}