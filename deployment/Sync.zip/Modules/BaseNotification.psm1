class BaseNotification
{

    BaseNotification()
    {
        
    }
}